/*
interview book P 171
*/
#include <stdio.h>
typedef struct binarytree
{
    int value;
    binarytree *left;
    binarytree *right;
} binarytree;

void printfromtootobottom(binarytree *p_root)
{
    if(!p_root)
	return;

    // below belongs to c++ class function
    //std:deque<binarytree *>dequetree;
    //dequetree.push_back(p_root)

    while(dequetree.size())
    {
    	binarytree *p_node=dequetreenode.front();
	dequetree.pop_front();
	printf("%d",p_node->value);
	if(p_node->left)
	    dequetree.push_back(p_node->left);
	if(p_node->right)
	    dequetree.push_back(p_node->right);
    }
}


// below is on th P174
void print(binarytree *p_root)
{
    if(p_root==NULL)
	return;
    std::queue<binarytree *> nodes;
    nodes.push(p_root);
    int nextlevel=0;
    int tobeprinted=1;

    while(!nodes.empty())
    {
	bianrytree *p_node=nodes.front()
	printf("%d",p_node->value);
    	
	if(p_node->left!=NULL)
	{
	    nodes.push(p_node->left);
	    ++nextlevel;
	}

 	if(p_node->right!=NULL)
	{
	    nodes.push(p_node->right);
	    ++nextlevel;	    
	}

    	nodes.pop();
    	--tobeprinted;
    	if(tobeprinted==0)
    	{
	    printf("\n");
	    tobeprinted=nextlevel;
	    nextlevel=0;
    	}
    }

}
