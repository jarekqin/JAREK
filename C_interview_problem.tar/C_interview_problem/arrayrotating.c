/*
rotating an array with 2 sub-array which are both increased.
*/
#include <stdio.h>
#include <stdlib.h>

// method 1
int Min(int *numbers,int length)
{
    if(numbers==NULL || length<=0)
	return ;
    
    int index1=0;
    int index2=length-1;
    int indexMid=index1;
    while (numbers[index1]>=numbers[index2])
    {
	if(index2-index1==1)
	{
	    indexMid=index2;
	    break;
	}
	indexMid=(index1+index2)/2;
	if(numbers[indexMid]>=numbers[index1])
	{
	    index1=indexMid;
	}
	else if(numbers[indexMid]<=numbers[index2])
	{
	    index2=indexMid;
	}
    }
    return numbers[indexMid];
}


int mininorder(int *numbers,int index1,int index2)
{
    int result=numbers[index1];
    for (int i=index1+1;i<=index2;i++)
    {
	if (result>numbers[i])
	    return numbers[i];
    }
    return result;
}
// method 2
// with case of {1,0,1,1,1}->{1,1,1,0,1}
int min(int *numbers,int length)
{
    if (numbers==NULL || length<=0)
	return ;

    int index1=0;
    int index2=length-1;
    int indexMid=index1;
    while (numbers[index1]>=numbers[index2])
    {
	if (index2-index1==1)
	{
	    indexMid=index2;
	    break;
	}
	indexMid=(index1+index2)/2;
  	// if index, index and indexMid are pointing same number-> only ordering from index=0 to index=4
 	if (numbers[index1]==numbers[index2] && numbers[index1]==numbers[indexMid])
	{
	    return mininorder(numbers,index1,index2);
	}

	if (numbers[indexMid]>=numbers[index1])
	    index1=indexMid;
 	else if(numbers[indexMid]<=numbers[index2])
	    index2=indexMid;

    }
    
    return numbers[indexMid];
}


int main(void)
{
    int arr[5]={3,4,5,2,3},arr1[5]={1,1,1,0,1},*numbers=NULL,*numbers1=NULL;
    int length=5;
    numbers=arr;
    numbers1=arr1;
    //printf("numbers[0] is %d\n",numbers[0]);
    
    printf("Original numbers are:");
    for (int i=0;i<length;i++)
    {
	printf("%d ",numbers[i]);
    }
    printf("\n");
    
    printf("Min number of arr is %d\n",Min(numbers,length));
    printf("Min number of arr1 is %d\n",min(numbers1,length));

    return 0;
}
