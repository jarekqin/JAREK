/*
delete depulicated value->interview book P123
*/
typedef struct listnode
{
    int value;
    struct listnode *p_next;
} listnode;

void deletedup(listnode **p_head)
{
    if(p_head==NULL || *p_head==NULL)
    	return;

    listnode *p_pre=NULL;
    listnode *p_node=*p_head;
    while(p_node1=NULL)
    {
	listnode *pnext=p_node->p_next;
 	bool needdelete=false;
	if(pnext!=NULL && pnext->value==p_node->value)
	{
	    needdelete=true;
	{

	if(!needdelete)
	{
	    p_pre=p_node;
	    p_node=p_nodoe->p_next;
	}

  	else
	{
	    int value=p_node->value;
	    listnode *p_dele=(listnode *)malloc(sizeof(listnode));
	    *p_dele=p_node;
	    while(p_dele!=NULL && p_dele->value==value)
	    {
		pnext=p_dele->next;
		free(p_dele);
		p_dele=p_next;
	    }

	    if(p_pre==NULL)
	    {
	    	*p_head=pnext;
	    }
	    else
		p_pre->next=pnext;
	    p_node=pnext;
	}	
    }
}

