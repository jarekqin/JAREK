/*
Faibonacci array
*/

//Q1 using di gui--too slowly works as complication ot time is longN times to increase
long long Fibonacci(unsigned int n)
{
    if (n<=0)
    {
	return 0;
    }

    else if (n==1)
    {
	return 1;
    }
 
    else
    {
	return Fibonacci(n-1)+Fibonacci(n-2);
    }
}


//Q2-using circle 
long long Fibonacci(unsigned n)
{
    int result[2]={0,1};
    if (n<2)
    {
	return result[n];
    }

    long long fibNMinusOne=1;
    long long fibNMinusTwo=0;
    long long fibN=0;
    for (unsigned int i=2;i<=n;i++)
    {
	fibN=fibNMinusONe+fibNMinusTwo;
	fibNMinusTwo=fibNMinusOne;
	fibNMinusOne=fibN;
    }
    return fibN;
}
