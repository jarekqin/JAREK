/*
interveiw book P181
*/
#include <stdio.h>
#include <stdbool.h>

bool verifysquenceofbst(int sequence[],int length)
{
    if(sequence==NULL || length<=0)
	return false;

    int root=sequence[length-1];
    // in binomimal tree->left value shoule be smaller than both root and right 
    int i=0
    for(;i<length-1;++i)
    {
	if(sequence[i]>root)
	    break;
    }

    // same theropy for right node
    int j=i;
    for (;,j<length-1;++j)
    {
	if(sequence[j]<root)
	    return false;
    }

    // verify left node is binomial tree or not
    bool left=true;
    if(i>0)
	left=verifysequenceofbst(sequence,i);
    // for right node
    right=true;
    if(j>0)
 	right=verifysequenceofbst(sequence+i,length-i-1);

    return (left && right)
}
