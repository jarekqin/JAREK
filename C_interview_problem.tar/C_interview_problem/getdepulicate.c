/*
second case for depulicated numbers:
For example: we have arr[]={2,3,5,4,3,2,6,7}. We find that this array length is 8, and all members are at 1-7 section. So we find its middle number 4 that deviding array into 2 part: left is 1-4, right is 5-7. We are going to use "er fen fa" that if left total amounts of number >4 means that this section has depulicated number. Same to right side.Next, we also separate left side also into 2 part, doing same procedure to this part until find one depulicated number.It will take O(n) times, O(long n) using function times, totalcomplication time is O(n long n), as well as space complication is O(1).
*/
int getDupulication(const *numbers,int length)
{
    if (number==NULL || length<=0)
    {
	return false;
    }

    int start=1,end=length-1;
    while(end>=start)
    {
	int middle=((end-start)>>1)+start;
	int count=countRange(numbers,length,start,middle);
	if(end==start)
	{
	    if(count>1)
		return start;
	    else
		break;
	}

   	if(count>(middle-start+1))
	{
	    end=middle;
	}
	else
	{
	    start=middle+1;
	}

    }
    
    return -1;
}

int countRange(const int *numbers,int length,int start, int end)
{
    if (numbers==NULL)
    {
	return 0;
    }

    int count=0;
    for (int i=0;i<length;i++)
    {
	if(numbers[i]>=start && numbers[i]<=end)
	     count++;
    }
    return count;
}
