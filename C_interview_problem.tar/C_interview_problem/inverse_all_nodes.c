/*
inverse all nodes of a chain table-> P143
*/
struct listnode
{
    int value;
    struct listnode *next;
} listnode;


listnode *reverselist(listnode *p_head)
{
    listnode *p_rhead=NULL;
    listnode *p_node=p_head;
    listnode *p_prev=NULL;
    
    while (p_node!=NULL)
    {
 	listnode *p_next=p_node->next;
	if(p_next==NULL)
	    p_rhead=p_node;
	p_node->next=p_prev;
	
	p_pre=p_node;
	p_node=p_next;
    }
    return p_rhead;
}
