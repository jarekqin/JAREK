/*
tree mirror finding case -> interview book ->P157
*/
#include <stdbool.h>
typedef struct binarynode
{
    int value;
    binarynode *left;
    binarynode *right;
} binarynode;



// must plot first, then change left and right with from top to bottom
void mirrorfinding(binarynode *p_node)
{
    if(p_node==NULL)
	return;

    if(p_node->left==NULL && p_node->right=NULL)
	return;

    binarynode *p_temp=p_node->left;

    p_node->left=p_node->right;
    p_node->right=ptemp;
   
    if(p_node->left)
	mirrorfinding(p_node->left);

    if(p_node->right)
	mirrorfinding(p_node->right);
}

