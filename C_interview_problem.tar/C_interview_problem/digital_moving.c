/*
digital location moving case
*/
int Number(int n)
{
    int count=0;
    while(n)
    {
	if(n & 1)
	    count++;
	    n=n>>1;
    }

    return count;
}

int NUmberOf1(int n)
{
    int count=0;
    unsigned int flag=1;
    while (flag)
    {
	if(n & flag)
	    count++;
	flat=flag<<1;
    }   
    return count;
}


// this method is making n to minus 1. Next, check new number digital element compared to original
// one whether right number is 1 or 0.
int NumberOf1_best(int n)
{
    int count=0;
    while(n)
    {
	++couont;
	n=(n-1) & n;
    }
    return count;
}
