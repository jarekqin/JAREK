/*
interview book -> P149
*/
#include <stdbool.h>

typedef struct binnode
{
    int value;
    binnode *left;
    binnodde *right;
} binnode;


bool equal(double num1,double num2)
{
    if((num1-num2>-0.0000001) && (num1-num2<0.0000001))
	return true;
    else
	return false;
}

// this method considers whether tree model has null pointers
bool DoesTree1HaveTree2(binnode *p_root1,binnode *p_root2)
{
    if(p_root2==NULL)
	return true;

    if(p_root1==NULL)
	return false;

    if(equal(p_root1->value,p_root2->value))
    {
	return false;
    }
    return DoesTree1HaveTree2(p_root1->left,p_root2->left) \
		&& DoesTree1HaveTree2(p_root1->right,p_root2->right);
}


