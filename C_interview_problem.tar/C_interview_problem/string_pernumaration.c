/*
interview book P198
*/
void permutation(char *p)
{
    if(p==NULL)
	return;

    permutation(p,p);
}


void permutation(char *p,char *p_b)
{
    if(*p_b=='0')
	printf("%s\n",p);

    else
    {
	for(char *pch=p_b;*pch!='\0';+=pch)
	{	
	    char temp=*pch;
	    *pch=*p_b;
	    *p_b=temp;

	    permutaiton(p,p-b+1);
	    temp=*pch;
	    *pch=*p_b;
	    *p_b=temp;
	}
    }
}
