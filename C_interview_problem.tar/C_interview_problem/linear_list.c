/*
linear_list
*/
#include <stdio.h>
#include <stdlib.h>
#define LIST_INIT_SIZE 100
#define LISTINCREMENT 10// linear_list incremental amount
typedef struct
{
    int *elem;
    int length;
    int listsize;
} sqlist;

void init(sqlist *l)
{
    l->elem=(int *)malloc(sizeof(int)*LIST_INIT_SIZE);
    if (!l->elem)
	exit(EXIT_FAILURE);
    l->length=0;
    l->listsize=LIST_INIT_SIZE;
}

void insert(sqlist *l,int i,int e)
{
    // insert value into l[i]
    if(i<1 || i>l->length+1)
	return;
    if(l->length>=l->listsize)
    {
	int *newbase=(int *)realloc(l->elem,(l->listsize+LISTINCREMENT)*sizeof(int));
	if(!newbase)
	    exit(EXIT_FAILURE);
	l->elem=*newbase;
	l->listsize+=LISTINCREMENT;
    }

    int *q=&(l->elem[i-1],p=0;
    for(p=&(l->elem[l->length-1]);p>=q;--p)
	*(p+1)=*p;

    *q=e;
    ++(l->length);
}

void delete(sqlist *l,int i, int *e)
{
    if((i<1) || (i>l->length))
	return;
    int *p=NULL,q=0;
    p=&(l->elem[i-1]);
    e=p;
    q=l->elem+l->length-1;
    for (++p;(*p)<=q;++p)
	*(p-1)=*p;
    --(l->length);
    
}


// compare 2 numbers are same or not
int locate_sq(sqlist l,int e,Status (*compare)(int,int))
{
    int i=1;
    int *p=l->elem;
    while(i<=l->length && !(*compare) (*p++,e))
	i++;
    if(i<=l->length)
	return 1;
    else
	return 0;
}


void merge_sq(sqlist la,sqlist,lb,sqlist *lc)
{
    int *pa=la.elem,*pb=lb.elem;
    lc->listsize=lc->length=la.length+lb.length;
    int *pc==lc->elem=(int *)malloc(lc->listsize*sizeof(int));
    
    if(!lc->elem)
	exit(OVERFLOW);

    int pa_last=la.elem+la.length-1;
    int pb_last=lb.elem+lb.length-1;

    while(*pa<=pa_last && *pb<=pb_last)
    {
	if(*pa<=*pb)
	    *pc++=*pa++;
	else
	    *pc++=*pb++;
    }	

    while (*pa<=pa_last)
	*pc++=*pa++;

    while (*pb<=pb_last)
	*pc++=*pb++;
}
