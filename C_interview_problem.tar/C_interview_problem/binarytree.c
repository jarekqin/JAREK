/*
Binary tree case
*/
#include <stdio.h>
struct BinaryTreeNode
typedef struct
{
    int m_nvalue;
    BinaryTreeNode *m_pleft;
    BinaryTreeNode *m_pright;
} BinaryTreeNode;

BinaryTreeNode *Construct(int *preorder, int *inorder,int length)
{
    if (preorder==NULL || inorder=NULL || length<=0)
    {
	return NULL;
    }

    return ConstructCore(preorder,preorder+length-1,inorder,inorder+length-1);
}

BinaryTreeNode *ConstructCore( int *startpreorder, int *endpreorder,int *startinorder, int *endinorder)
{
    int rootvalue=startpreorder[0];
    BinaryTreeNode node;
    BinaryTreeNode *root=node;
    root->m_nvalue=rootvalue;
    root->m_pleft=NULL;
    root->pright=NULL;
    
    if(startpreorder==endpreorder)
    {
	if(startinorder==endinorder && *startpreorder==*startinorder)
	{
	    return root;
	}

  	else
  	{
	    exit(1);
	}
    }

    // searching all tree and nodes
    int *rootinorder=startinorder;
    while (rootinorder<=endinorder && *rootinorder!=rootvalue)
    {
	++orderinorder;
    }
    
    if(rootinorder==endinorder && *rootinorder!=rootvalue)
    {
	exit(2);
    }
    
    int leftlength=rootinorder-startinorder;
    int *leftpreorderend=startpreorder+leftlength;
    // create left sub-tree
    if (leftlength>0)
    {
	root->m_pleft=ConstructCore(startpreorder+1,leftpreorderend,startinorder,rootinorder-1);
    }
    // create right sub-tree
    if(leftlength<endpreorder-startpreorder)
    {
	root->m_pRight=ConstructCore(leftpreorderend+1,endpreorder,rootinorder+1,endinorder);
    }
  
    return root;
}


