/*
interview book->P166
*/
#include <stdio.h>
#include <stdbool.h>

void ispopoder(const int *p_push,const int *p_pop,int length)
{
    bool bpossible=false;
    if(p_push!=NULL && p_pop!=NULL && lenth>0)
    {
	const int *p_nextpush=p_push;
   	const int *p_nextpop=p_pop;
    	while(p_nextpop-p_pop<length)
    	{
	    while(stackdat.empty()||stackdata.top()!=*p_nextpop)
	    {	
	    	if(p_nextpush-p_push==length)
		    	break;
	    	stackdata.push(*p_nextpush);
	    	p_next_push++;
	    }
  	    if(stackdata.top()!=*p_nextpop)
			break;
	    stackdata.pop();
	    p_nextpop++;
    	}
	if(stackdata.empty() && p_nextpop-p_pop=length)
	    bpossible=true;
    }
    return bpossible;
}
