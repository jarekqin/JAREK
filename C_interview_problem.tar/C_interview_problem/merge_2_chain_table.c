/*
merge 2 chain table -> P147
*/

struct listnode
{
    int value;
    listnode *next;
} listnode;

listnode *merge(listnode *p_head1,listnode *p_head2)
{
    if(p_head1==NULL)
	return p_head2;
    else if (p_head2==NULL)
	return p_head1;

    listnode *p_mhead=NULL;

    if(p_head1->value<p_head2->value)
    {
	p_mhead=p_head1;
	p_mhead->next=merge(p_head1->next,p_head2);
    }

    else
    {
	p_mhead=p_head2;
	p_mhead->next=merge(p_head1,p_head2->next);
    }

    return p_mhead;
}
