/*
depulicate function by C
*/
bool deplicate(int numbers[],int length, int *dulication)
{
    if(numbers==NULL || length<=)
    {
	return false;
    }

    for (int i=0;i<length;++i)
    {
 	if(numbers[i]<0 || numbers[i]>length-1)
	    return false;
    }

    int count=0;
    for (int i=0;i<length;++i)
    {
	while (numbers[i]!=i)
	{
	    if(numbers[i]==numbers[numbers[i]])
		*depulication=numbers[i];
		count++;
	  	printf("Depulicated number is %d and we are now have %d numbers appearing in this array\n",*depulication,count);
	}

	int tmp=numbers[i];
 	numbers[i]=numbers[tmp];
  	numbers[tmp]=tmp;
    }  
    
    return true;
}
// For example: arr[]={2,3,1,0,2,5,3},we don't know how many depulicated numbers are in this array. PLease fnd a function that can randomly choose one depulicated number to us without any specified number.
