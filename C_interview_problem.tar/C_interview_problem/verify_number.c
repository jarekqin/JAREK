/*
verify string is number or not->book P127

number formula=A[.[B]] .B[e|EC] [e|EC]
*/
bool isnumber(const char *str)
{
    if(str==NULL)
	return false;
    
    bool numeric=scanInteger(&str);
    if (*str=='.')
    {
	++str;
  	numeric=scanunsignedinteger(&str) || numberic;
	// why uses ||
	// if 1. digital part doesn't have integer->0.123=.123
	// if 2. digital part no number ->233. =233.0
	// if 3. both have number -> 233.666
    }

    // if there is appearing 'e' or 'E'
    if (*str=='e' || *str=='E')
    {
	++str;
	// if 1. when E or e there is no number previous: whole string is not number->e1,E1
	// if 2. when e or E there is no integer after: whole string is not number ->12e, 12E+5.4
	numeric=numeric && scaninteger(&str);
    }

    return numeric && *str=='\0';
}

bool scanunsignedinteger(const char *str)
{
    const char *before=*str;
    while(**str!='\0' && **str>='0' && **str<='9')
	++(*str);
    // return true if str includes several 0-9 number strings
    return &str>before;
}

bool scaninteger(const char **str)
{
    if(**str=='+' || **str=='-')
	++(*str);
    // scan string does have '+' or '-'
    return scanunsignedinteger(str)
}
}
