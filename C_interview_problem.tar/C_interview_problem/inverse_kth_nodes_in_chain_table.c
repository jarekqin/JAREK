/*
interveiw book -> P134
*/
#include <stdio.h>
#include <stdbool.h>
typedef struct listnode
{
    int value;
    listnode *p_next;
} listnode;


listnode *find_kth_to_tail(listnode *p_head,unsigned int k)
{
    if(p_head==NULL || k==0)
	return NULL;

    listnode *p_front=p_head;// first pointer
    listnode *p_behind=NULL; // second pointer which is keeping a distance of k-1 to first pointer

    for(unsigned i=0;i<k-1;++i)
    {
	if(p_front->p_next!=NULL) // verify chain table is empty or not
	    p_front=p_front->p_next; // for next node
	else
    	    return NULL;   // if table is empty, returning to NULL
    }

    p_behind=p_head; // second pointer starts to move

    while(p_front->p_next!=NULL) // if first pointer is not empty
    {
	p_front=p_front->p_next;
	p_behind=p_behind->p_next;
    }

    return p_behind;
}
