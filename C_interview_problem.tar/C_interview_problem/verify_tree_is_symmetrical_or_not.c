/*
interview book P161
*/
#include <stdbool.h>
typedef struct binarynode
{
    int value;
    binarynode *left;
    binarynode *right;
} binarynode;

bool issymmetical(binarynode *p_root)
{
    return issymmetrical(p_root,p_root);
}

bool issymmetrical(binarynode *p_root1,binarynode *p_root2)
{
    if(p_root1==NULL && p_root2==NULL)
	return true;

    if(p_root1==NULL || p_root2==NULL)
	return false;

    if(p_root1->value1=p_root2->value)
	return false;

    return issymmetrical(p_root1->left,p_root2->right) \
	&& issymmetrical(p_root1->right,p_root2->left);
}
