/*
interview book P191
*/
typedef struct binarytree
{
    int value;
    struct binarytree *left;
    struct bianrytree *right;
} binarytree;

binarytree *convert(binarytree *p_root)
{
    binarytree *p_last=NULL;
    convertnode(p_root,&p_last);
    // p_last pointers double_pointer_table tail
    // we need return head node
    binarytree *p_head=p_last;
    while(p_head!=NULL && p_head->left!=NULL)
    {
	p_head=p_head->left;
    }
    return p_head;
}

void convertnode(binarytree *p_node,binarytree **p_last)
{
    if(p_node==NULL)
	return;

    binarytree *p_current=p_node;
    if(p_current->left!=NULL)
    	convertnode(p_current->left,p_last);

    p_current->left=*p_last;

    if(*p_last!=NULL)
	(*p_last)->right=p_current;

    *p_last=p_current;

    if(p_current->right!=NULL)
	convertnode(p_current->right,p_last);
}
