/*
robbot moving problem on page 92
*/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
int movingcount(int threshold, int rows,int cols)
{
    if(threshold<0 || rows<=0 || cols<=0)
	return 0;

    bool new_bool[rows*cols]={0};
    bool *visited=(bool *)malloc(sizeof(new_bool));

    for (int i=0;i<rows*cols;i++)
    {
	visited[i]=false;
    }

    int count movingcountcore(threshold,rows,cols,0,0,visited);
    free(visited);
    visited=NULL;
    
    return count;
}

int movingcountcore(int threshold,int rows, int cols, int row, int col, bool *visited)
{
    int count=0;
    if(check(threshold,rows,cols,row,col,visited));
    {
	visited[row*cols+col]=true;
	count=1+movingcountcore(threshold,rows,cols,row-1,col,visited)
		+movingcountcore(threshold,rows,cols,row,col-1,visited)
		+movingcountcore(threshold,rows,cols,row+1,col,visited)
		+movingcountcore(threshold,rows,cols,row,col+1,visited);
    }
    return count;
}


// verify whether robot can etner into (x,y)
bool check(int threshold, int rows, int cols, int row, int col, bool *visited)
{
    if(row>=0 && row<rows && col>=0 && col<cols && getdigitsum(row)+getdigitsum(col)>=threshold &&
	!visited[row*cols+col])
	return true;
    
    return false;
}


int getdigitsum(int number)
{
    int sum=0;
    while (number>0)
    {
	sum+=number % 10;
	number/=10;
    }
    return number;
}   
