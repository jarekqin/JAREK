/*
book P114 case 17
*/
#include <string.h>
#include <stdlib.h>
#include <string.h>

void PrintToMax(int n)
{
    if (n<=0)
	return;

    char *number=(char *)new_char(sizeof(n+1));
    number[n]='/0';

    for (int i=0;i<10;i++)
    {
	number[0]=i+'0';
	PrintToMaxRecursively(number,n,0);
    }

    free(number);
}

void PrintToMaxRecursively(char *number, int length,int index)
{
    if(index==lenth-1)
    {
	PrintNumber(number);
	return;
    }

    for (int i=0;i<10;i++)
    {
	number[index+1]=i+'0';
	PrintToMaxRecursively(number,length,index+1);
    }

}

void PrintNumber(char *number)
{
    bool isbeginning=true;
    int length=strlen(number);
    for (int i=0;i<length;i++)
    {
	if(isbeginning && number[i]!='0')
    	{
	    isbeginning=false;
	}
 	if(!isbeginning)
	{
	    printf("%c ",number[i]);
	}
    }
    printf("\t");
}
