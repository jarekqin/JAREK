/*
tan lan method to calculate rop cutting problem
*/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
int maxproductaftercutting_solution2(int length)
{
    
    if (length<2)
 	return 0;
    if (length==2)
	return 1;
    if (length==3)
	return 2;

     // let's cut down parts that is moroe than 3.
    int timesof3=length/3;
     // As 2*2>3*1->The best method is cutting down 2 parts for rope
    if(length-timeof3*3==1)
	timesof3-=1;

    int timesof2=(length-timesof3*3)/2;
    return (int) (pow(3,timesof3))*(int)(pow(2,timesof2));    
}
