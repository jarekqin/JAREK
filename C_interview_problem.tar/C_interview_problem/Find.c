/*
Find a number at a specified matrix with its row and column. We find that numbers are growing up for both rowsand columns. So we can choose either top right corner or bottom left corner as starting point. In this case, we choose top right one that has biggest number for a column. If 1st value of column > number given, then we therefore have to turn to left one column as next round finding.
*/
bool Find(int *marix, int rows, int columns, int number)
{
    bool found=false;

    if (matrix!=NULL && rows>0 && columns>0)
    {
	int row=0;
  	int column=columns-1;// we choose top right concer as start point
	while (row<rows && column>=0)
	{
	    if (matrix[row*columns+column]==number) // from right to left, and with column as one step
	    {
		found=true;
		break;
	    }
	    // if 1st number of a column is > number
	    else if(matrix[rows*columns+column]>number)
	    {
		--column; 
	    }
	    // if 1st number of a column is <number
	    else
		++row;
	}	
    }
   
    return found;
}
