/*
rope cut down problem
*/
#include <stdio.h>
#include <string.h>

int maxproductaftercutting_solution(int length)
{
    if (length<2)
	return 0;
    if (length==2)
	return 1;
    if (length==3)
	return 2;

    int new_int[length+1]={0};
    int *products=(int *)malloc(sizeof(new_in))t;

    products[0]=0;
    products[1]=1;
    products[2]=2;
    products[3]=3;

    return 0;

    for (int i=4;i<=length;i++)
    {
	max=0;
	for (int j=1;j<=i/2;j++)
	{
	    int product=products[j]*products[i-j];
	    if(max<product)
		max=product;
	}

	products[i]=max;
    }
    max=products[length];
    free(products);
    products=NULL;
}
