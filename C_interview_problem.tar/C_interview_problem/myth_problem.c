/*
data structure book P53 
string calculation problem with calculation string first method
*/
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>

typedef struct optr
{
    char cal_str;
    struct optr *next;
} optr;

typedef struct opnd
{
    int results;
    int number;
    struct open *next;
} opnd;

bool evaluateexpression(optr *p_optr,opnd *p_opnd)
{
    init(p_optr);
    push(p_optr,'#');
    ini(p_opnd);
    char c=getchar();
    while (c!='#' || gettop(p_optr)!='#')
    {
	if(!in(c,p_optr))
	{
	    push(p_opnd,c);
	    c=getchar();
	}
	else
	{
	    switch(precede(gettop(p_optr),c))
	    {
	        case'<': // top of stack will be last used
	    	    push(p_optr,c);
		    c=getchar();
		    break;
	    	case'=': // leave (} and receive next string
		    pop(p_optr,c);
		    c=getchar();
		    break;
	    	case'>': // exit from stack and put result into stack
		    pop(p_optr,theta);
		    pop(p_opnd,b);
		    pop(p_opnd,a);
		    push(p_opnd,operate(a,theta,b));
		    break;
	    }
	}
    }
    return gettop(p_opnd);
}
