/*
delete one node of chain table-interview book P120
*/
#include <stdlib.h>
typedef struct listnode
{
    int value;
    listnode *p_next;
} listnode;

void deletenode(listnode **p_head,listnode *p_delete)
{
    if(!p_head||!p_delete)
	return;

    // if deleted node is not rear node
    if(p_delete->p_next!=NULL)
    {
	list *pnext=(listnode *)malloc(sizeof(listnode));
	pnext=p_delete->p_next;
	p_delete->value=pnext->value;
	p_delete->p_next=pnext->p_next;

	free(pnext);
	pnext=NULL;
    }

    // if chain table has only 1 node, delete head-rear node
    else if(*p_head==p_delete)
    {
	free(p_delete);
  	p_delete=NULL;
	*p_head=NULL;
    }

    // if chain table has several nodes, delete rear node
    else
    {
	listnode *p_node=*p_head;
	while(p_node->p_next!=p_delete)
	{
	    p_node=p_node->p_next;
	}
	p_node->next=NULL;
	free(p_delete);
	p_delete=NULL;
    }
}
