/*
interview book P184
*/
typedef struct treenode
{
    int value;
    struct treenode *left;
    struct treenode *right;
} treenode;

void findpath(treenode *p_root,int expsum)
{
    if(p_root==NULL)
	return;
    
    std::vector<int> path;
    int currentsum=0;
    findpath(p_root,expsum,path,currentsum);
    currentsum+=p_root->value;
    path.push_back(p_root->value);

    // if node is leaf node, and sum=typed number on the path
    // print this path
    bool isleaf=p_root->left==NULL && p_root->right==NULL;
    if(currentsum==expsum && isleaf)
    {
	printf("A path is found:");
	std::vector<int>:: iterator iter=path.begin();
	for(;iter!=path.end();++iter)
 	    printf("%d\n",*iter);

	print("\n");
    }

    // if node is not leaf node, read all sub-nodes of this node
    if(p_root->left!=NULL)
   	findpath(p_root->left,expsum,path,currentsum);
    if(p_root->right!=NULL)
	findpath(p_root->right,expsum,path,currentsum);

    path.pop_back();
}
