/*
string location moving case
*/
void ReplaceBLank(char string[],int length)
{
    if (string==NULL || length==0)
  	return ;


    // originalLength is original length for sting
    int originalLength=0;
    int numberOfBlank=0;
    int i=0;
    while(string[i]!='\0')
    {
	+originalLength;
	if(string[i]==' ')
 	    ++numberOfBlank;

  	i++;
    }


    // change blank space with '%20' string

    int newLength=originalLength+numOfBlank*2;
    if (newLength>length)
	return ;

    int indexOfOriginal=originalLength;
    int indexOfNew=newLength;
    while(indexOfOriginal>=0 && indexOfNew>indexOfOriginal)
    {
	if(string[indexOfOriginal]==' ')
	{
	    string[indexOfNew--]='0';
	    string[indexOfNew--]='2';
	    string[indexOfNew--]='%';
	}

	else
	{
	    string[indexOfNew--]=string[indexOfOriginal];
	}
    	
	--indexOfOriginal;
    }
}
