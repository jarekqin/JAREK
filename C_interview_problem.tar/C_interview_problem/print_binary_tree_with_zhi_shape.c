/*
interveiw book P178
*/
#include <stdio.h>
typedef struct binarynode
{
    int value;
    binarynode *left;
    binarynode *right;
} binarynode;

void print(binarynode *p_root)
{
    if(p_root==NULL)
	return;

    std::stack<binarynode *>levels[2];
    int current=0;
    int next=1;
    levels[current].push(p_root); 


    while(!levels[0].empty() || !levels[1].empty())
    {
	binarynode *p_node=levels[current].top();
  	printf("%d",p_node->value);

   	if(current==0)
	{
	    if(p_node->left!=NULL)
		levels[next].push(p_node->left);
	    if(p_node->right!=NULL)
	    	levels[next].push(p_node->right);
	}
	else
	{
	   
	    if(p_node->right!=NULL)
		levels[next].push(p_node->left);
	    if(p_node->left!=NULL)
	    	levels[next].push(p_node->right);
	}

  	if(levels[current].empty())
	{
	    print("\n");
	    current=1-current;
	    next=1-next;
	}
    }
}
