/*
interview book P162
*/

#include <stdio.h>


void printmatrixincircle(int **numbers,int columns,int rows,int start)
{
    int endx=columns-1-start;
    int endy=rows-1-start;

    // print from left to right for 1 row
    for (int i=start;i<=endx;++i)
    {
	int number=numbers[start][i];
	printf(number);
    }
    // from top to bottom for 1 column
    if(start<endy)
    {
	for(int i=start+1;i<=eny;++i)
	{
	    int number=numbers[i][endx];
	    printf(number);
	}
    }

    // print from right to left for 1 row
    if(start<endx && start<endy)
    {
	for (int i=endx-1;i>=start;--i)
	{
	    int number=numbers[endy][i];
	    printf(number);
	}
    }

    // print from bottom to top for 1 column
    if(start<endx && start<endy-1)
    {
	for(int i=endy-1;i>=start+1;--i)
	{
	    int number=numbers[i][start];
	    prinf(number);
	}	
    }
}


void printmatrixclockwisely(int **numbers,int columns,int rows)
{
    if(numbers==NULL || columns<=0 || rows<=0)
	return;

    while(columns>start*2 && rows>start*2)
    {
	printmatrixincircle(numbers,columns,rows,start);
	++str;
    }

}
