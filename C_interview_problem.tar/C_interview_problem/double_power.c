/*
self function to show power function
*/
// Q1 do not consider speed of coding
bool g_invalidinput=false;

double Power(double base,int exponent)
{
    g_invalidinput=false;
    if(base==0.0 && exponent<0)
    {
	g_invalidinput=true;
	return 0.0
    }
    
    unsigned int absexponent=(unsigned int)exponent;
    if(exponent<0)
    {
	absexponent=(unsigned int)-exponent;
    }
    double result=PowerWithUnsignedExponent(base,absexponent);

    if(exponent<0)
	result=1/result;

    return result
}

double PowerWithUnsignedExponent(double base, unsigned int exponent)
{
    double result=0;
    for (int i=0;i<=exponent;i++)
    {
	result*=base;
    }

    return result;
}


// Q2 with double variable power method 
// book P112
double PowerWithUnsignedExponent(double base, unsigned int exponent)
{
    if(exponent==0)
	reurn 1;
    if(exponent==1)
	return base;

    double result=PowerWithUnsignedExponent(base,exponent>>1);
    result*=result;

    if(exponent & 0x1==1)
 	result*=base;

    return result;
}

