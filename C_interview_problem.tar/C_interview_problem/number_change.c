/*
number change ->interviewing book P130
*/
#include <stdio.h>
#include <stdbool.h>
// below function is good for freshman of IT
void recordoddeven(int *p_data,unsigned int length)
{
    if(p_data==NULL || length==0)
	return ;
	
    int *p_begin=p_data;
    int *p_end=*p_data+length-1;

    while(p_begin<p_end)
    {	
	while(p_begin<p_end && (*p_begin & 0x1)!=0)//verify number is add number or even number
	    // stop ++ until p_begin meets even number
	    p_begin++;

	while(p_begin<p_end && (*p_end & 0x1)==0)
	    p_end--;//stop -- until p_end meets odd number

  	if(p_begin<p_end)
	{
	    int *temp=*p_begin;
	    *p_begin=*p_end;
	    *p_end=temp;
	}
    }
}


// below function is good for offer

void recorder(int *p_data,unsigned int length,bool (* func)(int))
{
    if(p_data==NULL || length==0)
	return ;
	
    int *p_begin=p_data;
    int *p_end=*p_data+length-1;

    while(p_begin<p_end)
    {	
	while(p_begin<p_end && !func(*p_begin))//verify number is add number or even number
	    // stop ++ until p_begin meets even number
	    p_begin++;

	while(p_begin<p_end && func(*p_end))
	    p_end--;//stop -- until p_end meets odd number

  	if(p_begin<p_end)
	{
	    int *temp=*p_begin;
	    *p_begin=*p_end;
	    *p_end=temp;
	}
    }
}

bool isEven(int n)
{
    return (n & 1)==0;
}


void recorderoddeven(int *p_data,unsigned int length)
{
    redorder(p_data,length,isEven);
}
