/*
chain table functions
*/
#include <stdio.h>
typedef struct LIstNode
{
    int m_nValue;
    ListNode *m_pNext
} ListNode;

// adding a new node to the tail node
void AddToTail(ListNode **pHead,int value)
{ 
    ListNode node;
    ListNode *pNew=node;
    pNew->m_nValue=value;
    pNew->m_pNext=NULL;

    if (*pNew==NULL)
    {    
	*pHead=pNew;
    }

    else
    {
	ListNode *pNode=*pNew;

	while (pNode->m_pNext!=NULL)
	{
	    pNode=pNode->m_pNext;
	}
	
	pNode->m_pNext=pNew;
    }
}


void RemoveNode(ListNode ** pHead,int value)
{
    if (pHead==NULL||*pHead==NULL)
    {
	return ;
    }

    ListNode *pToBeDeleted=NULL;
    if ((*pHead)->m-nValue==value)
    {
	pToBeDeleted=*pHead;
	*pHead=(*pHead)->m_pNext;
    }

    else
    {
	ListNode *pNode=*pHead;
	while (pNode->m_pNext!=NULL && pNode->m_pNext->m_nValue!=value)
	{
	    pNode=pNode->m_pNext;
	}
 	
	if (pNode->m_pNext!=NULL && pNode->m_pNext->m_nValue==value)
	{
	    pToBeDeleted=pNode->m_pNext;
	    pNode->m_pNext=pNode->m_pNext->m_pNext;
	}
    }

    if(pToBeDeleted!=NULL)
    {
	delete pToBeDeleted;
	pToBeDeleted=NULL;
    }
}

// using zhan export chain table
void PrinntListReversingly_Iteratively(ListNode *pHead)
{
    ListNode *pNode=pHead;
    while(pNode!=NULL)
    {
	node.push(pNode);
	p_Node=pNode->m_pNext;
    }

    while (!nodes.empty())
    {
 	pNode=node.top();
	printf("%d\t",pNode->m_nValue);
	node.pop();
    }	
}

// di gui fangfa
void PrintListReversingly_Recurisively(ListNode *pHead)
{
    if (pHead!=NULL)
    {
	if(pHead->m_pNext!=NULL)
	{
	    PrintListReversingly_Recurisively(pHead->m_pNext);
	}
    }
    printf("%d\t",pHead->m_pNext);
}
