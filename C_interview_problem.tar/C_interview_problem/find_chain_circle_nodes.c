/*
interview book P140
*/
#include <stdio.h>
struct listnode
{
    int value;
    listnode *next;
} listnode;


// finding the node where slow and fast will meet each other.
listnode *meetingnode(listnode *p_head)
{
    if(p_head==NULL)
	return;
    listnode *p_slow=p_head->next;
    if(p_slow==NULL)
	return NULL;

    listnode *p_fast=p_slow->next;
    while(p_fast!=NULL && p_slow!=NULL)
    {
	if(p_fast==p_slow)
	    return p_fast;

 	p_slow=p_slow->next;

 	p_fast=p_fast->next;
	if(p_fast!=NULL)
	    p_fast=p_fast->next
    }
    return NULL;
}

// finding exit and entry nodes
listnode *entrynodeofloop(listnode *p_head)
{
    listnode *meetingnode=meetingnode(p_head);
    if(meetingnode==NULL)
	return NULL;

    // getting number of circle nodes
    int nodeinloop=1;
    listnode *p_node1=meetingnode;
    while(p_node1->next!=meetingnode)
    {
	p_node1=p_node1->next;
	++nodeinloop;
    }
    
    // first moving p_node1 ,number = nodes in circle
    p_node1=p_head;
    for (int i=0;i<nodeinloop;++i)
    {
	p_node1=p_node1->next;
    }


    // secondly moving p_node1 and p_node2

    listnode * p_node2=p_head;
    while (p_node1!=p_node2)
    {
	p_node1=p_node1->next;
	p_node2=p_node2->next;
    }
    return p_node1;    	
}
