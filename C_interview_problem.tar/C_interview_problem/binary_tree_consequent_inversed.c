/*
interveiw book P1951
*/
typedef struct binarytree
{
    int value;
    struct binarytree *left;
    struct binarytree *right;
} binarytree;

void serialize(binarytree *p_root, ostream& stream)
{
    if(p_root==NULL)
    {
	stream<<"$,";
	return;
    }
    stream<<p_root->value<<',';
    serialize(p_root->left,stream);
    serialize(p_root->right,stream);
}

void deserialize(binarytree **p_root,istream& stream)
{
    int number;
    if(readstream(stream,&number))
    {
	*p_root=new BinaryTreeNOde();
	(*p_root)->value=number;
	(*p_root)->left=NULL;
 	(*p_root)->right=NULL;

	deserialize(&((*p_root)->left),stream);
	deserialize(&((*p_root)->right),stream);
    }
}
