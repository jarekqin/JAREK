/*
interview book P187
*/
typedef struct complexlistnode
{
    int value;
    struct complexlistnode *next;
    struct complexlistnode *sibling;
}complexlistnode;

// copy original nodes to a node', and node will link to node'
void clonenodes(complexlistnode *p_head)
{
    complexlistnode *p_node=p_head;
    while(p_node!=NULL)
    {
	complexlistnode *p_cloned=new_complexlistnode();
  	p_cloned->value=p_node->value;
  	p_cloned->next=p_node->next;
	p_cloned->sibling=NULL;

	p_node->value=p_cloned;
	p_node=p_cloned->next;
    }
}

// set up another pointer path that original paht has
void connectsiblingnodes(complexlistnode *p_head)
{
    complexlistnode *p_node=p_head;
    while(p_node !=NULL)
    {
	complexlistnode *p_cloned=p_node->next;
	if(p_node->sibling!=NULL)
	    p_cloned->sibling=p_node->siblingn->next;
	p_node=p_cloned->next;
    }
}

// add location is original chain table, event location is copies table
complexlistnode *reconnectnodes(complexlistnode *p_head)
{
    complexlistnode *p_node=p_head;
    complexlistnode *p_clonedhead=NULL;
    complexlistnode *p_clonednode=NULL;

    if(p_node!=NULL)
    {
	p_clonedhead=p_clonednode=p_node->next;
	p_node->next=p_clonednode->next;
	p_node=p_node->next;
    }

    while(p_node!=NULL)
    {
	p_clonednode->next=p_node->next;
	p_clonednode=pclonednode->next;
	p_node->next=p_clonednode->next;
	p_node=p_node->next;
    }
    return p_clonedhead;
}

complexlistnode *clone(complexlistnode *p_head)
{
    clonenodes(p_head);
    connectsiblingnodex(p_head);
    return reconnectnodes(p_head);
}   
