/*
chain table
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct
{
    char key[10];
    char name[20];
    int age;
} DATA;

typedef struct node
{
    DATA data;
    struct node *next;
} cltype;

// insert new node to the last node
cltype *claddend(cltype *head, DATA d)
{
    cltype *node,*temp;
    if(!(node=(cltype *)malloc(sizeof(cltype))))
    {	
	printf("Wrong!\n");
	return NULL;
    }
    else
    {
	node->data=d;
	node->next=NULL;
	if(head==NULL)
	{
	    head=node;
	    return head;
	}

	temp=head;
	while(temp->next!=NULL)
	{
	    temp=temp->next;
	}
  	temp->next=node;
	return head;
    }
}

// insert head node
cltype *claddfirst(cltype *head,DATA d)
{
    cltype *node;
    if(!(node=(cltype *)malloc(sizeof(cltype))))
    {
	printf("Wrong!\n");
	return NULL;
    }
    else
    {
	node->data=d;
	node->next=head;
	head=node;
	return head;
    }
}

// search node with key word
cltype *clfindnode(cltype *head, char *key)
{
    cltype *temp;
    temp=head;

    while(temp)
    {
	if(strcmp(temp->data.key,key)==0)
	    return temp;
    	temp=temp->next;
    }
    return NULL;
}

// insert node in any location
cltype *clinsertnode(cltype *head,char *findkey,DATA d)
{
    cltype *node,*temp;
    if(!(node=(cltype *)malloc(sizeof(cltype))))
    {
	printf("Wrong!\n");
	return 0;
    }
    node->data=d;
    node->next=NULL;
    temp=clfindnode(head,findkey);
    
    if(temp)
    {
	node->next=temp->next;
	temp->next=node;
    }
  
    else
    {
	printf("No node found!\n");
	free(node);	
    }
    return head;
}

// delete node
int cldeletenode(cltype *head,char *key)
{
    cltype *node,*temp;
    temp=head;
    node=head;

    while(temp)
    {
	if(strcmp(temp->data.key,key)==0)
	{
	    node->next=temp->next;
	    free(temp);
	    return 1;
	}

    	else
    	{
	    node=temp;
	    temp=temp->next;
    	}
    }
    return 0;
}

// calculate length of chain table
int cllength(cltype *head)
{
    cltype *temp;
    int len=0;
    temp=head;
    while(temp)
    {
	len++;
	temp=temp->next;
    }
    return len;
}


// show all nodes
void clallnode(cltype *head)
{
    cltype *temp;
    DATA data;
    temp=head;
    printf("This chain table has %d nodes. Data as below:\n",cllength(head));
    while(temp)
    {
	data=temp->data;
	printf("node (%s,%s,%d)\n",data.key,data.name,data.age);
	temp=temp->next;
    }
}

int main(void)
{
    cltype *node,*head=NULL;
    DATA nodedata;
    char key[10],findkey[10];

    printf("Chain table test. Please type data, formula as: key,name,age\n");
    do
    {
	fflush(stdin);
	scanf("%s",&nodedata.key);
	if(strcmp(nodedata.key,"0")==0)
	    break;
	else
	{
	    scanf("%s%d",&nodedata.name,&nodedata.age);
	    head=claddend(head,nodedata);
	}
    }while(1);
    clallnode(head);

    printf("\n add new nonde,type inserted key words: ");
    scanf("%s",&findkey);
    printf("type inform for inserted node(key,name,age):");
    scanf("%s%s%d",&nodedata.key,&nodedata.name,&nodedata.age);
    head=clinsertnode(head,findkey,nodedata);
    clallnode(head);

    printf("\n delete node, type key word: ");
    fflush(stdin);
    scanf("%s",key);
    cldeletenode(head,key);
    clallnode(head);

   printf("\n find node, type key word: ");
    fflush(stdin);
    scanf("%s",&key);
    node=clfindnode(head,key);
    if(node)
    {
	nodedata=node->data;
	printf("key %s is matched to node (%s %s %d)\n",key,nodedata.key,nodedata.name,nodedata.age);
    }
    else
    {
	printf("No matched node of %s found in this chain table!\n",key);
    }
    
    return 0;
}
