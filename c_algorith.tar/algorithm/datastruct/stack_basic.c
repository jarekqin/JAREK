/*
stack basic struct
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAXLEN 50
#define SIZE 10

typedef struct
{
    char name[10];
    int age;
} DATA;

typedef struct stack
{ 
    DATA data[SIZE+1];
    int top;
} stacktype;

// initialisation
stacktype *stinit()
{
    stacktype *p;
    if(p=(stacktype *)malloc(sizeof(stacktype)))
    {
	p->top=0;
	return p;
    }
    return NULL;
}


// modify empty
int stisempty(stacktype *s)
{
    int t;
    t=(s->top==0);
    return t;
}

// modify full or not
int stisfull(stacktype *s)
{
    int t;
    t=(s->top==MAXLEN);
    return t;
}

// release space
void stfree(stacktype *s)
{
    if(s)
	free(s);
}

// clean stack
void stclear(stacktype *s)
{   
    s->top=0;
}

// push
int pushst(stacktype *s,DATA data)
{
    if((s->top+1)>MAXLEN)
    {
	printf("Full\n");
	return 0;
    }
    s->data[++s->top]=data;
    return 1;
}


// pop
DATA popst(stacktype *s)
{
    if(s->top==0)
    {
	printf("No element!\n");
	exit(0);
    }

    return (s->data[s->top--]);
}

// read node
DATA peekst(stacktype *s)
{
    if(s->top==0)
    {
	printf("No elements!\n");
	exit(0);
    }
    return (s->data[s->top]);
}


int main(void)
{
    stacktype *stack;
    DATA data,data1;

    stack=stinit();
    printf("Into Stack; \n");
    printf("Please type name,age!");
    do
    {
	scanf("%s%d",&data.name,&data.age);
	if(strcmp(data.name,"0")==0)
	{
	    break;
	}
	else
 	{
	    pushst(stack,data);
	}
    }while(1);

    do
    {
	printf("\n Pop element from stack:");
	getchar();
	data1=popst(stack);
	printf("popped element is(%s %d)\n",data1.name,data1.age);
    }while(1);

    stfree(stack);


    return 0;
}

  
