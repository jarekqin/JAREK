/*
tree test
*/
#include <stdio.h>
#include "06bio.h"

void print_cb(int num)
{
    printf("%d ",num);
}


int main(void)
{
    tree tr={0};
    tree_init(&tr);
    
    // tree shoule be created from top to bottom with root first, left 2nd, right 3rd
    tree_insert_in_order(&tr,40);
    tree_insert_in_order(&tr,20);
    tree_insert_in_order(&tr,70);
    tree_insert_in_order(&tr,55);
    tree_insert_in_order(&tr,81);
    tree_insert_in_order(&tr,76);
    tree_insert_in_order(&tr,90);
    tree_insert_in_order(&tr,84);
    
    printf("Tree has %d rows\n",tree_deep(&tr));

    tree_remove(&tr,70);
    tree_remove(&tr,90); 
    // showing number on the screen from small ones to biggers
    tree_miter(&tr,print_cb);
    printf("\n");
    
    printf("After delete, tree has %d rows\n",tree_deep(&tr));

    tree_deinit(&tr);
    return 0;
}
