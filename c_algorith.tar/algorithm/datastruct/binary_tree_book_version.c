/*
binary tree for data struct book P61
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MANLEN 20
typedef char DATA;
typedef struct CBT
{
    DATA data;
    struct CBT *left;
    struct CBT *right;
} cbttype;

// initialisation tree
cbttype *inittree()
{
    cbttype *node;
    if(node=(cbttype *)malloc(sizeof(cbttype)))
    {
	printf("PLease type a root node data:\n");
 	scanf("%s",&node->data);
   	node->left=NULL;
	node->right=NULL;

	if(node!=NULL)
	    return node;

	else
	    return NULL;
    }
    return NULL;
}


// add nodes
void addtreenode(cbttype *treenode)
{
    cbttype *p_node,*parent;
    DATA data;
    char menusel;

    if(p_node=(cbttype *)malloc(sizeof(cbttype)))
    {	
	printf("Type binary tree node:\n");
	fflush(stdin);
	scanf("%s",&p_node->data);
	p_node->left=NULL;
	p_node->right=NULL;
 	
	printf("Type father node data:");
 	fflush(stdin);
	scanf("%s",&data);
 	parent=treefinnode(treenode,data);
	
	if(!parent)
	{
	    printf("cannot find father node!\n");
	    free(p_node);
	    p_node=NULL;
	    return;
	}

   	printf("1.Add this node to left\n2. Add this node to right\n");
	do
	{
	    menusel=getchar();
	    menusel-='0';
	    if(menusel==1 || menusel==2)
	    {	
		if(parent==NULL)
		    printf("No father node,please set father first!\n");
	    }
	    	else
		{
		    switch(menusel)
		    {
			case 1:
			{
			    if(parent->left)
				printf("Left has node yet!\n");
			    else
				parent->left=p_node;
			    break;
			}
			case 2:
			{
			    if(parent->right)
				printf("Right has node yet!\n");
			    else
				parent->right=p_node;
			    break;
			}
			default:
			    printf("Unvailable variable!\n");
		    }  
		}
	} while(menusel!=1 && menusel!=2)
    }
}

// find node
cbttype *treefindnode(cbttype *treenode,DATA data)
{
    cbttype *ptr;
    if(treenode==NULL)
    {
	return NULL;
    }

    else
    {
	if(treenode->data==data)
	    return data;
	else
	{
	    if(ptr=treefindnode(treenode->left,data))
	    	return ptr;
	    else if(ptr=treefindnode(treenode->right,data))
	  	return ptr;
	    else
		return NULL;
   	}
    }
}


// get left node
cbttype *treeleftnode(cbttype *treenode)
{
    if(treenode)
	return treenode->left;
    else
	return NULL;
}


// get right node
cbttype *treerightnode(cbttype *treenode)
{
    if(treenode)
	return treenode->right;
    else
	return NULL;
}
// left and right node function variable is a parent node's value

// get length of tree
int treedepth(bcttype *treenode)
{
    int depleft,depright;

    if(treenode==NULL)
	return 0;

    else
    {
	depleft=treedepth(treenode->left);
	depright=treedepth(treenode->right);
	if(depleft>depright)
	    return depleft+1;
	else
	    return depright+1;
    }
}

// clear tree
void cleartree(cbttype *treenode)
{
    if(treenode)
    {
	cleartree(treenode->left);
	cleartree(treenode->right);
	free(treenode);
	treenode=NULL;
    }
}

// show node
void treenodedata(cbttype *p_node)
{
    printf("%c",p_node->data);
}


// bian li tree
// Q1 accroding to level
void leveltree(cbttype *treenode,void (*treenodedata) (cbttype *p))
{
    cbttype *p;
    cbttype 8q[MANLEN];
    int head=0,tail=0;

    if(treenode)
    {
	tail=(tail+1)%MANLEN // calculate tail index
	q[tail]=treenode;
    }
    while(head!=tail)
    {
	head=(head+1) % MANLEN;
	p=q[head];
	treenodedata(p);

	if(p->left!=NULL)
	{
	    tail=(tail+1) % MANLEN;
	    q[tail]=p->left; // left tree pointer insert seque
	}
 
	if(p->right!=NULL)
	{
	    tail=(tail+1) % MANLEN;
	    q[tail]=->p->right;
	}
    }
}

// first bianli
void dlrtree(cbttype *treenode,void (*treenodedata)(cbttype *p))
{
    if(treenode)
    {
	treenodedata(treenode);
	dlrtree(treenode->left,treenodedata);
	dlrtree(treenode->right,treenodedata);
    }
}

// middle bianli
void ldrtree(cbttype *treenode, void (*treenodedata) (cbttype *p))
{
    if(treenode)
    {
	ldrtree(treenode->left,treenodedata);
	treenodedata(treenode);
	ldrtree(treenode->right,treenodedata);
    }
}

// last bianli
void lrdtree(cbttype *treenode, void (*treenodedata) (cbttype *p))
{
    if(treenode)
    {
	lrdtree(treenode->left,treenodedata);
	lrdtree(treenode->right,treenodedata);
	treenodedata(treenode);
    }
}


