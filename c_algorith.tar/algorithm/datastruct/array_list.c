/*
array list
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define QUEUELEN 15

typedef struct
{
    char name[10];
    int age;
} DATA;

typedef struct
{
    DATA data[QUEUELEN];
    int head;
    int tail;
}sqtype;

// initialisation
sqtype *sqtypeinit()
{
    sqtype *q;

    if(q=(sqtype *)malloc(sizeof(sqtype)))
    {
	q->head=0;
	q->tail=0;
	return q;
    }
    else
	return NULL;
}

// empty
int sqtypeisempty(sqtype *q)
{
    int temp;
    temp=q->head==q->tail;
    return (temp);
}

// full
int sqtypefull(sqtype *q)
{
    int temp;
    temp=q->tail==QUEUELEN;
    return (temp);
}

// clean
void sqtypeclear(sqtype *q)
{
    q->head=0;
    q->tail=0;
}


// release space
void sqtypefree(sqtype *q)
{
    if(q!=NULL)
    {
	free(q);
	q=NULL;
    }
}


// insert
int insqtype(sqtype *q,DATA data)
{
    if(q->tail==QUEUELEN)
    {
	printf("List has been full!\n");
 	return 0;
    }

    else
    {
	q->data[q->tail++]=data;
 	return 1;
    }
}

// take node out
DATA *outsqtype(sqtype *q)
{
    if(q->head==q->tail)
    {
	printf("List has beem cleaned!\n");
	exit (0);
    }

    else
	return &(q->data[q->head++]);
}

// read node
DATA *peeksqtype(sqtype *q)
{
    if(sqtypeisempty(q))
    {
	printf("\n empty list\n");
	return NULL;
    }

    else
    	return &(q->data[q->head]);
}


// calculate length of list
int sqtypelen(sqtype *q)
{
    int temp;
    temp=q->tail-q->head;
    return (temp);
}


int main(void)
{
    sqtype *stack;
    DATA data;
    DATA *data1;

    stack=sqtypeinit();
    printf("Insert element into list: \n");
    printf("Please type name and age: \n");

    do
    {
	scanf("%s %d",&data.name,&data.age);
   	if(strcmp(data.name,"0")==0)
  	{
	    break;
	}

  	else
 	{
	    insqtype(stack,data);
	}

    }while(1);


    do
    {
	printf("Take nodes out: Pressing any key!:\n");
	getchar();
	data1=outsqtype(stack);
 	printf("Data taken out are:(%s,%d)/n",data1->name,data1->age);
    } while(1);

    sqtypefree(stack);


    return 0;
}
