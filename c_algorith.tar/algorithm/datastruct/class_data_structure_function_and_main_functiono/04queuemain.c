/*
queue test
*/
#include <stdio.h>
#include "04queue.h"

int main(void)
{
    queue que={0};

    queue_init(&que);
    printf("Full result is %d\n",queue_full(&que));
    printf("Empty result is %d\n",queue_empty(&que));
    printf("There are %d numbers\n",queue_size(&que));
    
    queue_push(&que,4);
    queue_push(&que,11);
    queue_push(&que,23);
    queue_push(&que,31);
    queue_push(&que,42);
    queue_push(&que,55);

    printf("Full result is %d\n",queue_full(&que));
    printf("Empty result is %d\n",queue_empty(&que));
    printf("There are %d numbers\n",queue_size(&que));
    printf("Initial number is %d\n",queue_front(&que));
    printf("%d ",queue_pop(&que));
    printf("%d ",queue_pop(&que));
    printf("%d\n",queue_pop(&que));

    printf("Full result is %d\n",queue_full(&que));
    printf("Empty result is %d\n",queue_empty(&que));
    printf("There are %d numbers\n",queue_size(&que));

    printf("%d ",queue_pop(&que));
    printf("%d\n",queue_pop(&que));
    printf("Full result is %d\n",queue_full(&que));
    printf("Empty result is %d\n",queue_empty(&que));
    printf("There are %d numbers\n",queue_size(&que));
    
    queue_deinit(&que);    

    return 0;
}
