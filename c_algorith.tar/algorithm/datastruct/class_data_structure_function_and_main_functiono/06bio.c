/*
tree data-->includes physical chain data + specific functions
*/
#include <stdio.h>
#include <stdlib.h>
#include "06bio.h"
// create pointer to be included a structure data

// clearing with finally root solved  method

void tree_init(tree*p_tree)
{
    p_tree->p_node=NULL;
}


void tree_deinit(tree *p_tree)
{
    if(!(p_tree->p_node))
    {
    	return ;
    }
    tree_deinit(&(p_tree->p_node->left));//di gui method
    tree_deinit(&(p_tree->p_node->right));
    free(p_tree->p_node);
    p_tree->p_node=NULL;

}


// finding location for inserted value. Returned value is a whole tree
tree *tree_search_in_order(const tree *p_tree,int num)
{
    if(!(p_tree->p_node)) // if there is no any sub-node
    {
	return (tree *)p_tree;
    } 

    if(p_tree->p_node->num==num) // if value of root= found number
    {
	return (tree *)p_tree;
    }

    else if (p_tree->p_node->num>num) // if value of root > found num->							left location finding location
    {
	return tree_search_in_order(&(p_tree->p_node->left),num);
    }

    else // if value of root <num->right location finding locationo
    {
	return tree_search_in_order(&(p_tree->p_node->right),num);
    }

}


// insert number into queeued bio tree
void tree_insert_in_order(tree *p_tree,int num)
{
    node *p_node=NULL; // storing inserted number as a new node
    tree *p_tmp=tree_search_in_order(p_tree,num);
    if(p_tmp->p_node) // if found location has a number already, then no action
    {
	return ;
    }
    
    p_node=(node *)malloc(sizeof(node));
    if (p_node)
    {
	p_node->num=num;
	p_node->left.p_node=NULL;
	p_node->right.p_node=NULL;
  	p_tmp->p_node=p_node;
	// inserting new number directly into pointed location by p_tmp that 		has been calculated by last function
    }
}

/*
// print all numbers from tree on the screen
void tree_show(tree *p_tree) // using intermedia method
{
    if (!(p_tree->p_node))
    {
 	return ;
    }
    
    tree_show(&(p_tree->p_node->left));
    printf("%d ",p_tree->p_node->num);	
    tree_show(&(p_tree->p_node->right));
}
*/

// middle order circle that 2nd object is a function pointer
void tree_miter(const tree *p_tree,void (*p_func)(int))
{
    if (!(p_tree->p_node))
    {
	return ;
    }
    // first solve and show value of left node of a tree with di gui method
    tree_miter(&(p_tree->p_node->left),p_func);
    p_func(p_tree->p_node->num); // to show root's value
    // dispose and show value of right node
    tree_miter(&(p_tree->p_node->right),p_func);
    
}


void tree_fiter(const tree *p_tree,void (*p_func)(int))
{
    if (!(p_tree->p_node))
    {
	return ;
    }
    // front-circle
    p_func(p_tree->p_node->num);
    tree_fiter(&(p_tree->p_node->left),p_func);
    tree_fiter(&(p_tree->p_node->right),p_func);
}

// tail circle
void tree_liter(const tree *p_tree, void (*p_func)(int))
{
    if (!(p_tree->p_node))
    {
	return ;
    }
    tree_liter(&(p_tree->p_node->left),p_func);
    tree_liter(&(p_tree->p_node->right),p_func);
    p_func(p_tree->p_node->num);
}


// delete a give number from a ordered bionimal tree
void tree_remove(tree *p_tree,int num)
{
    node *p_node=NULL; // record node that deleted number at.
    tree *p_tmp=tree_search_in_order(p_tree,num); // number that deleted
    if (!(p_tmp->p_node))
    {
	return ;
    }
    
    p_node=p_tmp->p_node; // recording node which we want te delete
    
    if(!(p_node->left.p_node)) // no node on left sub-tree
    {
	p_tmp->p_node=p_node->right.p_node; // using root of right sub-tree replace 						deleted node
 	
    }

    else if(!(p_node->right.p_node))
    {
	p_tmp->p_node=p_node->left.p_node;
    }

    else // merge left and right sub-tree as a whole tree if we want
	// to delete root-->based on left tree

    {
	tree *p_tmp1=tree_search_in_order(&(p_node->left),p_node->right.p_node->num);
	p_tmp1->p_node=p_node->right.p_node;
  	p_tmp->p_node=p_node->left.p_node;
    }
    
    free(p_node);
    p_node=NULL;
}

// calculate deep of whole tree
int tree_deep(const tree *p_tree)
{ 
    int count_left=0;
    int count_right=0;

    if(!(p_tree->p_node))
   	return 0;

    count_left=tree_deep(&(p_tree->p_node->left));
    count_right=tree_deep(&(p_tree->p_node->right));

    int ret=count_left>count_right ? count_left : count_right;
    
    return ret+1;
}
