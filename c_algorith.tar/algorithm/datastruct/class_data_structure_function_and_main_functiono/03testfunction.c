/*
zhan test
*/
#include <stdio.h>
#include "03zhanstructure.h"

int main(void)
{
    stack stk={0};
    stack_init(&stk);
    printf("Verified full results is %d\n",stack_full(&stk));
    printf("Verified empty result is %d\n",stack_empty(&stk));
    printf("Avaliable numbers have %d\n",stack_size(&stk));
    stack_push(&stk,4);
    stack_push(&stk,11);
    stack_push(&stk,23);
    stack_push(&stk,31);
    stack_push(&stk,46);

    printf("Verified full results is %d\n",stack_full(&stk));
    printf("Verified empty result is %d\n",stack_empty(&stk));
    printf("Avaliable numbers have %d\n",stack_size(&stk));
    printf("Fianl number is %d\n",stack_top(&stk));
    
    printf("%d ",stack_pop(&stk));
    printf("%d ",stack_pop(&stk));
    printf("%d ",stack_pop(&stk));
    printf("%d ",stack_pop(&stk));
    printf("%d ",stack_pop(&stk));
    printf("\n");
    // that should be bigger number in the beginning
    printf("Verified full results is %d\n",stack_full(&stk));
    printf("Verified empty result is %d\n",stack_empty(&stk));
    printf("Avaliable numbers have %d\n",stack_size(&stk));

    stack_deinit(&stk);

    return 0;
}
