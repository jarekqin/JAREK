/*
chain table insert and delete functions
*/
#ifndef __05CHAIN_H__
#define __05CHIAN_H__

typedef struct node
{    
    int num;
    struct node *p_next;
    struct node *p_prev; // double directions physical chain
    
} node;


typedef struct
{
    node head,tail;// chain table should have some linear physical chain strucutures
    node *p_cur; // recording last round of taking number out 

} link;


// functions
void link_init(link *);


void link_deinit(link *);


int link_size(const link *);


// insert numberin the beginning location
void link_add_head(link *,int);

// insert number to tail
void link_append(link *,int);


void link_insert(link *,int);

// delete first number
void link_remove_head(link *);


// delete last number 
void link_remove_tail(link *);


// delege a specified number
void link_remove(link *,int);


// search 1st number function
int link_get_head(const link *,int *); //verify whether we get return number



// get final number function
int link_get_tail(const link *,int *);


// get number with index
int link_get(const link *,int , int *);
#endif       //__05CHAIN_H__

void link_begin(link *);
int link_next(link *, int *);
