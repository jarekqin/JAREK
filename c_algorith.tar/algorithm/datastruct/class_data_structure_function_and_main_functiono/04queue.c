/*
queue case
*/
#include "04queue.h"
#include <stdio.h>

void queue_init(queue *p_queue)
{
    p_queue->head=0;
    p_queue->tail=0;
}

void queue_deinit(queue *p_queue)
{
    p_queue->head=0;
    p_queue->tail=0;
}

int queue_full(const queue *p_queue)
{
    return p_queue->tail>=SIZE;
}

int queue_empty(const queue *p_queue)
{
    return p_queue->head==p_queue->tail;
}

int queue_size(queue *p_queue)
{
    return p_queue->tail-p_queue->head;
}

void queue_push(queue *p_queue,int num)
{
    p_queue->buf[p_queue->tail]=num;
    p_queue->tail++;

}

// getting number and deleting number
int queue_pop(queue *p_queue)
{
    p_queue->head++;
    return p_queue->buf[p_queue->head-1];
}

// getting number without delete
int queue_front(const queue *p_queue)
{
    return p_queue->buf[p_queue->head];
}


