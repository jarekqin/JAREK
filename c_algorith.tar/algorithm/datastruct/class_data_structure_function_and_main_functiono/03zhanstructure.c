/*
zhan structure 1
*/
#include <stdio.h>
#include "03zhanstructure.h"

// first using stack
void stack_init(stack *p_stack)
{
    p_stack->num=0;// stack initialise
    
}

// after first using stack
void stack_deinit(stack *p_stack)
{
    p_stack->num=0;// clear stack
}


// verify whether stack is fulled or not
int stack_full(const stack *p_stack)
{
    return p_stack->num >=SIZE;
}


// verify whether stack is null
int stack_empty(const stack *p_stack)
{
    return (!p_stack->num);
}


// get how many available number in stack
int stack_size(const stack *p_stack)
{
    return p_stack->num;
}


// add number into stack
void stack_push(stack *p_stack,int num)
{
    p_stack->buf[p_stack->num]=num;
    p_stack->num++;
}


// get and delete  number from stack
int stack_pop(stack *p_stack)
{
    int ret=p_stack->buf[p_stack->num-1];
    p_stack->num--;
    return ret;
}

// get number but does'nt delete number
int stack_top(const stack *p_stack)
{
    return p_stack->buf[p_stack->num-1];
}


