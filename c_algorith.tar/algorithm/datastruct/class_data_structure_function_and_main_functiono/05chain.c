/*
chain table insert and delete functions
*/
#include "05chain.h"
#include <stdlib.h>


// functions
void link_init(link *p_link)
{
    p_link->head.p_next=&(p_link->tail);
    p_link->tail.p_prev=&(p_link->head);
    p_link->tail.p_next=NULL;
    p_link->head.p_prev=NULL;
    p_link->p_cur=NULL;

}


void link_deinit(link *p_link)
{
    while(p_link->head.p_next!=&(p_link->tail))
    {
	node *p_first=&(p_link->head);
	node *p_mid=p_first->p_next;// p_mid must be piped with first available number
	node *p_last=p_mid->p_next;
        p_first->p_next=p_last;
   	p_last->p_prev=p_first;
	free(p_mid);
	p_mid=NULL;
    }
}


int link_size(const link *p_link)
{
    int cnt=0;
    const node *p_node=NULL;

    for (p_node=&(p_link->head);p_node!=&(p_link->tail);p_node=p_node->p_next);
    {
	const node *p_first=p_node;
	const node *p_mid=p_first->p_next;
	const node *p_last=p_mid->p_next;
	
	if (p_mid!=&(p_link->tail))
	{
	    cnt++;
	}
    }

    return cnt;
}


// insert number in the beginning location
void link_add_head(link *p_link,int num)
{   
     
    node *p_first=&(p_link->head);
    node *p_mid=p_first->p_next;
    node *p_last=p_mid->p_next;// this will not be used
    node *p_node=(node *)malloc(sizeof(node));// creating hack
    
    if (!p_node)
    {
	return ;
    }

    p_node->num=num;
    p_node->p_next=NULL;
    p_node->p_prev=NULL;
    p_first->p_next=p_node;
    p_node->p_next=p_mid;
    p_node->p_prev=p_first;
    p_mid->p_prev=p_node;
}

// insert number to tail
void link_append(link *p_link,int num)
{
    
    node *p_tmp=NULL;
    node *p_node=(node *)malloc(sizeof(node));// creating hack
    
    if (!p_node)
    {
	return ;
    }

    p_node->num=num;
    p_node->p_next=NULL;
    p_node->p_prev=NULL;
    for (p_tmp=&(p_link->head);p_tmp!=&(p_link->tail);p_tmp=p_tmp->p_next)
    {
  	
    	node *p_first=p_tmp;
    	node *p_mid=p_first->p_next;
    	node *p_last=p_mid->p_next;
	if (p_mid==&(p_link->tail))
	{
	    p_first->p_next=p_node;
	    p_node->p_next=p_mid;
	    p_node->p_prev=p_first;
	    p_mid->p_prev=p_node;
	    break;
	}
    }

}

// insert number with its squence from small one to big one
void link_insert(link *p_link,int num)
{
    node *p_tmp=NULL;
    node *p_node=(node *) malloc(sizeof(node));
    if (!p_node)
    {
	return ;
    }

    p_node->num=num;
    p_node->p_next=NULL;
    p_node->p_prev=NULL;
    for (p_tmp=&(p_link->head);p_tmp!=&(p_link->tail);p_tmp=p_tmp->p_next)
    {
	
    	node *p_first=p_tmp;
    	node *p_mid=p_first->p_next;
    	node *p_last=p_mid->p_next;

  	if(p_mid==&(p_link->tail) || p_mid->num>num)
	{
	    p_first->p_next=p_node;
	    p_node->p_next=p_mid;
 	    p_node->p_prev=p_first;
	    p_mid->p_prev=p_node;
	    break;
	}
	
    }

}


// delete first number
void link_remove_head(link *p_link)
{
    node *p_first=NULL,*p_mid=NULL,*p_last=NULL;

    if (p_link->head.p_next==&(p_link->tail))
    {
	return ;
    }
    p_first=&(p_link->head);
    p_mid=p_first->p_next;
    p_last=p_mid->p_next;
    p_first->p_next=p_last;
    p_last->p_prev=p_first;
    free(p_mid);
    p_mid=NULL;
    p_link->p_cur=NULL;
}


// delete last number 
void link_remove_tail(link *p_link)
{
    node *p_node=NULL;
    for (p_node=&(p_link->head);p_node!=&(p_link->tail);p_node=p_node->p_next)
    {
	node *p_first=p_node;
  	node *p_mid=p_first->p_next;
 	node *p_last=p_mid->p_next;
  	if (p_last==&(p_link->tail))
	{  //p_mid is piped with last available node
	    p_first->p_next=p_last;
	    p_last->p_prev=p_first;
	    free(p_mid);
	    p_mid=NULL;
	    break;
	}	
    }
    p_link->p_cur=NULL;
}


// delege a specified number
void link_remove(link *p_link,int num)
{
    node *p_node=NULL;
    for (p_node=&(p_link->head);p_node!=&(p_link->tail);p_node=p_node->p_next)
    {
	node *p_first=p_node;
  	node *p_mid=p_first->p_next;
 	node *p_last=p_mid->p_next;
 	if (p_mid!=&(p_link->tail) && p_mid->num==num)
	{
	    p_first->p_next=p_last;
	    p_last->p_prev=p_first;
	    free(p_mid);
	    p_mid=NULL;
	    break;
	}
    }
    p_link->p_cur=NULL;
}


// search 1st number function
int link_get_head(const link *p_link,int *p_num) //verify whether we get return number
{
    if (p_link->head.p_next==&(p_link->tail))
    {
	return 0;
    }

    else
    {
	*p_num=p_link->head.p_next->num;
	return 1;
    }
}


// get final number function
int link_get_tail(const link *p_link,int *p_num)
{
    if (p_link->head.p_next==&(p_link->tail))
    {
	return 0;
    }
    
    else 
    {
	*p_num=p_link->tail.p_prev->num;
	return 1;
    }
}


// get number with index
int link_get(const link *p_link,int sn, int *p_num)
{   
    int cnt=0;
    const node *p_node=NULL;
    for (p_node=&(p_link->head);p_node!=&(p_link->tail);p_node=p_node->p_next)
    {
	const node *p_first=p_node;
  	const node *p_mid=p_first->p_next;
 	const node *p_last=p_mid->p_next;
 	if (p_mid!=&(p_link->tail))
	{
	    if (cnt==sn)
	    {
	  	*p_num=p_mid->num;
	   	return 1;
	    }
	    cnt++;
	}
    }
    
    return 0;
}


//starting read all nodes of chain from front to end
void link_begin(link *p_link)
{
    p_link->p_cur=&(p_link->head);
 
}

// getting next number of a chain
int link_next(link * p_link,int *p_num)
{
    if (!(p_link->p_cur))
    {
	return 0;
    }

    // pointer move to next node
    p_link->p_cur=p_link->p_cur->p_next;
    if (p_link->p_cur==&(p_link->tail))
    {
	return 0;// cannot take any number again
	p_link->p_cur=NULL;
    }

    else
    {
	*p_num=p_link->p_cur->num;
	return 1;
    }

}


void link_append2(link *p_link,int num)
{
    node *p_first=&(p_link->tail.p_prev);
    node *p_mid=p_first->p_next;
    node *p_last=p_mid->p_next;
    node *p_node=(node *)malloc(sieof(node));

    if (!p_node)
    {
	return ;
    }

    p_node->num=num;
    p_node->p_next=NULL;
    p_node->p_prev=NULL;

    p_first->p_next=p_node;
    p_node->p_next=p_mid;
    p_node->p_prev=p_first;
    p_mid=->p_prev=p_node;
    
}

void link_remove_tail(link *p_link)
{
    node *p_first=NULL, *p_mid=NULL,*p_last=NULL;
    if (p_link->head.p_next==&(p_link->tail))
    {
	return ;
    }

    p_first=p_link->tail.p_prev->p_prev;// tail.p_prev=p_mid
 					// p_mid.p_rev=p_first
    p_mid=p_first->p_next;
    p_last=p_mid->p_next;
    p_first->p_next=p_last;
    p_last->p_prev=p_first;
    free(p_mid);
    p_mid=NULL;
    p_link->p_cur=NULL;

}  
