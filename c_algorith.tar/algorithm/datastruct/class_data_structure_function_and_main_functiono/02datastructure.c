/*
data structure 2-dymatically allocating nodes
*/

#include <stdio.h>
#include <stdlib.h>

typedef struct node
{
    int num;
    struct node *p_next;
} node;


int main(void)
{
    int num=0;
    node *p_node=NULL,*p_tmp=NULL;
    // p_tmp is used as counter,p_node is used as a dymatic allocating structured data pointer
    node head={0},tail={0};
    head.p_next=&tail;

    while (1)
    {
	printf("Please type a number:");
	scanf("%d",&num);
	
	if (num<0)
	{
	    break;
	}
	// dymatic allocating a node, and stroing typed number, as well as 
        // give number to p_first, receive older number from p_mid
	p_node=(node *)malloc(sizeof(node));
  	//printf("p_node has %d space\n",sizeof(p_node));

 	if (!p_node)
	{
	    continue;
 	}

	p_node->num=num;
	p_node->p_next=NULL;

	for (p_tmp=&head;p_tmp!=&tail;p_tmp=p_tmp->p_next)
	{
	    node *p_first=p_tmp;
	    node *p_mid=p_first->p_next;
	    node *p_last=p_mid->p_next;

	    if (p_mid==&tail || p_mid->num>num)
	    {	
		p_first->p_next=p_node;
		p_node->p_next=p_mid;
		break;
	    }

	}

    }
    /*
    //delete a random number in the given node
    int i;
    printf("Type a number you want to delete:");
    scanf("%d",&i);
    
     
    for (p_tmp=&head;p_tmp!=&tail;p_tmp=p_tmp->p_next)
    {	
	node *p_first=p_tmp;
	node *p_mid=p_first->p_next;
	node *p_last=p_mid->p_next;
  	// delete condition
	if (p_mid!=&tail && p_mid->num==i)
	{
	    p_first->p_next=p_last;
	    // release p_mid from physical chain
	    free(p_mid);
	    p_mid=NULL;
	    break;
	}
    }
    */

    //print numbers in the nodes
    for (p_tmp=&head;p_tmp!=&tail;p_tmp=p_tmp->p_next)
    {    
	node *p_first=p_tmp;
	node *p_mid=p_first->p_next;
	node *p_last=p_mid->p_next;
	
	if (p_mid!=&tail)
	{
	    printf("%d ",p_mid->num);
	}
    }

    printf("\n");
    // releasing all nodes store
    while (head.p_next!=&tail)
    {
 	node *p_first=&head;
	node *p_mid=p_first->p_next;
	node *p_last=p_mid->p_next;
	// p-mid will tipped with first valiable node	
	p_first->p_next=p_last;
	free(p_mid);
	p_mid=NULL;
    }
        
    return 0;
    
}
