/*
main function for 05chain.c file
*/

#include <stdio.h>
#include "05chain.h"

int main(void)
{   
    int num=0,size=0,tmp=0;
    link lnk={0};
    link_init(&lnk);
    link_insert(&lnk,11);
    link_insert(&lnk,55);
    link_insert(&lnk,31);
    link_insert(&lnk,63);
    link_insert(&lnk,23);
    link_insert(&lnk,42);
    link_add_head(&lnk,7);
    link_add_head(&lnk,3);
    link_append(&lnk,86);
    link_append(&lnk,75);

    printf("Available number are %d\n",link_size(&lnk));
    link_get_head(&lnk,&num);
    printf("First number is %d\n",num);
    link_get_tail(&lnk,&num);
    printf("Last number is %d\n",num);
    
    link_remove_head(&lnk);
    link_remove_tail(&lnk);
    link_remove(&lnk,42);

    size=link_size(&lnk);
    for (tmp=0;tmp<size;tmp++)
    {
	link_get(&lnk,tmp,&num);
	printf("%d ",num);
    }
    printf("\n");
   
    link_begin(&lnk);
    while (1)
    {
	tmp=link_next(&lnk,&num);
	if (!tmp)
	    break;
  	printf("%d ",num);
    }
    printf("\n");

    link_deinit(&lnk);


    return 0;
}
