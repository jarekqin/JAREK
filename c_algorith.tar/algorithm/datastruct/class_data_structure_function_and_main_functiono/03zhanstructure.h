/*
zhan structure 1
*/
#ifndef __03ZHANSTRUCTURE_H__
#define __03ZHANSTRUCTURE_H__


typedef struct
{
    int buf[SIZE];
    //number should be bigger ones in the beginning, and smaller ones in the      end
    // 1,2,3-->3,2,1 in stack
    int num;// shows how many available numbers in above array

} stack;

// first using stack
void stack_init(stack *);

// after first using stack
void stack_deinit(stack *);


// verify whether stack is fulled or not
int stack_full(const stack *);


// verify whether stack is null
int stack_empty(const stack *);


// get how many available number in stack
int stack_size(const stack *);


// add number into stack
void stack_push(stack *,int );


// get and delete  number from stack
int stack_pop(stack *);

// get number but does'nt delete number
int stack_top(const stack *);

#endif   //__03ZHANSTRUCTURE_H__
