
/*
data structure basic knowledge for chain data
*/
#include <stdio.h>
typedef struct node
{
   int num;
   struct node *p_next;
   //this is a special case for pointer that can directly point another object 

} node;

int main(void)
{
    node node1={1},node2={5},node3={13},node4={7},tail={0},head={0};
    node *p_node=NULL;
    head.p_next=&node1;
    node1.p_next=&node2;//linking node1 and node2
    node2.p_next=&node3;// this is pointer array declaration
    node3.p_next=&tail;
    /*node2.p_next=&node4;
    node4.p_next=&node3;
    node1.p_next=&node4;*/
    // how can we find inserted location for where we want
    // below framework can be used as a fixed way to be remebered
    // for circle starts from head nodes to final tail nodes
    
    for (p_node=&head;p_node!=&tail;p_node=p_node->p_next)
    {
	node *p_first=p_node;
    	//this is a pointer for a pointer ==**p_first=&p_node
  	node *p_mid=p_first->p_next;
	node *p_last=p_mid->p_next;
	
	if (p_mid==&tail || p_mid->num > node4.num)
	{
	    p_first->p_next=&node4;
	    node4.p_next=p_mid;
	    break; // this is necessary to do
	}

    }

    // delete which location we want 
    for (p_node=&head;p_node !=&tail;p_node=p_node->p_next)
    {
	node *p_first=p_node;
 	node *p_mid=p_first->p_next;
	node *p_last=p_mid->p_next;
	
	if (p_mid!=&tail && p_mid->num==5)
	{
	    p_first->p_next=p_last;
	    break;
	}
    }

    // exporting total num in physical chain observations
    for (p_node=&head;p_node !=&tail;p_node=p_node->p_next)
    {
	node *p_first=p_node;
 	node *p_mid=p_first->p_next;
	node *p_last=p_mid->p_next;
	
	if (p_mid!=&tail)
	{
	    printf("%d ",p_mid->num);
	}
    }
    
    printf("\n");
    
    // calculate available observations
    int num=0;
    for (p_node=&head;p_node !=&tail;p_node=p_node->p_next)
    {
	node *p_first=p_node;
 	node *p_mid=p_first->p_next;
	node *p_last=p_mid->p_next;
	
	if (p_mid!=&tail)
	{
	    num++;
	}
    }

    printf("Avaiable observations are: %d\n",num);
    
    num=0;
    // showing physical chain can read number randomly
    for (p_node=&head;p_node !=&tail;p_node=p_node->p_next)
    {
	node *p_first=p_node;
 	node *p_mid=p_first->p_next;
	node *p_last=p_mid->p_next;
	
	if (p_mid!=&tail)
	{
	    if (num==2)
	    {
		printf("No2 observation is %d\n",p_mid->num);
		break;
	    }

	    num++;
	}
    }

    return 0;
}
