/*
tree data-->includes physical chain data + specific functions
*/
// create pointer to be included a structure data
#ifndef    __06BIO_H__
#define    __06BIO_H__
struct node;
typedef struct
{
    struct node *p_node;

} tree; // this represents a sub-tree with a pointer only

// using last pointer structure data as right and left pointers
// packing pointer in tree
typedef struct node
{
    int num; 
    tree left;// p_node->left
    tree right;// p_node->right

} node; // if left/right=NULL--> node will be released


// initializing
void tree_init(tree *);


// clearing with finally root solved  method
void tree_deinit(tree *);

// insert number into queeued bio tree
void tree_insert_in_order(tree *,int );


// middle order circle that 2nd object is a function pointer
void tree_miter(const tree *,void (*)(int));


void tree_fiter(const tree *,void (*)(int));

// tail circle
void tree_liter(const tree *, void (*)(int));

// delete number in a node

void tree_remove(tree *,int);

int tree_deep(const tree *);

#endif    //__06BIO_H__
