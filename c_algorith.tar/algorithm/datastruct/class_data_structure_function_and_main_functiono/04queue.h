/*
queue case
*/

#ifndef __04QUEUE_H__
#define __04QUEUE_H__
#define SIZE 100

typedef struct
{

    int buf[SIZE];
    int head,tail; // head is first available number index
		   // tail is last available number of next index       

} queue;

void queue_init(queue *);

void queue_deinit(queue *);

int queue_full(const queue *);

int queue_empty(const queue *);

int queue_size(queue *);

void queue_push(queue *,int );

// getting number and deleting number
int queue_pop(queue *);

// getting number without delete
int queue_front(const queue *);

#endif //__04QUEUE_H__
