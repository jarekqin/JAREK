/*
c/c++ common algo book ->P23
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAXLEN 100
typedef struct 
{
    char key[10];
    char name[20];
    int  age;
} data;

typedef struct
{
    data listdata[MAXLEN+1];
    int listlen; // showing present nodes
} sltype;

// initiallise list
void slinit(sltype *sl)
{
    sl->listlen=0;
}

// calculate len of list
int sllength(sltype *sl)
{
    return (sl->listlen);
}

// insert node
int slinsert(sltype *sl,int n,data d)
{
    int i;
    if(sl->listlen>=MAXLEN)
	return 0;

    if(n<1 || n>sl->listlen-1)
    {
	printf("wrong index of number, cannot insert!\n");
	return 0;
    }

    for (i=sl->listlen;i>=n;i--)
    {
	sl->listdata[i+1]=sl->listdata[i];
    }
    sl->listdata[n]=d;
    sl->listlen++;
    return 1;
}	

// add node in the last node
int sladd(sltype *sl,data d)
{
    if(sl->listlen>=MAXLEN)
    {
	printf("list has been fulled\n");
	return 0;
    }

    sl->listdata[++sl->listlen]=d;
    return 1;
}

// delete node
int sldelete(sltype *sl,int n)
{
    int i;
    if(n<1|| n>sl->listlen) // delete wrong node
    {
	printf("cannot delete wrong node!\n");
	return 0;
    }

    for (i=n;i<sl->listlen;i++)
    {
	sl->listdata[i]=sl->listdata[i+1];
    }
    sl->listlen--;
    return 1;
}

// find node by order
data *slfindbynum(sltype *sl,int n)
{
    if(n<1 || n>sl->listlen+1)
    {
	printf("wrong node number, cannot return!\n");
	return NULL;
    }

    return &(sl->listdata[n]);
}

// find node by key word
int slfindbycont(sltype *sl,char *key)
{
    int i;
    for (i=1;i<=sl->listlen;i++)
    {
	if(strcmp(sl->listdata[i].key,key)==0)
	    return i;
    }

    return 0;
}


// show all nodes
int slall(sltype *sl)
{
    int i;
    for (i=1;i<=sl->listlen;i++)
    {
	printf("(%s,%s,%d)\n",sl->listdata[i].key,sl->listdata[i].name,sl->listdata[i].age);
    }
    return 0;
}

int main(void)
{
    int i;
    sltype sl;
    data d;
    data *p_d;
    char key[10];
 
    printf("List exhibition!\n");
    slinit(&sl);
    printf("initialisation finish!\n");

    do
    {
	printf("Type added node data:(key name age): ");
	fflush(stdin);//delete all huan chong qu
 	scanf("%s%s%d",&d.key,&d.name,&d.age);
	if(d.age)
  	{
	    if(!sladd(&sl,d)) // if add nodes failed
		break;
  	}
  	else
	     break;
    }while (1);

    printf("\n All nodes is: \n");
    slall(&sl);
    
    fflush(stdin);
    printf("\nTake node is: ");
    scanf("%d",&i);
    p_d=slfindbynum(&sl,i);
    if(p_d)
    	printf("No:%d node is (%s %s %d)\n",i,p_d->key,p_d->name,p_d->age);

    fflush(stdin);
    printf("\n word will be founded:");
    scanf("%s",key);
    i=slfindbycont(&sl,key);
    p_d=slfindbynum(&sl,i);
    if(p_d)
    	printf("No:%d node is (%s %s %d)\n",i,p_d->key,p_d->name,p_d->age);
	    
    getchar();
    return 0;
}
