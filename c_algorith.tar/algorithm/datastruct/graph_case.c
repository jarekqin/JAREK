/*
graph case
*/
#include <stdio.h>
#define MAXNUM 20
#define MAXVALUE 65535

typedef struct
{
    char vertex[MAXNUM];
    int gtype;
    int vertexnum;// points number
    int edgenum; // edge numbers
    int edgeweight[MAXNUM][MAXNUM];// store weight of edgess
    int istrav[MAXNUM]; // bianli denote
} graphmatrix;

void creategraph(graphmatrix *gm)
{
    int i,j,k;
    int weight;
    char estartv,eendv;

    printf("type inform for every points\n");
    for (i=0;i<gm->vertexnum;i++)
    {
	getchar();
	printf("No.%d point:",i+1);
	scanf("%c",&(gm->vertex[i]));
    }

    printf("Type points for all edges and weights\n");
    for (k=0;k<gm->edgenum;k++)
    {
	getchar();
	printf("No.%d edge: ",k+1);
	scanf("%c %c %d",&estartv,&eendv,&weight);
 	for(i=0;estartv!=gm->vertex[i];i++)
 	{
	    for(j=0;estartv!=gm->vertex[j];j++);
		gm->edgeweight[i][j]=weight;

 		if(gm->gtype==0)
	    	    gm->edgeweight[j][i]=weight; // diagonal line stores weight value
	}
    }
}

// clear graph
void cleargraph(graphmatrix *gm)
{
    int i,j;
    for(i=0;j<gm->vertexnum;i++)
    {
	for (j=0;j<gm->vertexnum;j++)
	{
	    gm->edgeweight[i][j]=MAXVALUE;
	}
    }
}


// show graph
void outgraph(graphmatrix *gm)
{
    int i,j;
    for (j=0;j<gm->vertexnum;j++)
	printf("\t%c",gm->vertex[j]); // export 1st line inform
    printf("\n");
    for (i=0;i<gm->vertexnum;i++)
    {
	printf("%c",gm->vertex[i]);
	for (j=0;j<gm->vertexnum;j++)
	{	
	    if(gm->edgeweight[i][j]==MAXVALUE)
	    	printf("\tZ");
	
	    else
	    	printf("\t%d",gm->edgeweight[i][j]);
	}
    	printf("\n");    	
    }
}


// bian li graph
void deeptraone(graphmatrix *gm,int n)
{
    int i;
    gm->istrav[n]=1;
    printf("->%c",gm->vertex[n]);

    // add node
    for (i=0;i<gm->vertexnum;i++)
    {
	if(gm->edgeweight[n][i]!=MAXVALUE && !gm->istrav[n])
	    deeptraone(gm,i);
    }
}

void deeptragraph(graphmatrix *gm)
{
    int i;
    for (i=0;i<gm->vertexnum;i++)
    {
	gm->istrav[i]=0;
    }
    printf("Deep travelling first nodes:");
    for (i=0;i<gm->vertexnum;i++)
    {
	if(!gm->istrav[i])
	    deeptraone(gm,i);
    }
    printf("\n");
}

int main(void)
{
    graphmatrix gm;
    
    printf("Create a type of graph:");
    scanf("%d",&gm.gtype);
    printf("Pointers amounts:");
    scanf("%d",&gm.vertexnum);
    printf("Type edges amounts:");
    scanf("%d",&gm.edgenum);
    cleargraph(&gm);
    creategraph(&gm);
    printf("THis graph has matrix as below:\n");
    outgraph(&gm);
    deeptragraph(&gm);

    return 0;
}
