/*
digui calculation
*/
#include <stdio.h>
long fact(int n)
{
    if(n<=1)
	return 1;
    else
 	return n*fact(n-1);
}

int main(void)
{
    int i;
    printf("please type a number for calculate:\n");
    scanf("%d",&i);

    printf("After %d rounds, number result is: %ld\n",i,fact(i));

    return 0;
}
