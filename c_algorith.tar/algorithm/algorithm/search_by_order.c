/*
algorighm book P 137
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define N 15


int SearchFun(int a[],int n,int x)
{
    int i,f=-1;
    for(i=0;i<n;i++)
    {
	if(x==a[i])
	{
	    f=i;
	    break;
	}
    }	
    return f;
}


void main()
{
    int x,n,i;
    int shuzu[N];

    srand(time(0));
    for (i=0;i<N;i++)
    	shuzu[i]=rand()/1000000+100;
    printf("Search method case!\n");
    printf("data:\n");
    for (i=0;i<N;i++)
    	printf("%d ",shuzu[i]);
    
    printf("\n\n");

    printf("Type number:");
    scanf("%d",&x);

    n=SearchFun(shuzu,N,x);
    if(n<0)
	printf("No data in shuzu!\n");
    else
	printf("data: %d is at No.%d location.\n",x,n+1);
}
