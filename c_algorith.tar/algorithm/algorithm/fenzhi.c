/*
silver coins case
*/
#include <stdio.h>
#define MAXNUM 30

int FalseCoin(int coin[],int low,int high)
{
    int i,sum1,sum2,sum3;
    int re;

    sum1=sum2=sum3=0;
    if(low+1==high)
    {
	if(coin[low]<coin[high])
	{
	    re=low+1;
	    return re;
 	}
	else
	{
	    re=high+1;
	    return re;
	}
    }

    if((high-low+1) % 2==0) // n is event
    {
	for(i=low;i<low+(high-low)/2;i++)
	{
	    sum1=sum1+coin[i];  // previous scale sum
	}
        for(i=low+(high-low)/2+1;i<=high;i++)
	{
	    sum2=sum2+coin[i];
	}
   	if(sum1>sum2)
	{
	    re=FalseCoin(coin,low+(high-low)/2+1,high);
	    return re;
	}
  	else if(sum1<sum2)
	{
	    re=FalseCoin(coin,low,low+(high-low)/2);
	    return re;
	}
	else
	{
	}
    }
    
    else
    {
	for(i=low;i<=low+(high-low)/2-1;i++)
	{
	    sum1=sum1+coin[i]; // sum of previous half
	}
	for(i=low+(high-low)/2+1;i<=high;i++)
	{
	     sum2=sum2+coin[i];
	}
	sum3=coin[low+(high-low)/2];
	if(sum1>sum2)
	{
 	    re=FalseCoin(coin,low+(high-low)/2+1,high);
	    return re;
	}
  	else if (sum1<sum2)
	{
	    re=FalseCoin(coin,low,(high-low)+low/2-1);
	    return re;
	}	
	else
	{	

	}
	if(sum1+sum3== sum2+sum3)
	{
	    re=low+(high-low)/2+1;
	    return re;
	}
    }
}

void main()
{
    int coin[MAXNUM];
    int i,n;
    int weizhi;

    printf("Division method calculate silver coin casee!\n");
    printf("Type silve coins number: ");
    scanf("%d",&n);
    printf("Type silve is true or false: ");
    for (i=0;i<n;i++)
    	scanf("%d",&coin[i]);
    weizhi=FalseCoin(coin,0,n-1);
    printf("Total %d silver coins, NO.%d is false!\n",n,weizhi);

}
