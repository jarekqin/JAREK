/*
chicken and rabbit problem
*/
#include <stdio.h>

int qiongju(int head,int foot,int *chicken,int *rabbit)
{
    int i,j,re;
    re=0;
    for (i=0;i<=head;i++)
    {
	j=head-i;
	if(i*2+4*j==foot)
	{
	    re=1;
	    *chicken=i;
	    *rabbit=j;
	}
    }
    return re;
}

int main(void)
{
    int chicken,rabbit,head,foot;

    int re;

    printf("qiong ju method calculate chicken and rabbit numbers!\n");
    printf("Please type head numbers: ");
    scanf("%d",&head);
    printf("please type foot numbers: ");
    scanf("%d",&foot);
    
    re=qiongju(head,foot,&chicken,&rabbit);
    if(re==1)
    {
	printf("chicken are %d, rabbit are %d.\n",chicken,rabbit);
    }	
    else
    {
	printf("NO result for those numbers!\n");
    }

    return 0;
}
