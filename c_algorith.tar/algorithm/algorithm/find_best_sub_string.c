#include <stdio.h>
#include <string.h>

void FindSub(char *str,int *sub0, int *sub1)
{
    int i=0,len;
    int temp0=0,temp1=0;

    len=strlen(str);
    while(i<len)
    {
	if(str[i]=='0')
	{
	    if(str[i-1]=='1')
	    {
		if(temp1>*sub1)
		    *sub1=temp1;
	    	temp1=0;
	    }
	    temp0++;
	    *sub0=temp0;
	}

    	if(str[i]=='1')
    	{
	    if(temp0>*sub0)
	    {
	    	*sub0=temp0;
	    }
	    if(str[i-1]=='0')
	    	temp0=0;
	    temp1++;
	    *sub1=temp1;
    	}  
    	i++;
    }	
}


void main()
{
    char *str="1011000000000011110000000000";
    int sub0=0;
    int sub1=0;
    FindSub(str,&sub0,&sub1);
    printf("'0' longest length is %d\n",sub0);
    printf("'1' longest length is %d\n",sub1);
}
