#include <stdio.h>

void main()
{
    int i;
    int n=100;
    float tmp;
    float sum=0;
    float a=1;
    float b=1;
    
    for(i=0;i<n;i++)
    {
	sum=sum+a/b;
  	tmp=a+b;
	b=a;    // fen mu = previous fen zi
	a=tmp;  // fen zi=sum of previous fen zi + previous fen mu
    }
    printf("1+2+3/2+5/3...=%f\n",sum);

}
