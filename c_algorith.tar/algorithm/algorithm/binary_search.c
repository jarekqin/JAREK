/*
binary search->algorithm book P 139
*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

#define N 15

void quick_sort(int *a,int left,int right)
{
    int f,l,r,t;
    l=left;
    r=right;
    f=a[(left+right)/2];

    while(l<r)
    {
	while(a[l]<f)
	    ++l;
	while(a[r]>f)
	    --r;
	if(l<=r)
	{
	    t=a[l];
	    a[l]=a[r];
	    a[r]=t;
	    ++l;
	    --r;
	}
    }
    if(l==r)
	l++;
    if(left<r)
	quick_sort(a,left,l-1);
    if(l<right)
	quick_sort(a,r+1,right);	
}

// binary search
int SearchFun(int a[],int n,int x)
{
    int mid,low,high;
    low=0;
    high=n-1;
    while(low<=high)
    {
	mid=(low+high)/2;
	if(a[mid]==x)
	    return mid;
  	else if(a[mid]>x)
	    high=mid-1;
 	else
	    low=mid+1;
    }
    return -1;
}


void main()
{
    int shuzu[N],x,n,i;
    srand(time(0));
    for (i=0;i<N;i++)
    	shuzu[i]=rand()/1000000+100;
    
    printf("Data before sorted:\n");
    for (i=0;i<N;i++)
  	printf("%d ",shuzu[i]);
    printf("\n\n");

    quick_sort(shuzu,0,N-1);

    printf("After sorted:\n");
    
    for (i=0;i<N;i++)
	printf("%d ",shuzu[i]);
    printf("\n\n");

    printf("type a number:");
    scanf("%d",&x);

    n=SearchFun(shuzu,N,x);

    if(n<0)
	printf("no data:%d\n",x);
    else
 	printf("data: %d is at NO.%d location.\n",x,n+1);
}


