/*
mao pao paixu-from small to big
*/
#include <stdio.h>
#include <string.h>

/*
void bubble_sort(int *p_num,int size)
{
    int num=0,num1=0,tmp=0;
    for (num=size-1;num>0;num--)
    {
	for(num1=1;num1<=num;num1++)j;
	{
	    //adjusting index of num1-1 and num1 those 2 numbers
	    if(*(p_num+num1-1)<*(p_num+num1))
 	    {
		tmp=*(p_num+num1-1);
		*(p_num+num1-1)=*(p_num+num1);
		*(p_num+num1)=tmp;
	    }

	}

    }

}
*/

// from right to left
// and comparison scale declines as per circle
void bubble_sort2(int *p_num,int size)
{
    int num=0,num1=0,tmp=0;
    for (num=0;num<size-1;num++)
    {     
	for (num1=size-1;num1>num;num1--)
	{
	    if (p_num[num1-1]>p_num[num1])
	    {
		tmp=p_num[num1-1];
		p_num[num1-1]=p_num[num1];
		p_num[num1]=tmp;
	    }
	}
    }
}


// max number put on the right, and every circle will be reduced
// from right to left. min number will be put on the left.
// we are always choose data[n-1] as chosen point to compare remained ones
void choice_sort(int *p_num,int size)
{
    int num=0,num1=0,tmp=0;
    for (num=size-1;num>0;num--)//choosing final value of index as fixed one
    {
	for (num1=0;num1<=num-1;num1++)
	{
	    if(*(p_num+num1)>*(p_num+num)) // comparing 1st to final
	    {
		tmp=*(p_num+num1);
		*(p_num+num1)=*(p_num+num);
		*(p_num+num)=tmp;
	    }	
	}

    }


}


// every circle comparison will be expended by 1
// from left to right
// etc:1st round, p_num[0] > p_num[1]
// 2nd croun, p_num[1]>p_num[2];p_num[0]>p_num[1];
// 3rd croun, p_num[2]>p_num[3];p_num[1]>p_num[2];p_num[0]>p_nu,[1]...
// we choose p_num[0] as smallest number location to compare to the right ones.
void insert_sort(int *p_num,int size)
{
    int num=0,num1=0,tmp=0;
    for (num=1;num<=size-1;num++)
    {
	// insert num=index to a fixed location
	// this decline likes bubble sort
	for (num1=num-1;num1>=0;num1--)
	{
	    if (p_num[num1]>p_num[num1+1])
	    {
		tmp=p_num[num1];
		p_num[num1]=p_num[num1+1];
		p_num[num1+1]=tmp;
	    }
	    
	    else
	    {   
		// only affect inner circle
		break;
	    }
	}
    }
}



void quick_sort(int *p_num,int size)
{
    int *p_start=p_num,*p_end=&p_num[size-1],tmp=0;// tiping start and end of array
    int base=*p_num;// initially, base number is first number of an array
    
    if(size<=1)
    {
	return ;
    } 

    while(p_start<p_end)
    {   // adjust p_start and p_end pointer
 	// their tipped block order
	// there is must be at least one pointer= based number
	if(*p_start>*p_end)
	{
	    tmp=*p_start;
	    *p_start=*p_end;
	    *p_end=tmp;
	}

   	if(*p_start==base)
 	{
	    // if p_start=based number
	    // therefore delete p_end block
	    p_end--; // number that bigger than base is on the right
	}

 	else
	{
	    // if p_end=based number
	    // therefore delete p_start block
	    p_start++; // number that smaller than base is on the left
	}
    }
    // dispose numbers are on the based number left
    quick_sort(p_num,p_start-p_num);
    // dispose numbers are on the based number right
    quick_sort(p_start+1,size-(p_start-p_num)-1);
}


// jiweijiu sorting
void cocktail(int *arr,int size)
{
    int i,j,k;
    int bl;
    int temp;
    int tail=size-1;
    for(i=0;i>tail;)
    {
	bl=0;
	for(j=tail;j>i;--j)   // set min number to left
	{
	    if(arr[j]<arr[j-1])
	    {
		temp=arr[j];
	 	arr[j]=arr[j-1];
		arr[j-1]=temp;
		bl=1;
	    }	
	}
	++i;  // original data at i place has been done, i++
	for(j=i;j<tail;++j)     // set max number to right
	{
	    if(arr[j]>arr[j+1])
	    {
		temp=arr[j];
		arr[j]=arr[j+1];
		arr[j+1]=temp;
		bl=1;
	    }
	}
	tail--;

	printf("No.%d steps result is:",i);
	for(k=0;k<size;k++)
	{
	    printf("%d ",arr[k]);
	}
	printf("\n");

	if(bl==0)  // verify whehter is sorted or not
	    break;
    }
}


int main(void)
{
    //int arr[]={50,20,70,10,30,110,80,60};
    int arr[]={12,78,34,101,23,170,120,22,200,90,56,260,33,55,125,89,199,201,3,9};
    //int *p_arr=arr;
    //bubble_sort(arr,8);
    //choice_sort(arr,8);
    //insert_sort(arr,8);
    //bubble_sort2(arr,8);
    //quick_sort(arr,8);
    cocktail(arr,20);
    for (int i=0;i<20;i++)
    {
	printf("%d ",arr[i]);
    }

    printf("\n");

    return 0;
}
