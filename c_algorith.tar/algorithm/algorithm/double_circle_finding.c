/*
FInd 2 same string into 2 arrays
*/
#include <stdio.h>
void FindNumber(int array1[],int n1,int array2[],int n2)
{
    int i,j;

    for(i=0;i<n1;i++)
    {
	for(j=0;j<n2;j++)
	{	
	    if(array1[i]==array2[j])
	    {
		printf("%d ",array1[i]);
		break;
	    }
	}
    }
}

void main(void)
{
    int i,j,n1,n2;
    int array1[5];
    int array2[6];

    n1=5;
    printf("Type array1 numbers, all %d numbers: \n",n1);
    for(i=0;i<n1;i++)
    {
	scanf("%d",&array1[i]);
    }

    n2=6;
    printf("Type array2 numbers, all %d numbers: \n",n2);
    for (i=0;i<n2;i++)
    {
	scanf("%d",&array2[i]);
    }

    printf("Array1 is:");
    for (i=0;i<n1;i++)
    {
	printf("%d",array1[i]);
    }
    printf("\n");

    printf("array2 is:");
    for (i=0;i<n2;i++)
    {
	printf("%d",array2[i]);
    }
    printf("\n");

    printf("Same number between 2 arrays are: ");
    FindNumber(array1,n1,array2,n2);
}
