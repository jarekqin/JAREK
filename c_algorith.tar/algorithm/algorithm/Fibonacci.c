/*
rabbit makes next generation case
*/
#include <stdio.h>

int Fibonacci(n)
{
    int t1,t2;
    if(n==1 || n==2)
	return 1;
    else
    {
	t1=Fibonacci(n-2);
	t2=Fibonacci(n-1);
	return t1+t2;
    }
}

int main(void)
{
    int n,num;

    printf("di tui method calculate next generation for rabbit!\n");
    printf("Type time: ");
    scanf("%d",&n);
    num=(int) Fibonacci(n);
    printf("After %d months, rabbits will be %d as amounts1\n",n,num);

    return 0;
}
