/*
algorithm book P121
*/
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define SIZE 15

void MergeOne(int a[],int b[],int n,int len)
{
    int i,j,k,s,e;
    s=0;
    while(s+len<n)
    {
	e=s+2*len-1;
   	if(e>=n) // if last scale less than len node
	    e=n-1;
	k=s;
	i=s;
	j=s+len;
	while(i<s+len && j<=e) // if 2 order table are not ended
			       // circle will compare less number
			       // into list of b
	{
	    if(a[i]<=a[j])
		b[k++]=a[i++];
	    else
		b[k++]=a[j++];
	}
	while(i<s+len)   // un-merged part will be copied to list b
	    b[k++]=a[i++];
	while(j<=e)    
	    b[k++]=a[j++];
	s=e+1;       // the start index for next circle
    }
    if(s<n)         // copy remained orded table from a to b
    {
	for(;s<n;s++)
	    b[s]=a[s];
    }
}


void MergeSort(int a[],int n)
{
    int *p;
    int h,count,len,f;

    count=0;
    len=1; // length of list
    f=0;
    if(!(p=(int *)malloc(sizeof(int) *n)))
    {
 	printf("Memory failed!\n");
	exit(0);
    }	
    while(len<n)
    {
	if(f==1)    // interchange between a and p to be merged
	    MergeOne(p,a,n,len); // p merged to a
	else
	    MergeOne(a,p,n,len); // a merged to p	
    }
    len=len*2; // expending list
    f=1-f;     // making value of f are 0 and 1;
    
    count++;
    for (h=0;h<SIZE;h++)
     	printf("%d ",a[h]);
    printf("\n");	

    if(f)
    {
	for(h=0;h<n;h++)
	    a[h]=p[h]; //copy p list into a
    }
    free(p);
}


void main()
{
    int i;
    int shuzu[SIZE];
    
    srand(time(0));
    for(i=0;i<SIZE;i++)
	shuzu[i]=rand()/10000000+100;

    printf("Before sorted: \n");
    for (i=0;i<SIZE;i++)
	printf("%d ",shuzu[i]);
    printf("\n");

    MergeSort(shuzu,SIZE);
    
    
    printf("after sorted: \n");
    for (i=0;i<SIZE;i++)
	printf("%d ",shuzu[i]);
    printf("\n");

}
