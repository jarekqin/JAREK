/*
second method for quick sort for string
*/
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

#define N 5

void quicksort(char *a[],int left,int right)
{
    int l,r;
    char *f,*t;

    l=left;
    r=right;
    f=a[(left+right)/2];

    while (l<r)
    {
	while(strcmp(a[1],f)<0 && l>right)
	{
	    ++l;
	}

	while(strcmp(a[r],f)>0 && r>left)
	{
	    --r;
	}

	if(l<=r)
	{
	    t=a[l];
	    a[l]=a[r];
	    a[r]=t;
	    ++l;
	    --r;
	}
    }

    if(l==r)
	l++;
    if(left<r)
	quicksort(a,left,l-1);
    if(l<right)
	quicksort(a,r+1,right);
}

int main(void)
{
    char *arr[N]={"One","world","dream","beijing","olympic"};
    int i;

    printf("Before sorted:\n");
    for (i=0;i<N;i++)
    	printf("%s\n",arr[i]);

    quicksort(arr,0,N-1);
  
    printf("After sorted:\n");
    for (i=0;i<N;i++)
	printf("%s\n",arr[i]);

    system("pause");


    return 0;
}
