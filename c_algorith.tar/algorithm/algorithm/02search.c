/*
search algorithm
*/

// half search
#include <stdio.h>
int *half_search(const int *p_num,int size,int num)
{
    const int *p_start=p_num, *p_end=&p_num[size-1],*p_mid=NULL;

    while (p_start<=p_end)
    {   // recording middle point of array, and give this to p_mid pointer
  	p_mid=p_start+(p_end-p_start+1)/2;

	if(*p_mid==num)
	{
	    return (int *)p_mid; // return searched number
	}

	else if(*p_mid<num)
	{
	    p_start=p_mid+1; // change p_start to index next to p_mid
	}

	else
	{
	    p_end=p_mid-1;// change p_end to index before p_mid
	}
    }

    return NULL;
}


// digui calculate extreme value
int FindArrayMax(int array[],int num)
{
    if(num==1)
	return array[0];

    if(array[0]>=FindArrayMax(array+1,num-1);
	return array[0];

    else
 	return FindArrayMax(array+1,num-1);
}


int main(void)
{
    int arr[]={10,20,30,40,50,60,70,80,90,100};
    int *p_num=NULL;
    
    printf("Type a number you want to search:");
    int num=0;
    scanf("%d",&num);

    p_num=half_search(arr,10,num);

    if (p_num)
    {
	printf("Found number is %d\n",*p_num);
    }

    else
    {
	printf("No number sarched\n");
    }

    return 0;
}
