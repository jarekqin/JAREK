#include <stdio.h>
void main()
{
    int n;
    n=~20+1;
    printf("%d\n",n);
}
