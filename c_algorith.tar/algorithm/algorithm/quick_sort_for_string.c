/*
algorithm book ->P130
*/
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

void quick_sort_string(char *a,int left,int right)
{
    int f,l,r,t;
    l=left;
    r=right;
    f=a[(left+right)/2];

    while(l<r)
    {
	while(a[l]<f)
	    ++l;
	while(a[r]>f)
	    --r;
	if(l<r)
	{
	    t=a[l];
	    a[l]=a[r];
	    a[r]=t;
	    ++l;
	    --r;
	}
    }
    if(l==r)
	l++;
    if(left<r)
	quick_sort_string(a,left,l-1);
    if(l<right)
	quick_sort_string(a,r+1,right);	
}

int main(void)
{
    char str[80];
    int N;

    memset(str,'\0',sizeof(str));
    printf("pleae type a string:");
    scanf("%s",str);
    
    N=strlen(str);

    printf("Before sorted:\n");
    printf("%s\n",str);
    
    quick_sort_string(str,0,N-1);
  
    printf("After sorted:\n");
    printf("%s\n",str);

    system("pause");
    return 0;
}
