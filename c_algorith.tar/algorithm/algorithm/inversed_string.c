#include <stdio.h>
#include <string.h>

void reversestr(char *s);

int main(void)
{
    char s[]="ABCDEFGHIJK";
    reversestr(s);
    printf("After inverse string is:%s\n",s);

    return 0;
}


void reversestr(char *s)
{
    int len=strlen(s)-1;
    int n=0;
    char tmp;

    while(n!=len && n<len)
    {
	tmp=s[n];
 	s[n]=s[len];
	s[len]=tmp;
	n++;
	len--;
    }
}

/* void reversestr(char *s,int len,int n)
{    
    char tmp;
    if(n<len)
    {
	tmp=s[len];
	s[len]=s[n];
	s[n]=tmp;
	reversestr(*s,len-1,n+1);
    }	
}
*/
