/*
montcarlo simulatioin to calculate
circle
*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

double MontePI(int n)
{
    double PI;
    double x,y;
    int i,sum;

    sum=0;
    srand(time(0));
    for(i=1;i<n;i++)
    {   // generate random number between 0 and 1
	x=(double)rand()/RAND_MAX;
	y=(double)rand()/RAND_MAX;
	if((x*x+y*y)<=1)
	    sum++;
    }
    PI=4.0*sum/n;
    return PI;
}

int main(void)
{
    int n;
    double PI;

    printf("Mont Carlo smulation.");
    printf("Type points: \n");
    scanf("%d",&n);
    PI=MontePI(n);
    printf("PI=%f\n",PI);    

    return 0;
}
