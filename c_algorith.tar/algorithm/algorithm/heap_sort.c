/*
heap sort-> algorithm book P 114
heap sort bases on sort algorithm with binarytree
*/
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define SIZE 10

void HeapSort(int a[],int n)
{
    int i,j,h,k;
    int t;

    for (i=n/2-1;i>=0;i--) // a[0,n-1] is root
    {
	while(2*i+1<n)    // no.i has right tree
	{
	    j=2*i+1;
	    if((j+1)<n)
	    {
		if(a[j]<a[j+1]) // if left tree<right tree
				// comparing right tree
		    j++;
	    }
	    if(a[i]<a[j]) // comparing i and j index of data
	    {
		t=a[i];   // exchange value
		a[i]=a[j];
	  	a[j]=t;
		i=j;     // heap is renuied, will be re-adjusted
 	    }

	    else   // compariing left and right nodes, if all greater
		   // no need to adjust
	    {
		break;
	    }
	}
    }

    // export as heap
    printf("Original data heap:");
    for (h=0;h<n;h++)
    {
	printf("%d ",a[h]);
    }

    printf("\n");

    for (i=n-1;i>0;i--)
    {
	t=a[0];
	a[0]=a[i];
	a[i]=t;
	k=0;
	while(2*k+1<i) // right tree of no.i node
	{
	    j=2*k+1;
	    if((j+1)<i)
	    {
		if(a[j]<a[j+1]) // right left tee less than right tree
				// comparing right tree
		    j++;       
	    }
	    if(a[k]<a[j]) // comparing i and j their data
	    {
		t=a[k];
		a[k]=a[j];
		a[j]=t;
	 	k=j;
	    }

	    else
	    {
		break;
 	    }
	}
        printf("No %d step result is:",n-i);
        for (h=0;h<n;h++)
        {
	    printf("%d ",a[h]);
    	}
    	printf("\n");
     }	
}


void main()
{
    int i;
    int shuzu[SIZE];

    srand(time(NULL));

    for (i=0;i<SIZE;i++)
    {
	shuzu[i]=rand()/10000000+100;
    }

    printf("Before sorted:\n");
    for (i=0;i<SIZE;i++)
    	printf("%d ",shuzu[i]);
    printf("\n");
    
    HeapSort(shuzu,SIZE);
    
    printf("After sorted:\n");
    
    for (i=0;i<SIZE;i++)
    	printf("%d ",shuzu[i]);
    printf("\n");
}
