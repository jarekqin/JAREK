/*
book P325
*/
#include <stdio.h>

void threeball(int red,int yellow,int green,int n)
{
    int i,j,k;

    printf("That could be several sets as below:\n");
    printf("\tRed\tYellow\tGreen\n");
    for (i=0;i<=3;i++)
    {
	for(j=0;j<=3;j++)
	{
	    for(k=0;k<=6;k++)
	    {
		if(i+j+k==n)
		    printf("\t%d\t%d\t%d\n",i,j,k);
	    }
	}
    }    
}

void main(void)
{
    int red,yellow,green;
    int n;
    printf("Type number of red balls:");
    scanf("%d",&red);
    printf("Type number of yellow balls:");
    scanf("%d",&yellow);
    printf("Type number of green balls:");
    scanf("%d",&green);
    printf("Type whole balls size:");
    scanf("%d",&n);
    threeball(red,yellow,green,n);
}
