/*
BOOK p243
*/
#include <stdio.h>
#define MAXNUM 20
#define MAXVALUE 65535
#define USED 0
#define NOL -1

typedef struct
{
    char Vertex[MAXNUM];
    int GType;
    int VertexNum;
    int EdgeNum;
    int EdgeWeight[MAXNUM][MAXNUM];
    int isTrav[MAXNUM];
}GraphMatrix;

void CreateGraph(GraphMatrix *GM)
{
    int i,j,k;
    int weight;
    char EstartV,EendV;

    printf("Type every node on each graph\n");
    for (i=0;i<GM->VertexNum;i++)
    {
	getchar();
	printf("No.%d node:",i+1);
	scanf("%c",&(GM->Vertex[i]));
    }
    
    printf("Type each weight value for each points\n");
    for (k=0;k<GM->EdgeNum;k++)
    {
	getchar();
	printf("No.%d edge: ",k+1);
  	scanf("%c %c %d",&EstartV,&EendV,&weight);
 	for (i=0;EstartV!=GM->Vertex[i];i++); //find start node in known point
	for (j=0;EendV!=GM->Vertex[j];j++);// find end node in known
	GM->EdgeWeight[i][j]=weight;// store found node with 1 edge
  	if(GM->GType==0)  // if this is non-direction graph
	    GM->EdgeWeight[j][i]=weight;  // strore weight at diagnal corner
    }
}


void ClearGraph(GraphMatrix *GM)
{
    int i,j;
    for (i=0;i<GM->VertexNum;i++)
    {
	for (j=0;j<GM->VertexNum;j++)
	    GM->EdgeWeight[i][j]=MAXVALUE;
    }
}


void OutGraph(GraphMatrix *GM)
{
    int i,j;
    for (j=0;j<GM->VertexNum;i++)
    {
	printf("\t%c",GM->Vertex[j]); // Output of 1st node  
    }
    printf("\n");

    for (i=0;i<GM->VertexNum;i++)
    {
	printf("%c",GM->Vertex[i]);
	for(j=0;j<GM->VertexNum;j++)
	{
	    if(GM->EdgeWeight[i][j]==MAXVALUE)
	    	printf("\tZ");
	    else
		printf("\t%d",GM->EdgeWeight[i][j]);
	}
    }
    printf("\n");
}



void PrimGraph(GraphMatrix GM)  // smallest trees generate
{
    int i,j,k,min,sum;
    int weight[MAXNUM];
    char vtempx[MAXNUM]; // temp points detail
    
    sum=0;
    for(i=0;i<GM.VertexNum;i++)    // stroing neighboured rows detail
    {
	weight[i]=GM.EdgeWeight[0][i];
	if(weight[i]==MAXVALUE)
	{
	    vtempx[i]=NOL;
	}
	else
	{
	    vtempx[i]=GM.Vertex[0]; // neighboured point
	}
    }
    vtempx[0]=USED;   			// optional
    weight[0]=MAXVALUE;
    for (i=1;i<GM.VertexNum;i++)
    {
	min=weight[0];			// min value
	k=i;
	for (j=1;j<GM.VertexNum;j++)
	{
	    if(weight[j]<min && vtempx[j]>0)  // finding unused min value
	    {
	 	min=weight[j];
		k=j; 				// sotring neighboured points number
	    }
	}
	sum+=min;  // weight cumsum
	printf("(%c,%c),",vtempx[k],GM.Vertex[k]);
	vtempx[k]=USED;	
	weight[k]=MAXVALUE;
 	for (j=0;j<GM.VertexNum;j++)
	{
	    if(GM.EdgeWeight[k][j]<weight[j] && vtempx[j]!=0)
	    {
		weight[j]=GM.EdgeWeight[k][j];
		vtempx[j]=GM.Vertex[k];
	    }
	}
    }
    printf("\n smallest generated tree sum of weights are:%d\n",sum);
}


int main(void)
{
    GraphMatrix GM;
    
    printf("Type which graph do you want:");
    scanf("%d",&GM.GType);
    printf("Type nodes numbers:");
    scanf("%d",&GM.VertexNum);
    printf("Type edges numbers:");
    scanf("%d",&GM.EdgeNum);
    ClearGraph(&GM);
    CreateGraph(&GM);
    printf("This graph has neighboured matrix data as below:\n");
    OutGraph(&GM);
    printf("Min tree edges are:");
    PrimGraph(GM);

    return 0;
}
