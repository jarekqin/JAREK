/*
BOOK p232
*/
#include <string.h>
#include <stdio.h>
#include <malloc.h>
#define NUM 41
#define KILLMAN 3

void Josephus(int alive)
{
    int man[NUM]={0};
    int count=1;
    int i=0,pos=-1;

    while(count<=NUM)
    {
	do{
	   pos=(pos+1) % NUM;
	   if(man[pos]==0)
	     	i++;
	    if(i==KILLMAN)
	    {
		i=0;
		break;
  	    }
 
	   } while(1);
	man[pos]=count;
	printf("No %2d person kill himself! Josephus circle number is %2d",pos+1,man[pos]);
	if (count % 2)
	    printf("->");
	else
	    printf("->\n");
 	count++;
	printf("\n");
    }
	printf("Next survived persons number should be at: %d\n",alive);
	alive=NUM-alive;
	for (i=0;i<NUM;i++)
	{
	    if(man[i]>alive)
		printf("Original number:%d, Josephus circle number:%d\n",i+1,man[i]);
	}
	printf("\n");
}

int main(void)
{
    int alive;
    printf("Type how many people should be survived: ");
    scanf("%d",&alive);
    Josephus(alive);
 
    return 0;
}
