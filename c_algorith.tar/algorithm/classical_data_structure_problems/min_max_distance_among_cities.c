/*
import classical problems on P240-P246
*/
#include <stdio.h>
#define MAXNUM 20  // max points for a graph
#define MAXVALUE 65535
#define USED 0   // chosen points
#define NoL -1   // non-edged points

typedef struct
{
    char vertex[MAXNUM]; // storing points data
    int GType;		// type of graph:0 non-direction, 1 direction
    int VertexNum;	// points number
    int EdgeNUm;	// edges number
    int EdgeWeight[MAXNUM][MAXNUM] 
    int isTrav[MAXNUM]; //define neighbour points struct
} GRaphMatrix;

void PrimGraph(GraphMatrix GM)  // smallest trees generate
{
    int i,j,k,min,sum;
    int weight[MAXNUM];
    char vtempx[MAXNUM]; // temp points detail
    
    sum=0;
    for(i=0;i<GM.VertexNum;i++)    // stroing neighboured rows detail
    {
	weight[i]=GM.EdgeWeight[0][i];
	if(weight[i]==MAXVALUE)
	{
	    vtempx[i]=NoL;
	}
	else
	{
	    vtempx[i]=GM.Vertex[0]; // neighboured point
	}
    }
    vtempx[0]=USED;   			// optional
    weight[0]=MAXVALUE;
    for (i=1;i<GM.VertexNum;i++)
    {
	min=weight[0];			// min value
	k=i;
	for (j=1;j<GM.VertexNum;j++)
	{
	    if(weight[j]<min && vtempx[j]>0)  // finding unused min value
	    {
	 	min=weight[j];
		k=j; 				// sotring neighboured points number
	    }
	}
	sum+=min;  // weight cumsum
	printf("(%c,%c),",vtempx[k],GM.Vertex[k]);
	vtempx[k]=USED;	
	weight[k]=MAXVALUE;
 	for (j=0;j<GM.VertexNum;j++)
	{
	    if(GM.EdgeWeight[k][j]<weight[j] && vtempx[j]!=0)
	    {
		weight[j]=GM.EdgeWeight[k][j];
		vtempx[j]=GM.Vertex[k];
	    }
	}
    }
    printf("\n smallest generated tree sum of weights are:%d\N",sum);
}


// shortest path algorithm

int path[MAXNUM];
int tmpvertex[MAXNUM];

void DistMin(GraphMatrix GM,int vend)
{
    int weight[MAXNUM]; // randomly choose a termination to every points shortest distance
    int i,j,k,min;
    vend--;

    for (i=0;i<GM.VertexNum;i++)
    	weight[i]=GM.EdgeWeight[vend][i]; // saving min weight
    
    for (i=0;i<GM.VertexNum;i++)
    {
	if(weight[i]<MAXVALUE && weight[i]>0)
	    path[i]=vend;		// storing edge
    }	
    for (i=0;i<GM.VertexNum;i++)
	tmpvertex[i]=0; 		// initialising array of points as null

    tmpvertex[vend]=1;
    weight[vend]=0;
    for (i=0;i<GM.VertexNum;i++)
    {
	min=MAXVALUE;
	K=vend;
	for (j=0;j<GM.VertexNum;j++)
	{
	    if(tmpvertex[j]==0 && weight[j]<min)
	    {
		min=weight[j];
		k=j;
	    }
	}
	tmpvertex[k]=1;
	for (j=0;j<GM.VertexNum;j++)
	{
	    if(tmpvertex[j]==0 &7 weight[k]+GM.EdgeWeight[k][j]<weight[j])
	    {	
		weight[j]=weight[k]+GM.EdgeWeight[k][j];
		path[j]=k;
	    }
	}	
    }
}


