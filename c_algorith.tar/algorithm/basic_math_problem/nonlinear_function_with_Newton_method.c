/*
book P190
*/
#include <stdio.h>
#include <math.h>

double func(double x)
{
    return x*x*x*x-3*x*x*x+1.5*x*x-4;
}

// derivative function
double dfunc(double x)
{
    return 4*x*x*x-9*x*x+3*x;
}

int NewtonMethod(double *x,int maxcyc,double precision)
{
    double x0,x1;
    int i;
    x0=*x;
    i=0;
    while(i<maxcyc)
    {
	if(dfunc(x0)==0.0)
	{
	    printf("Interation process is 0 for derivatives!\n");
	    return 0;
	}

    	x1=x0-func(x0)/dfunc(x0);
    	if(fabs(x1-x0)<precision || fabs(func(x1))<precision) // arrive at exponential condition
    	{	
	    *x=x1;
	    return 1;
     	}

    	else
	    x0=x1;
    	i++;
    }
    printf("Interation rounds has been more than precision, and no results arrive!\n");
    return 0;
}



int main(void)
{
    double x,precision;
    int maxcyc,result;
    x=2.0;
    maxcyc=1000;
    precision=0.00001;

    result=NewtonMethod(&x,maxcyc,precision);
    if(result==1)
	printf("Function x*x*x*x-3*x*x*x+1.5*x*x-4.0=0\n root at nearby 2.0 is:%lf\n",x);
    else
	printf("Failed\n");


    return 0;
}
