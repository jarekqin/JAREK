/*
book P174
*/
#include <stdio.h>
#include <math.h>
#include <stdlib.h>

void cyclotomic(int n)
{
    int i,s;
    double k,len;
    i=0;
    k=3.0;
    len=1.0;
    s=6;
    while(i<=n)
    {
	printf("No.%2d times cutting, the %5d shape, PI=%.24f\n",i,s,k*sqrt(len));
	s*=2;
 	len=2-sqrt(4-len);
 	i++;
	k*=2.0;
    }
}


// jishu
double JinshuPI()
{    
    double PI,temp; // fen zi
    int n,m;   // fen mu
    n=1;
    m=3;
    temp=2;
    PI=2;

    while (temp>1e-15)
    {
	temp=temp*n/m;
	PI+=temp;
  	n++;
	m+=2;
    }
    return PI;
}



int main(void)
{
    int n;
    printf("Type cutting times:");
    scanf("%d",&n);
    cyclotomic(n);
    
    double PI;
    PI=JinshuPI();
    printf("PI=%f\n",PI);
    return 0;
}
