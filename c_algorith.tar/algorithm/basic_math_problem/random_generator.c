/*
Generator of random number P154-P161
*/
#include <stdio.h>
#include <time.h>
#include <stdlib.h>

/*
// Q1 generate 0~100 random number
int main(void)
{
    int i,j;

    srand((int)time(0));
    for (j=0;j<10;j++)
    {
	for (i=0;i<10;i++)
	    printf("%d\t",(rand() % 100+1));
    }
    printf("\n");
    
    system("pause");
    return 0;
}
*/


// Q2 generate 0 to 1 random
double Rand_0_1(double *r)
{
    double base,u,v,p,temp1,temp2,temp3;
    base=256.0;
    u=17.0;
    v=139.0;
    temp1=u*(*r)+v; // total value
    temp2=(int) (temp1/base); // shang
    temp3=temp1-temp2*base; // yu shu
    *r=temp3; // refresh random seed for next round
    p=*r/base;
    return p;
}

/*
void main()
{
    //int i; // for random number 0 to 1
    int i,m,n; // for random nubmer among 100~200 as int
    //double r;  generate 10 random number between 0 and 1
    //double r,m,n; // genrating 10~20 floating random numbers
    double r;
    r=5.0;
    //m=10.0;
    //n=20.0;
    m=100;
    n=200;
    //printf("Genrate 10 random numbers among 10 and 20:\n");
    //printf("Genrate 10 random numbers among 0 and 1:\n");
    printf("Genrate 10 int random numbers among 100 and 200:\n");
    for (i=0;i<10;i++)
    	//printf("%10.5lf\n",(int)(Rand_0_1(&r)*(n-m))+m);
  	printf("%d\t",m+(int)((n-m)*Rand_0_1(&r)));

    printf("\n");
}
*/


// Q4 generateing random number follow by normal distribution
double Rand_normal(double u,double t,double *r)
{
    int i;
    double total=0.0;
    double result;
    for(i=0;i<12;i++)
    	total+=Rand_0_1(r);
    result=u+t*(total-6.0); //random number
    return result;
}


void main()
{
    int i;
    double r,u,t;
    r=0.0;
    u=0.0;
    t=1.0;

    printf("10 normal random numbers:\n");
    for (i=0;i<10;i++)
	printf("%10.5f\n",Rand_normal(u,t,&r));
    printf("\n");
}


