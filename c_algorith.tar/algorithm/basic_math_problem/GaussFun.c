/*
Guassin function P184
*/
#include <stdio.h>
#include <math.h>

#define MAXNUM 10 // maximum value of variables
int array[MAXNUM][MAXNUM]={{3,5,-4,0},{7,2,6,-4},{4,-1,5,-5}};;// expanding matrix
int unuse_result[MAXNUM];// verify is unconcered variable

int GaussFun(int equ,int var,int result[])
{
    int i,j,k,col,num1,num2;
    int max_r,ta,tb,gcdtemp,lcmtemp;
    int temp,unuse_x_num,unuse_index;
    col=0;  				// from 1st column
    for(k=0;k<equ && col<var;k++,col++) // circling for expanding matrix
    {
	max_r=k;			// restoring the max rows value of abs value
  	for(i=k+1;i<equ;i++)
	{
	    if(abs(array[i][col])>abs(array[max_r][col]))
		max_r=i;    		// restoring the abs(biggest rows value)
	}
	if(max_r!=k)			// if max rows is not where we are
					// exchanging with k
	{ 
	    for (j=k;j<var+1;j++)       // exchange data on the right coner
	    {
		temp=array[k][j];
		array[k][j]=array[max_r][j];
		array[max_r][j]=temp;
	    }
	}
	if(array[k][col]==0)            // if there is 0 under the k rows with col column
					// continues to next column
	{
	    k--;
	    continue;
	}
	for(i=k+1;i<equ;i++)
	{
	    if(array[i][col]!=0)
	    {
		num1=abs(array[i][col]);
		num2=abs(array[k][col]);
		while(num2!=0)
		{
		    temp=num2;
		    num2=num1 % num2;
		    num1=temp;
		}
		gcdtemp=num1;           // meax public number
		lcmtemp=(abs(array[i][col])*abs(array[k][col]))/gcdtemp;
					// min public timer number
	    ta=lcmtemp/abs(array[i][col]);
	    tb=lcmtemp/abs(array[k][col]);
	    if(array[i][col]*array[k][col]<0)  // if 2 numbers have different symbols
	    	tb=-tb;			// adding them if different symbols

	    for(j=col;j<var+1;j++)
		array[i][j]=array[i][j]*ta-array[k][j]*tb;
	    }
	}	
    }
    
    for (i=k;i<equ;i++)
    {
	if(array[i][col]!=0)
	    return -1;   		// no result if return -1
    }

    if(k<var)
    {
	for(i=k-1;i>=0;i--)
	{
	    unuse_x_num=0;  		// verifying unused variable at this row
	    for (j=0;j<var;j++)
	    {
		if(array[i][j]!=0 && unuse_result[j])
		{
		    unuse_x_num++;
		    unuse_index=j;
		}
	    }
	    if(unuse_x_num>1)		// if greater than 1
		continue;
	    temp=array[i][var];
	    for(j=0;j<var;j++)
	    {
		if(array[i][j]!=0 && j!=unuse_index)
		    temp-=array[i][j]*result[j];
   	    }
	    result[unuse_index]=temp/array[i][unuse_index]; // getting this variable
	    unuse_result[unuse_index]=0;
	}
        return var-k;
    }
    for (i=var-1;i>=0;i--)
    {
	temp=array[i][var];
	for (j=i+1;j<var;j++)
	{
	    if(array[i][j]!=0)
	   	temp-=array[i][j]*result[j];
	}
	if(temp % array[i][i]!=0)
	    return -2;
 	result[i]=temp/array[i][i];
    }
    return 0; 
}


int main(void)
{
    int i,type;
    int equnum,varnum;
    int result[MAXNUM];    
    equnum=3;
    varnum=3;

    type=GaussFun(equnum,varnum,result);
    if(type==-1)
   	printf("no result!\n");
    else if(type==-2)
	printf("This function has float result, no interge result!\n");
    else if(type>0)
    {
	printf("This function has inifite result, free variables have %d\n",type);
	for(i=0;i<varnum;i++)
	{
	    if(unuse_result[i])
		printf("x%d is uncertain!\n",i+1);
	    else
		printf("x%d: %d\n",i+1,result[i]);
	}
    }
    else
    {
	printf("Result of this function is:\n");
	for (i=0;i<varnum;i++)
	    printf("x%d=%d\n",i+1,result[i]);
    }

    return 0;
}
