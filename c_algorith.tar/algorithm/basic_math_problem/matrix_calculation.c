/*matrix calculation gather
P177-P182
*/
#include <stdio.h>
#include <stdlib.h>

// plus
void MatrixPlus(double A[],double B[],int m,int n,double C[])
{
    int i;
    for(i=0;i<m*n;i++)
    {
	C[i]=A[i]+B[i];
    }
}


// minus
void MatrixMinus(double A[],double B[],int m,int n,double C[])
{
    int i;
    for (i=0;i<n*m;i++)
	C[i]=A[i]-B[i];
}


// Multiple is different to plus and minus as A' rows must be = B' columns
void MatrixMul(double A[],double B[],int m,int n,int k,double C[])
{
    int i,j,l,u;
    for (i=0;i<m;i++)
    {
	for (j=0;j<n;j++)
	{
	    u=i*k+j;
	    C[u]=0.0;
	    for (l=0;l<n;l++)
	  	C[u]+=A[i*n+l]*B[l*k+j];
	}
    } 
}


int main(void)
{
    double A[3][3]={{1.0,2.0,3.0},
		   {4.0,5.0,6.0},
		   {7.0,8.0,9.0}};
    double B[3][3]={{2.0,-2.0,1.0},
                     {1.0,3.0,9.0},
                     {17.0,-3.0,7.0}};
    double C[3][3];
    
    double A1[3][3]={{1.0,2.0,3.0},
		   {4.0,5.0,6.0},
		   {7.0,8.0,9.0}};
    double B1[3][3]={{2.0,-2.0,1.0},
                     {1.0,3.0,9.0},
                     {17.0,-3.0,7.0}};
    double C1[3][3];
    
    double A2[3][3]={{1.0,2.0,3.0},
		   {4.0,5.0,6.0},
		   {7.0,8.0,9.0}};
    double B2[3][3]={{2.0,-2.0,1.0},
                     {1.0,3.0,9.0},
                     {17.0,-3.0,7.0}};
    double C2[3][3];
    int m,n,i,j,k;
    m=3;
    n=3;
    k=3;

    printf("A+B result is:\n");
    MatrixPlus(A,B,m,n,C);
    for (i=0;i<m;i++)
    {
	for (j=0;j<n;j++)
	    printf("%10.6f ",C[i][j]);
        printf("\n");
    }

    printf("A-B result is:\n");
    MatrixMinus(A1,B1,m,n,C1);
    for (i=0;i<m;i++)
    {
	for (j=0;j<n;j++)
	    printf("%10.6f ",C1[i][j]);
        printf("\n");
    }

    printf("A*B result is:\n");
    MatrixMul(A2,B2,m,n,k,C2);
    for (i=0;i<m;i++)
    {
	for (j=0;j<n;j++)
	    printf("%10.6f ",C2[i][j]);
        printf("\n");
    }
    return 0;
} 
