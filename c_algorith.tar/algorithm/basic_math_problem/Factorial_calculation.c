/*
Factorial calculation->P170
*/
#include <stdio.h>
long fact(int n)
{
    int i;
    long result=1;
    for (i=1;i<=n;i++)
	result*=i;
    return result;
}

void main(void)
{
    int i;
    printf("Pleae type a interge number:\n");
    scanf("%d",&i);
    printf("%d factorial result is=%ld\n",i,fact(i));
}
