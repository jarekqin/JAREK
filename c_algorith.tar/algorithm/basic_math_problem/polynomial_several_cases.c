/*
polynomial cases P146-P153
*/
#include <stdio.h>

/*
// Q1 1 diamesion poly case
double polynomiallD(double a[],int n,double x)
{
    int i;
    double result;

    result=a[n-1];
    for (i=n-2;i>=0;i--)
    	result=result*x+a[i];
    return result;
}

void main()
{
    int i;
    static double a[7]={-15.0,-7.0,7.0,2.0,-3.0,7.0,3.0};
    static double x[6]={-2.0,-0.5,1.0,2.0,3.7,4.0};

    double result;
    for (i=0;i<6;i++)
    {
	result=polynomiallD(a,7,x[i]);
	printf("x=%5.2lf, p(x)=%13.7e\n",x[i],result);
    }
    printf("\n");
}
*/

/*
// 2 diamension poly case
double polynomial2D(double a[],int m,int n,double x,double y)
{
    int i,j;
    double result,temp,tt;
    result=0.0;
    tt=1.0;
    for (i=0;i<m;i++)
    {
	temp=a[i*n+n-1]*tt;
  	for(j=n-2;j>=0;j--)
	    temp=temp*y+a[i*n+j]*tt;
	result+=temp;
	tt*=x;
    }
    return result;
}

void main()
{
    double result;
    double x=0.5,y=-2.0;
    double a[4][5]={{1.0,2.0,3.0,4.0,5.0},
		 {6.0,7.0,8.0,9.0,10.0},
		 {11.0,12.0,13.0,14.0,15.0},
		 {16.0,17.0,18.0,19.0,20.0}};
    printf("2D polynomial result:\n");
    result=polynomial2D(a,4,5,x,y);
    printf("p(%2.1lf,%2.1lf)=%10.4e\n",x,y,result);
    printf("\n");
}
*/

/*
// Q3 MUltiplier case
void polynomial_mul(double A[],int m,double B[],int n,double R[],int k)
{
    int i,j;
    for (i=0;i<k;i++)
	R[i]=0;

    for (i=0;i<m;i++)
    {
	for (j=0;j<n;j++)
	    R[i+j]+=A[i]*B[j];
    }
}

void main()
{  
    int i;
    static double A[6]={-4.0,5.0,2.0,-1.0,3.0,2.0};
    static double B[4]={-3.0,-2.0,1.0,3.0};

    double R[9];

    polynomial_mul(A,6,B,4,R,9);
    printf("A(x)*B(x) results as below:\n");
    for (i=0;i<9;i++)
   	printf("R(%d)=%13.7e\n",i,R[i]);
    printf("\n");
}
*/


// Q4 substract case
void polynomial_div(double A[],int m,double B[],int n,double R[],int k,double L[],int l)
{
    int i,j,mm,ll;
    for (i=0;i<k;i++)
	R[i]=0.0;
    
    ll=m-1;
    for (i=k;i>0;i--)
    {
	R[i-1]=A[ll]/B[n-1];
 	mm=ll;
	for (j=1;j<=n-1;j++)
	{
	    A[mm-1]-=R[i-1]*B[n-j-1];
	    mm-=1;
	}
	ll-=1;
    }
    for(i=0;i<l;i++)
	L[i]=A[i];
}

void main()
{
    int i;
    static double A[5]={-3.0,6.0,-3.0,4.0,2.0};
    static double B[3]={-1.0,1.0,1.0};
    double R[3],L[2];
 
    printf("A(X)/B(x) result as below:\n");
    polynomial_div(A,5,B,3,R,3,L,2);
    for (i=0;i<=2;i++)
	printf("div R(%d)=%10.2e\n",i,R[i]);

    printf("\n");

    for (i=0;i<=1;i++)
	printf("remianed result L(%d)=%10.2e\n",i,L[i]);
    printf("\n");
}
