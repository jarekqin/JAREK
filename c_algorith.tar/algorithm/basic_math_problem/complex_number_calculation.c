/*
complex number 4 calculating methods
*/
#include <stdio.h>
#include <math.h>

void CPlus(double a,double b,double c,double d,double *e,double *f)
{
    *e=a+c;
    *f=b+d;
}


void CMinus(double a,double b,double c,double d,double *e,double *f)
{
    *e=a-c;
    *f=b-c;
}


void CMul(double a,double b,double c,double d,double *e,double *f)
{
    *e=a*c-b*d;
    *f=a*d+b*c;
}


void CDiv(double a,double b,double c,double d,double *e,double *f)
{
    double sq;
    sq=c*c+d*d;
    *e=(a*c+b*d)/sq;
    *f=(b*c-a*d)/sq;
}


// power of complex number
void CPowN(double a,double b,int n,double *e,double *f)
{
    double result;
    int i;
    *e=a;
    *f=b;

    if(n==1)
    	return;
    else
    {
	for (i=1;i<n;i++)
	    CMul(*e,*f,a,b,e,f);
    }
}


// exponential index calculation
void CExp(double a,double b,double *e,double *f)
{
    double temp;
    temp=exp(a);
    *e=temp*cos(b);
    *f=temp*sin(b);
}


// log calculation
void CLog(double a,double b,double *e,double *f)
{
    double temp;
    temp=log(sqrt(a*a+b*b));
    *e=temp;
    *f=atan2(b,a);
}


// sin(a+bi)
void CSin(double a,double b,double *e,double *f)
{
    double p,q;
    p=exp(b);
    q=1/p;
    *e=sin(a)*(q+p)/2.0;
    *f=cos(a)*(p-q)/2.0;
}


// cos(a+bi)
void CCos(double a,double b,double *e,double *f)
{
    double p,q;
    p=exp(b);
    q=1/p;
    *e=cos(a)*(q+p)/2.0;
    *f=-1.0*sin(a)*(p-q)/2.0;
}
void main(void)
{ 
    double a,b,c,d;
    double e,f;
    int n=5;
    double a1=1,b1=1,a2=3,b2=2,a3=2.0,b3=3.0,a4=1.0,b4=4.0;;
    a=4;b=6;c=2;d=-1;
    CPlus(a,b,c,d,&e,&f);
    printf("(%f+%fi)+(%f+%fi)=%f+%fi\n",a,b,c,d,e,f);
    CMinus(a,b,c,d,&e,&f); 
    printf("(%f+%fi)-(%f+%fi)=%f+%fi\n",a,b,c,d,e,f);
    CMul(a,b,c,d,&e,&f);
    printf("(%f+%fi)*(%f+%fi)=%f+%fi\n",a,b,c,d,e,f);
    CDiv(a,b,c,d,&e,&f);
    printf("(%f+%fi)/(%f+%fi)=%f+%fi\n",a,b,c,d,e,f);
    CPowN(a1,b1,n,&e,&f);
    printf("(%f+%fi)^%d=%f+%fi\n",a1,b1,n,e,f);
    CExp(a2,b2,&e,&f); 
    printf("power of e's(%f+%fi)=%f+%fi\n",a2,b2,e,f);
    CLog(a,b,&e,&f); 
    printf("Ln(%f+%fi)=%f+%fi\n",a3,b3,e,f);
    CSin(a4,b4,&e,&f);
    printf("Sin(%f+%fi)=%f+%fi\n",a4,b4,e,f);
    CCos(a4,b4,&e,&f);
    printf("Cos(%f+%fi)=%f+%fi\n",a4,b4,e,f);
}
