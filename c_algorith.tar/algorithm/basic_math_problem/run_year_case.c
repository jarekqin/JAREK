/*
run nian case P144
*/
#include <stdio.h>

int LeapYear(int year)
{
    if((year % 400==0) || (year % 100!=0) && (year % 4==0))
    	return 1;

    else
	return 0;
}

int main(void)
{
    int year;
    printf("Among 2000 and 3000 years. Total leap year are:\n");
    for (year=2000;year<=3000;year++)
    {
	if(LeapYear(year)==1)
	    printf("%d,",year);
    }
    getchar();
    return 0;
}
