/*
book P213
*/
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

double Chebxshev[11]={0.0000677106,-0.0003442342,0.0015397681,-0.0024467480,0.0109736958,
-0.0002109075,0.0742379071,0.0815782188,0.4118402518,0.4227843370,1.0};

double gamma(double x)
{
    int i;
    double t,u;
    double result;

    if(x<=0.0)
    {
	printf("Wrong type, x cannot be <0!\n");
	return -1.0;
    }
    if(x<=1.0)
    {
	t=1.0/(x*(x+1.0));
	x+=2.0;
    }
    else if(x<=2.0)
    {
	t=1.0/x;
	x+=1.0;
    }
    else if(x<=3.0)
    {
	t=1.0;
    }

    else
    {
	t=1.0;
	while(x>3.0)
	{
	    x-=1.0;
	    t=t*x;
	}
    }
    result=Chebxshev[0];
    u=x-2.0;
    for (i=0;i<=10;i++)
  	result=result*u+Chebxshev[i];
    result*=t;

    return result;
}


double beta(double x1, double x2)
{
    double result;
    result=gamma(x1)*gamma(x2)/gamma(x1+x2);
    return result;
}


int main(void)
{
    double x1,x2,y; 

    printf("Type x1 and x2 numbers: ");
    fflush(stdin);
    scanf("%lf %lf", &x1,&x2);
    y=beta(x1,x2);
    printf("When x1=%e and x2=%e, beta value=%e\n",x1,x2,y);

    return 0;
}
