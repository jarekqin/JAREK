/*
book P 198
*/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

double func(double x)
{
    double y;
    y=x*exp(-x*x);
    return y;
}

double jifen(double x1,double x2,double eps)
{
    int i,n;
    double fx1,fx2,h,t1,p,s,x;
    double result;

    fx1=func(x1);
    fx2=func(x2);
    n=1;
    h=x2-x1;
    t1=h*(fx1+fx2)/2.0;
    p=eps+1.0;
    while(p>=eps)
    {
	s=0.0;
	for(i=0;i<n;i++)
	{
	    x=x1+i*h+0.5*h;
	    s+=func(x);
	}
 	result=(t1+h*s)/2.0;
	n=2*n;
	t1=result;
	h=h/2.0;
	p=fabs(t1-result);
    }
    return result;
}



int main(void)
{
    double x1,x2,eps,t;
    printf("Pleae type scale for upper and lower limit: ");
    fflush(stdin);
    scanf("%lf %lf",&x1,&x2);
    printf("Pleae type accuracy: ");
    fflush(stdin);
    scanf("%lf",&eps);
    t=jifen(x1,x2,eps);
    printf("Result=%e\n",t);

    return 0;
}
