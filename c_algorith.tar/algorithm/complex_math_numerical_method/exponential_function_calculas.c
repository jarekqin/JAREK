/*
Book p225
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

double r=0.57721566490153286060651;
double t[5]={-0.9061798459,-0.5384693101,0.0,0.5384693101,0.9061798459};
double c[5]={0.2369268851,0.4786286705,0.5688888889,0.4786286705,0.2369268851};

double EXFunc(double x,double eps)
{
    int i,j;
    double h,w,q;
    double atemp,btemp,xtemp;
    double result;
    double p=1.0e35;
    double temp=0.1;

    int m=1;

    if (x==0)
  	x=1.0e-35;

    else if(x<0.0)
	x=-x;

    else
    {
    }	

    q=r+log(x);
    h=x;
    while((temp>=eps) && (fabs(h)>fabs(0.0001*x)))
    {
	result=0.0;
	for (i=1;i<=m;i++)
	{
	    w=0.0;
	    atemp=(i-1.0)*h;
	    btemp=i*h;
	    for(j=0;j<5;j++)
	    {
		xtemp=((btemp-atemp)*t[j]+(btemp+atemp))/2.0;
		w+=(exp(-xtemp)-1.0)/xtemp*c[j];
	    }
	    result+=w;
	}
	result=result*h/2.0;
	temp=fabs(result-p)/(1.0+fabs(result));
	m++;
	h=x/m;
	p=result;
    }
    result+=q;

    return result;    
}

int main(void)
{
    int count=0;
    int type=0;

    double x,y,eps;

    printf("Type value of x:");
    fflush(stdin);
    scanf("%lf",&x);
    printf("Type value of eps:");
    fflush(stdin);
    scanf("%lf",&eps);

    y=EXFunc(x,eps);
    printf("When x=%f, exponential calculas functoin result is %e\n",x,y);
    
    return 0;
}
