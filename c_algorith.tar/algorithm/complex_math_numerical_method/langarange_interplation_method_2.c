/*
book P194
*/
#include <stdio.h>
#include <stdlib.h>

double Lagrange(double x[], double y[],int n,double t)
{
    int i,j,k,m;
    double s;
    double result;

    result=0.0;
    if(n<1)
	return result;

    else if(n==1)
    {
	result=y[0];
	return result;
    }

    else if(n==2)
    {
	result=(y[0]*(t-x[1])-y[1]*(t-x[0]))/(x[0]-x[1]);
	return result;
    }

    else
    {
	i=0;
	while((x[i]<t) && (i<n))
	{
	    i=i+1;
	}
	k=i-4;
  	if (k<0)
	    k=0;
   	m=i+3;
	if(m>n-1)
	    m=n-1;
 	for(i=k;i<=m;i++)
	{
	    s=1.0;
	    for(j=k;j<=m;j++)
	    {
		if(j!=i)
		    s=s*(t-x[j])/(x[i]-x[j]);
	    }
	    result=result+s*y[i];
	}
    }
    return result;
}

int main(void)
{
    double t,z;
    char again;
    static double x[10]={0.1,0.15,0.3,0.4,0.5,0.6,0.7,0.85,0.9,1.00};
    static double y[10]={0.9,0.86,0.78,0.67,0.6,0.55,0.48,0.42,0.38,0.36};

    printf("Lagrange interplation method:\n");
  S1:
    printf("Type interplated points:");
    fflush(stdin);
    scanf("%lf",&t);

    z=Lagrange(x,y,10,t);
    printf("interplated point t=%6.3f, result z=%e\n",t,z);

  S2:
    printf("\nContinuesly(y/n)?");
    fflush(stdin);
    scanf("%c",&again);

    if(again=='y' | again=='Y')
    {
    	goto S1;
    }
    else if(again=='n' || again =='N')
    {
	goto S3;
    }
    else
    {
	goto S2;
    }

  S3:
    printf("Show ends up!\n");

    return 0;
}
