/*
book P201
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

double SQRT(double x,double eps)
{
    double result,t;
    t=0.0;
    result=x;
    while(fabs(result-t)>eps)
    {
	t=result;
	result=0.5*(t+x/t);
    }
    return result;
}


int main(void)
{
    double x,eps,t;

    printf("Pleae type a number: ");
    fflush(stdin);
    scanf("%lf",&x);
    printf("Please type accruacy: ");
    fflush(stdin);
    scanf("%lf",&eps);
    t=SQRT(x,eps);
    printf("result =%e\n",t);

    return 0;
}
