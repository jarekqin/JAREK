/*
book P198
*/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

double func(double x)
{
    double y;
    y=x*exp(-x*x);
    return y;
}

double jifen(double x1,double x2,double eps)
{
    int i,n;
    double fx1,fx2,h,t1,p,s,x;
    double result;

    fx1=func(x1); // upper limit
    fx2=func(x2); // lower limit
    n=1;
    h=x2-x1;
    t1=h*(fx1+fx2)/2.0;
    p=eps+1.0;
    while(p>=eps)
    {
	s=0.0;
	for (i=0;i<n;i++)
	{
	    x=x1+i*h+0.5*h;
	    s+=func(x);
	}
	result=(t1+h*s)/2.0;
	n=2*n;
	t1=result;
	h=h/2;
	p=fabs(t1-result);	
    }
    return result;
}

int main(void)
{
    char again;
    double x1,x2,eps,t;

  S1:
    printf("Type scale of calculas;");
    fflush(stdin);
    scanf("%lf %lf",&x1,&x2);
    printf("Type accuracy; ");
    fflush(stdin);
    scanf("%lf",&eps);

    t=jifen(x1,x2,eps);
    printf("Result=%e\n",t);
   
  S2:
    printf("\nContinusly(y/n)?");
    fflush(stdin);
    scanf("%c",&again);
    if(again=='y' || again=='Y')
	goto S1;
    else if(again=='n' || again=='N')
	goto S3;
    else
    {
	printf("Wrong, again\n");
	goto S2;
    }

  S3:
    printf("Ending up!\n");

    return 0;
}
