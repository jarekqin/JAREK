/*
book P318
*/

#include <stdio.h>

int fish(int yufu)
{
    int init;  // initial fisher numbers
    int n;     // cycling rounds
    int s;     // final round of last fisher got

    init=yufu+1;
    n=yufu-1;
    s=init;

    while(n)
    {
	s=5*s+1;
	n--;
    }

    return s;
}

int main(void)
{
    int num;
    int yufu;

    printf("Type fisher number:\n");
    scanf("%d",&yufu);
    num=fish(yufu);
    printf("There are %d fish caught\n",num);

    return 0;
}
