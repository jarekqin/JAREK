/*
book P303
*/

#include <stdio.h>
#include <stdlib.h>

typedef struct
{
    int x;
    int y;
} Coordinate;

int chessboard[8][8];
int curstep; // horse steps

Coordinate fangxiang[9]={{-2,1},{-1,2},{1,2},{2,1},{2,-1},{1,-2},{-1,-2},{-2,-1}};

void Move(Coordinate curpos)
{
    Coordinate next;
    int i,j;

    if(curpos.x<0 || curpos.x>7 || curpos.y<0 || curpos.y>7)
	return;

    if(chessboard[curpos.x][curpos.y]) // horse has passed through
	return;

    chessboard[curpos.x][curpos.y]=curstep; // storing step
    curstep++;
   
    if(curstep>64) // all blanks have been acorssed
    {
	for(i=0;i<8;i++) // exporting steps map
	{
	    for(j=0;j<8;j++)
	    	printf("%5d",chessboard[i][j]);
	printf("\n");
	}
        exit(0);
    }

    else
    {
	for(i=0;i<8;i++)
	{
	    next.x=curpos.x+fangxiang[i].x;
	    next.y=curpos.y+fangxiang[i].y;
	    if(next.x<0 || next.x>7 || next.y<0 || next.y>7)
	    {
	    }
	    else
		Move(next);
	}
    }
    chessboard[curpos.x][curpos.y]=0;  // clear steps number
    curstep--;
}

void main()
{
    int i,j;
    Coordinate start;
    
    printf("\n%d %d\n",fangxiang[7].x,fangxiang[7].y);
    printf("Type a original location of horse(x,y):");
    scanf("%d%d",&start.x,&start.y);
    if(start.x<1 || start.y<1 || start.x>8 || start.y>8)
    {
	printf("Wrong! Type again!\n");
	exit(0);
    }

    for(i=0;i<8;i++)
    {
	for(j=0;j<8;j++)
	    chessboard[i][j]=0;
    }

    start.x--;
    start.y--;
    curstep=1;
    Move(start);
}
