/*
book P315
*/
#include <stdio.h>
#include <string.h>

int count;
char color[]="rwbwwbrbwr";
int blue,white,red;

void swap(char *x,char *y)
{
    int i;
    char temp;
    temp=*x;
    *x=*y;
    *y=temp;
    count++;

    printf("After %d times exchange: ",count);
    for (i=0;i<(int)strlen(color);i++)
    	printf(" %c",color[i]);
    printf("\n");
}


void threeflags()
{
    while(color[white]=='b')
    {
	blue++;
	white++;
    }	
    while(color[red]=='r')
	red--;
    while(white<=red)
    {
	if(color[white]=='r')
	{
	    swap(&color[white],&color[red]);
	    red--;
	    while(color[red]=='r')
		red--;
	}
	while(color[white]=='w')
	    white++;
	if(color[white]=='b')
	{
	    swap(&color[white],&color[blue]);
	    blue++;
	    white++;
	}
    }
}


int main(void)
{
    int i;
    blue=0;
    white=0;
    red=strlen(color)-1;
    printf("3 flas original ranking:\n");
    for (i=0;i<=red;i++)
	printf(" %c",color[i]);
    printf("\n");

    threeflags();
    printf("After ranking:\n");
    for (i=0;i<(int)strlen(color);i++)
 	printf(" %c",color[i]);

    printf("\n");

    return 0;
}
