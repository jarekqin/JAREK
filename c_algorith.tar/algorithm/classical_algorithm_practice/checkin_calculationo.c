/*
book P287
*/
#include <stdio.h>

void BQBJ(int m,int n)
{
    int x,y,z;
    for(x=0;x<=n;x++)
    {
	for (y=0;y<=n;y++)
	{
	    z=n-x-y;
	    if(z>0 && z%3==0 && x*5+y*3+z/3==m)
	    	printf("Big: %d,middle: %d, small: %d\n",x,y,z); 
	    else
	    {
   	    }
	}
    }
}

int main(void)
{
    int m,n;
    m=100;
    n=100;
    printf("%d money can buy %d checken results is : \n",m,n);
    BQBJ(m,n);

    return 0;
}
