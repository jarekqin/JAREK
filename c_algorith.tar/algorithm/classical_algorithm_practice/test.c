#include <stdio.h>

int main(void)
{
    int *p=NULL;
    int array[5]={1,2,3,4,5};
    p=array;
    for (int i=0;i<5;i++)
 	printf("%d\n",p[i]);

    return 0;
}
