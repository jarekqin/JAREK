/*
book P307
*/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int icount=0;
int weizhi[8];

void Output()
{
    int i,j,flag=1;
    printf("No.%2d method(* represents queen):\n",++icount);
    printf(" ");
    for(i=1;i<=8;i++)
    {
	printf(" |");
  	for (j=0;j<8;j++)
	{
	    if(weizhi[i]-1==j)
		 printf("*");
	    else
	    {
		if(flag<0)
		    printf(" ");
		else
		    printf("@");
	    }
	    flag=-1*flag;
	}
	printf(" |");
	flag=-1*flag;
    }
    printf(" ");
    for (i=1;i<=8;i++)
    {
	printf("*");
    }
    printf("\n");
    getchar();
}



void EightQueen(int n)
{
    int i,j;
    int ct;
    if(n==8)
    {
	Output();
	return;
    }

    for (i=1;i<=8;i++)  // try
    {
	weizhi[n]=i;
	ct=1;
	for (j=1;j<8;j++)
	{
	    if(weizhi[j]==weizhi[n]) // attacked
		ct=0;
	    else if (abs(weizhi[j]-weizhi[n])==(n-j))  // attacking
		ct=0;
	    else
	    {
 	    }
	}
	if (ct==1)  // no attacking for next try
	    EightQueen(n+1); // digui
    }
}

void main(void)
{
    printf("8 Queens list:\n");
    EightQueen(0);
}
