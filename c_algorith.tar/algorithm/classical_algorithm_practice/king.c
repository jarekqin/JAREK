/*
book P293
*/
#include <stdio.h>

double mai(int n)
{
    int i;
    double temp,sum;
    temp=1;
    sum=0;

    for (i=1;i<=n;i++)
    {
	sum=sum+temp;
	temp=temp*2;
    }
    return sum;
}

int main()
{
    int n;
    double sum;

    printf("Type a number:");
    scanf("%d",&n);
    sum=mai(n);
    printf("Sum of results is :%f\n",sum);
    printf("TOtal has %.2f tuns. \n",sum/25000/1000);

    return 0;
}
