/*
book P295
*/
#include <stdio.h>

long count;

void hanoi(int n,char a,char b,char c)
{
    if (n==1)
	printf("No.%d time movement:\t circle is moved from %c to %c\n", \
		++count,a,c);
    else
    {
	hanoi(n-1,a,c,b);
	printf("No.%d time movement:\t circle is moved from %c to %c\n", \
		++count,a,c);
	hanoi(n-1,b,a,c);
    }
}

int main(void)
{
    int n;
    count=0;
    printf("Typle number of circles:");
    scanf("%d",&n);
    hanoi(n,'A','B','C');
    printf("Done! Total needs %ld steps!\n",count);

    return 0;
}
