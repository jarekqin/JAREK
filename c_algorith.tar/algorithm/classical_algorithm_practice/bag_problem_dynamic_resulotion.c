/*
book P299
*/
#include <stdio.h>
#include <stdlib.h>

typedef struct goods
{
    double *value;
    double *weight;
    char *isSelect;
} GType;

double maxvalue;
double totalvalue;
double maxwt;
int num;
char *seltemp;

void backpack(GType *goods, int i, double wt,double vt)
{
    int k;
    if (wt+goods->weight[i]<=maxwt)
    {
	seltemp[i]=1;
	if(i<num-1) // if this is not the final one
	{
	    backpack(goods,i+1,wt+goods->weight[i],vt); // adding others
	}
	else
	{
	    for(k=0;k<num;++k)
		goods->isSelect[k]=seltemp[k];
	    maxvalue=vt;
	}
    }
    
    seltemp[i]=0;// cancel goods status
    if (vt-goods->value[i]>maxvalue)
    {
  	if(i<num-1)
	{
	    backpack(goods,i+1,wt,vt-goods->value[i]);
	}
   	 else
    	{
	    for(k=0;k<num;k++)
	    	goods->isSelect[k]=seltemp[k];
    	 maxvalue=vt-goods->value[i];
    	}
    }
}

int main(void)
{
    double sumweight;
    GType goods;
    int i;
    int lend,lenc;

    printf("Type max weight for this bag:");
    scanf("%lf",&maxwt);
    printf("Alternative goods:");
    scanf("%d",&num);

    lend=sizeof(double) *num;
    lenc=sizeof(char) *num;

    if(!(goods.value=(double *)malloc(lend)))
    {
	printf("Wrong!\n");
	exit(0);
    }

    if(!(goods.weight=(double *)malloc(lend)))
    {
	printf("Wrong!\n");
	exit(0);
    }

    if(!(goods.isSelect=(char *)malloc(lenc)))
    {
	printf("Wrong!\n");
	exit(0);
    }

    if(!(seltemp=(char *)malloc(lenc)))
    {
	printf("Wrong!\n");
	exit(0);
    }

    totalvalue=0;
    for(i=0;i<num;i++)
    {
	printf("Type No.%d goods its weight and value:",i+1);
	scanf("%lf%lf",&goods.weight[i],&goods.value[i]);
	totalvalue+=goods.value[i];
    }
    
    printf("\n Bag max weights is:%0.2f\n\n",maxwt);
    for(i=0;i<num;i++)
    {
	printf("No.%d goods weight is:%0.2f, value:%0.2f\n",i+1,goods.weight[i],goods.value[i]);
    }

    for (i=0;i<num;i++)
    	seltemp[i]=0;

    maxvalue=0;
    backpack(&goods,0,0.0,totalvalue);
    sumweight=0;
    printf("\n We can put below goods making value biggest\n");
    for (i=0;i<num;++i)
    {
	if(goods.isSelect[i])
	{
	    printf("No.%d goods, weight:%0.2f, value:%0.2f\n",i+1,goods.weight[i],goods.value[i]);
	    sumweight+=goods.weight[i];
	}
    }
    printf("\nOverall weight is: %0.2f, overall value is: %0.2f\n",sumweight,maxvalue);

    return 0;
}
