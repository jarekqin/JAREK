/*
book P291
*/

#include <stdio.h>

long peach(int n)
{
    int pe;
    if (n==1)
	return 1;
    else
	pe=(peach(n-1)+1)*2;

    return pe;
}

int main(void)
{
    int n;
    long peachnum;

    printf("Type days:");
    scanf("%d",&n);
    peachnum=peach(n);
    printf("Original peach has:%ld\n",peachnum);

    return 0;
}
