/*
book P320
*/
#include <stdio.h>
#include <string.h>

int jieti()
{
    int i,res;
    int count;
    count=7;

    for(i=1;i<=100;i++)
    {
	if((count % 2==1) && (count % 3==2) && (count %5 ==4) && (count % 6==5))
	{
	    res=count;
	    break;
	}
	count=7*(i+1);
    }
    return count;
}

void main()
{
    int num;
    num=jieti();
    printf("This lag has %d lags\n",num);
}
