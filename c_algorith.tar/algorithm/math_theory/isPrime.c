/*
Book P 276
*/
#include <stdio.h>
int isPrime(int n)
{
    int i;
    for (i=2;i<n;i++)
    {
	if(n % i==0)
	    return 0;
    }
    return 1;
}

int main(void)
{
    int i,n,count;
    n=1000;
    count=0;
    for (i=1;i<1000;i++)
    {
	if(isPrime(i)==1)
	{
	    printf("%7d",i);
	    count++;
	    if(count % 10==0)
	    	printf("\n");
	}
    }
    printf("\n");

    return 0;
}
