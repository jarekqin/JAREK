/*
book P277
*/
#include <stdio.h>
#include <math.h>

int isPrime(int n)
{
    int i;
    for (i=2;i<n;i++)
    {
	if(n % i==0)
	    return 0;
    }
    return 1;
}



int huiwen(int n)
{
    int temp,m,k,t,num,sum;
    int count,i;
    
    k=1;
    count=0;
    while(k>0)
    {
	k=n-(int)pow(10,count);
	count++;
    }
    m=count-1;

    sum=0;
    num=n;
    for(i=0;i<m;i++)
    {
	temp=num % 10;
	sum=sum+temp*((int)pow(10,m-1-i));
	num=(num-temp)/10;
    }

    t=sum;
    if(t==n)
    {
	if(isPrime(n))
	    return 1;
	else
	    return 0;
    }
    else
	return 0;
}

int main(void)
{
    int i,count;
    count=0;
    for(i=10;i<50000;i++)
    {
	if(huiwen(i)==1)
	{
	    printf("%7d",i);
	    count++;
	    if(count % 10==0)
	  	printf("\n");
	}
    }
    printf("\n");

    return 0;
}
