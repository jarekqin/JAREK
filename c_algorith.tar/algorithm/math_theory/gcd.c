/*
book P272-275
*/
#include <stdio.h>

int gcd(int a,int b)
{
    int m,n,r;
    if(a>b)
    {
	m=a;
	n=b;
    }

    else
    {
	m=b;
	n=a;
    }

    if(n==0)
   	return m; // return another number as gcd
    if(m % 2==0 && n % 2==0)
	return 2*gcd(m/2,n/2); // if m,n are both event number

    if(m%2==0)
	return gcd(m/2,n);     // if m is event number

    if(n % 2==0)
	return gcd(m,n/2);    // if n is event number

    return gcd((m+n)/2,(m-n)/2); // if m,n are both add number    
}

int lcm(int a,int b)
{
    int c,d;

    c=gcd(a,b);
    d=(a*b)/c;
    return d;
}


int main(void)
{
    int a,b;
    printf("Type 2 integer numbers:");
    scanf("%d %d",&a,&b);
    printf("GCD of %d and %d is %d\n",a,b,gcd(a,b));
    printf("LCM of %d and %d is %d\n",a,b,lcm(a,b));

    return 0;
}
