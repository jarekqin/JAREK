/*
book P284
*/
#include <stdio.h>

int isPrime(int n)
{
    int i;
    for (i=2;i<n;i++)
    {
	if(n % i==0)
	    return 0;
    }
    return 1;
}

void PrimeFactor(int n)
{
    int i;
    if(isPrime(n))
    	printf("%d*",n);

    else
    {
	for(i=2;i<n;i++)
	{
	    if(n % i==0)
  	    {
	    	printf("%d*",i);
	    	if(isPrime(n/i))
	    	{
		    printf("%d",n/i);
		    break;
	    	}
	    	else
		    PrimeFactor(n/i);
	     break;
	    }
	}
    }
}

int main(void)
{
    int n;
    printf("Please type a integer number: \n");
    scanf("%d",&n);
    printf("n=%d=",n);
    PrimeFactor(n);
    printf("\n");

    return 0;
}
