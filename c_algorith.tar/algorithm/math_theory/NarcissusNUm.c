/*
Book P263
*/
#include <stdio.h>
#include <math.h>

void NarcissusNum(int n)
{
    long i,start,end,temp,num,sum;
    int j;
    
    start=(long)pow(10,n-1);
    end=(long)pow(10,n)-1;
    for (i=start;i<end;i++)
    {
	temp=0;
   	num=i;
	sum=0;
	for (j=0;j<n;j++)
	{
	    temp=num % 10;
	    sum=sum+(long)pow(temp,n); // cumsum of n power of number
	    num=(num-temp)/10;
	}
	if(sum==i)
	    printf("%ld\n",i);
    }	
}


int main(void)
{
    int n;
    n=3;
    printf("Listing %d digits number's shuixian flower number: \n",n);
    NarcissusNum(n);
    printf("\n");
    n=4;
    printf("Listing %d digits number's shuixian flower number: \n",n);
    NarcissusNum(n);
    printf("\n");

    return 0;
}
