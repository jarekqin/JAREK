/*
Book P267
*/
#include <stdio.h>
#include <math.h>

int zishounum1(long n)
{
    long temp,m,k;
    int count;

    k=1;
    count=0;
    while (k>0)
    {
	k=n-(long)pow(10,count);
	count++;
    }

    m=count-1;
    temp=(n*n) % ((long) (pow(10,m)));
    if(temp==n)
	return 1;
    else 
	return 0;
}

int zishounum2(long num)
{
    long faciend,mod,n_mod,p_mod; // mod is variable that being multiplied, n_mod is multiplier's variable
    				  // p_mode is partial cumprod variable
    long t,n;
    faciend=num;	// multiplied number
    mod=1;
    do
    {
	mod*=10;
	faciend/=10;
    }while(faciend>0);

    p_mod=mod;  // circling to calculate multiplier's variable
    faciend=0;  // cutting part of variable of p_mod down
    n_mod=10;
   
    while(mod>0)
    {
	t=num % (mod*10);
	n=num % n_mod-num % (n_mod/10);
	t=t*n;
	faciend=(faciend+t) % p_mod;
    	mod/=10;
	n_mod*=10;
    }
    if(num==faciend)
	return 1;
    else
	return 0;
}

int main(void)
{
    long i;
    printf("1st method:\n");
    for (i=2;i<1000;i++)
    {
	if(zishounum1(i)==1)
	    printf("%ld ",i);
    }
    printf("\n");
  
    printf("2nd method:\n");
    for (i=2;i<200000;i++)
    {
	if(zishounum2(i)==1)
	    printf("%ld ",i);
    }
    printf("\n");

    return 0;
}
