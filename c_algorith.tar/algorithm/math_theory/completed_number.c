/*
Book P258
*/
#include <stdio.h>
void Perfectnum(long fanwei)
{
    long p[300];  // storing deviding factors
    long i,j,k,sum,num,count;
    
    for (i=1;i<fanwei;i++)
    {
	count=0;
	num=i;
	sum=num;
	for (j=1;j<num;j++)
	{
	    if(num % j==0)
	    {
		p[count++]=j;  // storing factor
		sum=sum-j;     // minus a facto
	    }
	}
 	if (sum==0)
	{
	    printf("%4ld is a perfect number, factor is",num);
	    printf("%ld=%ld",num,p[0]);
	    for (k=1;k<count;k++)
	    	printf("+%ld",p[k]);
	    printf("\n");
	}
    }
}

int main(void)
{
    long fanwei;
    fanwei=10000;
    printf("Searched result as perfect NUmber is within %ld:\n",fanwei);
    Perfectnum(fanwei);

    return 0;
}
