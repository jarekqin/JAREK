#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Feb  4 16:18:41 2019

@author: me
"""

# 1,2,5三个数让它们和等于100组合个数
# 通过求解x+2y+5z=100来求解x+5z是偶数而且满足x+5z<=100个数
def combinationCount(n):
    count=0
    m=0
    while m<=n:
        count+=(m+2)//2
        m+=5
    return count

if __name__=='__main__':
    print(combinationCount(100))
    
