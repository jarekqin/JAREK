#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Feb  4 16:28:01 2019

@author: me
"""

# 100个灯泡开关问题（经典）
def factorIsOdd(a):
    total=0
    i=1
    while i<=a:
        if a % i==0:
            total+=1
        i+=1
    if total % 2==1:
        return 1
    else:
        return 0
    
def count(num,n):
    count=0
    i=0
    while i<n:
        # 判断因子数是否是奇数，如果是奇数（灯亮）,那么加1
        if factorIsOdd(num[i])==1:
            print('亮着的灯编号是:',num[i])
            count+=1
        i+=1
    return count

if __name__=='__main__':
    num=[0]*100
    i=0
    while i<100:
        num[i]=i+1
        i+=1
    count=count(num,100)
    print('最后总共有',count,'盏灯亮着')