#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Feb  4 16:12:06 2019

@author: me
"""

# 等概从数组中选择指定个数的数字
# 从n个书中抽取一个数的概率是1/n,没抽中概率是(n-1)/n
# 由此再从n-1个书中抽取一个数的概率依然位1/n
# ((n-1)/n)*(1/(n-1))=1/n
# 时间复杂度:O(N)

import random
def getRandom(arr,n,m):
    if not arr or n<=0 or m<=0:
        return -1
    i=0
    while i<m:
        j=random.randint(i,n-1) # 获取i->i-1
        # 随机抽取元素放到元素当前第一位
        tmp=arr[i]
        arr[i]=arr[j]
        arr[j]=tmp
        i+=1

if __name__=='__main__':
    arr=[1,2,3,4,5,6,7,8,9,10]
    n=10
    m=6
    getRandom(arr,n,m)
    i=0
    while i<m:
        print(arr[i],end=' ')
        i+=1
        