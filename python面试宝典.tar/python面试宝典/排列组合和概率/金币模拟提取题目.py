#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Feb  4 15:45:13 2019

@author: me
"""

# 金币模拟提取题目
import random

def getMaxNum(n):
    if n<1:
        return 
    a=[0]*n
    i=0
    while i<n:
        a[i]=random.uniform(1,n)
        i+=1
    # 找出前四个房间中最多的金币数
    max4=0
    i=0
    while i<4:
        if a[i]>max4:
            max4=a[i]
        i+=1
    # 后面5个房间的金币数和前面四个房间中最大的金币数对比
    i=4
    while i<n-1:
        if a[i]>max4: # 能拿到的最多的金币
            return True
        i+=1
    return False

if __name__=='__main__':
    count=1000+0.0
    success=0
    i=0
    while i<count:
        if getMaxNum(10):
            success+=1
        i+=1
    print(success/count)