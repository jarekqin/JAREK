#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Feb  4 15:52:14 2019

@author: me
"""

# 求正整数n所有可能整数的和
# 用递归的方式求解某个数值的所有整数解
def getAll(sums,result,count):
    if sums<0:
        return -1
    # 数字的组合满足和sums的条件，打印所有组合
    if sums==0:
        print('\n')
        print('满足条件的组合')
        i=0
        while i<count:
            print(result[i],end=' ')
            i+=1
        print('\n')
        return
    # 打印debug信息，为了便于理解
    print('当前组合:')
    i=0
    while i<count:
        print(result[i],end=' ')
        i+=1
    print('\n')
    print('-'*30)
    # 确定组合中的下一个取值
    i=(1 if count==0 else result[count-1])
    print('--','i=',i,'count=',count,'--',end=' ')
    
    while i<=sums:
        result[count]=i
        count+=1
        getAll(sums-i,result,count) # 求和ｓｕｍｓ-i
        count-=1
        i+=1
    
def showall(n):
    if n<1:
        return -1
    result=[0]*n
    getAll(n,result,0)
    
if __name__=='__main__':
    showall(4)