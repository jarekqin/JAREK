#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Feb  3 19:20:00 2019

@author: me
"""

# 求出1,2,2,3,4,5序列中，4不在第三位，3,5不限量的排列组合串
# 转换成无相连通图，除了4不是第三个点，3和5不能相连外
# 其余遍历出来的值都放到set集合中
class Test:
    def __init__(self,arr):
        self.numbers=arr
        self.visited=[0]*len(self.numbers)
        # 图的二维数组表示
        self.graph=[([0]*len(self.numbers)) for i in range(len(self.numbers))]
        self.n=len(arr)
        # 数字的组合
        self.combination=''
        self.s=set()
        
    def depthFirstSearch(self,start):
        self.visited[start]=True
        self.combination+=str(self.numbers[start])
        if len(self.combination)==self.n:
            # 4 不出现在第三个位置
            if self.combination.index('4')!=2:
                self.s.add((self.combination))
        j=0
        while j<self.n:
            if self.graph[start][j]==1 \
                and self.visited[j]==False:
                self.depthFirstSearch(j)
            j+=1
        self.combination=self.combination[:-1]
        self.visited[start]=False
    # 功能性获取
    def getAllCombination(self):
        # 构造图
        i=0
        while i<self.n:
            j=0
            while j<self.n:
                if i==j:
                    self.graph[i][j]=0
                else:
                    self.graph[i][j]=1
                j+=1
            i+=1
        self.graph[3][5]=0
        self.graph[5][3]=0
        # 分别从不同的节点出发深度遍历图
        i=0
        while i<self.n:
            self.depthFirstSearch(i)
            i+=1
            
    def printAllCombination(self):
        print('一共有%d种组合' % len(self.s))
        print('组合具体明细请差看以下:')
        for strs in self.s:
            print(strs)
            
            
if __name__=='__main__':
    arr=[1,2,2,3,4,5]
    t=Test(arr)
    t.getAllCombination()
    t.printAllCombination()
    