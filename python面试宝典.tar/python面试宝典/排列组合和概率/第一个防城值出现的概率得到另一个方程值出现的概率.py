#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Feb  4 16:05:32 2019

@author: me
"""

# 用第一个方程值出现的概率得到另一个方程值出现的概率
# 调用方程１两次，生成一个二进制a2a1，由于方程１的结果０和１
# 出现概率都是0.5，则二进制的a2a1有四中结果,00,10,01,11
# 只要让结果＝＝００时候返回0,剩余返回１即可
import random
def func1():
    return int(round(random.random()))

def func2():
    # 0的返回概率０.25，1是0.75
    a1=func1()
    a2=func1()
    tmp=a1
    tmp|=(a2<<1)
    if tmp==0:
        return 0
    else:
        return 1
    
    
if __name__=='__main__':
    i=0
    while i<16:
        print(func2(),end=' ')
        i+=1
    print('\n')
    i=0
    while i<16:
        print(func2(),end=' ')
        i+=1
        