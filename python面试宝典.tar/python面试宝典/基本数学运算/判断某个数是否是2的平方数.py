#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Feb  2 22:51:16 2019

@author: me
"""

# 判断一个数是否是2的n次方
# 用Num&(num-1)来判断结果,如果==0就是
def is2Power(num):
    if num<1:
        return None
    m=num&(num-1)
    return m==0

if __name__=="__main__":
    if is2Power(8):
        print('8是2的n次方结果')
    else:
        print('8不是2的n次方结果')
    if is2Power(9):
        print('9是2的n次方结果')
    else:
        print('9不是2的n次方结果')
    if is2Power(16):
        print('16是2的n次方结果')
    else:
        print('16不是2的n次方结果')