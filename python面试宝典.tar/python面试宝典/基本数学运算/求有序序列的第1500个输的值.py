#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Feb  3 16:54:15 2019

@author: me
"""

# 求有序序列的第1500个输的值
# 次序列的所有数字都能被2/3/5整除
# 暴力方法：时间复杂度O(N)
def search1500th(n):
    i=0
    count=0
    i=1
    while 1:
        if i%2==0 or i%3==0 or i%5==0:
            count+=1
        if count==n:
            break
        i+=1
    return i

if __name__=='__main__':
    print(search1500th(1500))