#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Feb  3 17:51:47 2019

@author: me
"""

# 输出整数用二进制表示中1的总数
# 位与操作：时间复杂度O(M)

def countOne(n):
    count=0
    while n>0:
        if n!=0:
            n=n&(n-1)  # 作用是去掉二进制中的最后一位的1
        count+=1
    return count

if __name__=='__main__':
    print(countOne(7))
    print(countOne(8))