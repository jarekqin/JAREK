#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Feb  3 16:40:16 2019

@author: me
"""

# 判断1024!末尾有多少个0
# 寻找5的因字数总数相加
def zero1024(n=1024):
    count=0
    for i in range(n):
        n/=5
        count+=n
    return count

if __name__=='__main__':
    print('1024末尾有%d个0'%zero1024())
        