#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Feb  3 16:22:57 2019

@author: me
"""

# 用已知随机数生成器生成新的随机数生成器
import random
def rand7():
    return int(random.uniform(1,7))

def rand10():
    x=0
    while 1:
        x=(rand7()-1)*7+rand7()
        if x<=40:
            break
    return x%10+1
    

if __name__=='__main__':
    i=0
    while i!=10:
        print(rand10(),end=' ')
        i+=1