#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Feb  3 18:32:55 2019

@author: me
"""

# 不用^操作实现异或运算
def xor(x,y):
    return (x|y)&(~x|~y)


if __name__=='__main__':
    x=3
    y=5
    print(xor(x,y))