
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Feb  3 18:21:08 2019

@author: me
"""

# 计算一个数字的n次方
# 递归方法
# 当n=0->result=1
# n=1->result=d
# n>0且n是奇数->result=tmp*tmp*d;偶数->result=tmp*tmp
# n<0切n是奇数->result=1/(tmp*tmp*d);偶数->result=1/(tmp*tmp)
def power(d,n):
    if n==0:
        return 1
    if n==1:
        return d
    tmp=power(d,abs(n)//2)+0.0
    if n>0:
        if n% 2==1:
            return tmp*tmp*d
        else:
            return tmp*tmp
        
    else:
        if n % 2==1:
            return 1/(tmp*tmp*d)
        
        else:
            return 1/(tmp*tmp)
        
if __name__=='__main__':
    print(power(2,3))
    print(power(-2,3))
    print(power(2,-3))
    