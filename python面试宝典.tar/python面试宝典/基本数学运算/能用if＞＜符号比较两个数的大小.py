#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Feb  3 16:50:53 2019

@author: me
"""

# 不能用if,＞＜符号比较两个数的大小
def maxes(a,b):
    return ((a+b)+abs(a-b))/2


if __name__=='__main__':
    print(maxes(5,6))