#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Feb  2 23:01:47 2019

@author: me
"""

# 不用除法操作符实现两个正整数的除法
# 位移法->时间复杂度:O(LOG(M/N))
def divide(m,n):
    print('%d/%d' % (m,n),end=' ')
    result=0
    while m>=n:
        multi=1
        while multi*n<=(m>>1):
            multi<<=1
        result+=multi
        # 相减的结果进入下一次循环
        m-=multi*n
    print('商是:%d,余数是:%d'%(result,m))
    
    
# 扩展一：不用加减乘除运算实现加法
def myadd(a,b):
    sums=0 #保存不进位的想家结果
    carry=0 # 保存进位值
    while 1:
        sums=a^b # 异或代替不进位相加
        carry=(a & b)<<1 # 与操作代替计算进位值
        a=sums
        b=carry
        if carry==0:
            break
    return sums

# 扩展一：不用加减乘除运算实现减法
#def mysub(a,b):
#     return myadd(a,myadd(~b,1))

# 扩展二：不用加减乘除运算实现乘法
def multi(a,b):
    neg=(a>0)^(b>0)
    # 计算正数相乘结果，最后根据neg确定正负
    if b<0:
        b=myadd(~b,1)
    if a<0:
        a=myadd(~a,1)
        
    result=0
    # key:1.向左位移后的值，value：移位的次数
    bit_position=dict()
    i=0
    while i<32:
        bit_position[1<<i]=i
    while b>0:
        # 计算最后一位1的编号位置
        position=bit_position[b&~(b-1)]
        result+=(a<<position)
        b&=b-1
    if neg:
        result=myadd(~result,1)
    return result




if __name__=='__main__':
    m=14
    n=4
    divide(m,4)
    print('%d+%d=%d'% (m,n,myadd(m,n)))
#    print('%d-%d=%d'% (m,n,mysub(m,n)))
    print('%d*%d=%d'% (m,n,multi(m,n)))
    