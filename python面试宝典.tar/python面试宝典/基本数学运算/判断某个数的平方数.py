#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Feb  2 22:30:08 2019

@author: me
"""

# 判断一个数是否有平方底数
# 方法1：直接暴力搜索
# 时间复杂度：O(N^0.5)
def isPower(num):
    if not num or num<0:
        return None
    i=1
    while i<num:
        if i**2==num:
            return i
        i+=1
    return None


# 方法2：二分法
# 时间复杂度:O(LOGN)-->推荐
def find_power(n):
    low=1
    high=n
    while low<high:
        mid=(low+high)//2
        power_num=mid*mid
        if power_num>n:
            high=mid-1
        elif power_num<n:
            low=mid+1
        else:
            return mid
    return None


if __name__=='__main__':
    n1=100
    n2=16
    num1=isPower(n1)
    num2=isPower(n2)
    if num1 and num2:
        print('n1是%d的平方数,n2是%d的平方数' % (num1,num2))
    elif num1:
        print('n1是%d的平方数' % num1)
        print('n2不是任何数的平方')
    elif num2:
        print('n2是%d的平方数' % num2)
        print('n1不是任何数的平方')
    else:
        print('两个数都不是任何数的平方数')
        
    n3=20
    n4=9
    num3=find_power(n3)
    num4=find_power(n4)
    if num3 and num4:
        print('n3是%d的平方数,n4是%d的平方数' % (num3,num4))
    elif num3:
        print('n3是%d的平方数' % num3)
        print('n4不是任何数的平方')
    elif num4:
        print('n4是%d的平方数' % num4)
        print('n3不是任何数的平方')
    else:
        print('两个数都不是任何数的平方数')        
        