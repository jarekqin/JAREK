#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Feb  3 17:59:48 2019

@author: me
"""
# 找最小的不重复数
# 从左到右的贪心算法
# 时间复杂度：O(n²)
# 具体算法看书P249
def carry(num,pos):
    # 用于处理数字相加的进位
    while pos>0:
        if int(num[pos])>9:
            num[pos]='0'
            num[pos-1]=str(int(num[pos-1])+1)
        pos-=1
        
def getMinNum(n):
    count=0
    nChar=list(str(n+1))
    ch=[None]*(len(nChar)+2)
    ch[0]='0'
    ch[len(ch)-1]='0'
    i=0
    while i<len(nChar):
        ch[i+1]=nChar[i]
        i+=1
    lens=len(ch)
    # 从右向左遍历
    i=lens-2
    while i>0:
        count+=1
        if ch[i-1]==ch[i]:
            ch[i]=str(int(ch[i])+1) # 末尾+1
            carry(ch,i)
            # 把下标位i后面的字符变为0101
            j=i+1
            while j<lens:
                if (j-i)%2==1:
                    ch[j]='0'
                else:
                    ch[j]='1'
                j+=1
            # i位+1后，可能会与第i+1位相等
            i+=1
        else:
            i-=1
    print('循环次数为:',count)
    return int(''.join(ch))

if __name__=='__main__':
    print(getMinNum(23345))
    print(getMinNum(1101010))
    print(getMinNum(99010))
    print(getMinNum(8989))