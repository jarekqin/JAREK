#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Feb  3 19:17:11 2019

@author: me
"""

# 不用循环输出数字
# 递归方法
def prints(n):
    if n>0:
        prints(n-1)
        print(n,end=' ')
        
if __name__=='__main__':
    prints(100)