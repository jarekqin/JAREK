#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Feb  3 16:03:06 2019

@author: me
"""

# 只使用+=符号实现加减乘除
# 具体算法查看书本p240
def add(a,b):
    if a<0 and b<0:
        return -1
    if b>=0:
        i=0
        while i<b:
            a+=1
            i+=1
        return a
    else:
        i=0
        while i<a:
            b+=1
            i+=1
        return b
    
def minus(a,b):
    if a<b:
        return
    result=0
    while b!=a:
        b+=1
        result+=1
    return result

def multi(a,b):
    if a<=0 and b<=0:
        return
    result=0
    i=0
    while i<b:
        result=add(result,a)
        i+=1
    return result

def divide(a,b):
    if a<=0 and b<=0:
        return
    result=1
    tmpmulti=0
    while 1:
        tmpmulti=multi(b,result)
        if tmpmulti<=a:
            result+=1
        else:
            break
    return result-1

if __name__=='__main__':
    print(add(2,-4))
    print(minus(2,-4))
    print(multi(2,4))
    print(divide(9,4))