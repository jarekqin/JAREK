#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jan 30 17:38:03 2019

@author: me
"""

# 对有大量重复数字的序列排序
# 哈希表方法->时间复杂度O(N+MLOG2M)
# 必须使用快速排序才能得到MLOG2M的时间复杂度+一次遍历的O（N）
def QuickSort(arr,start,end):
    if not arr:
        return -1
    # 判断low是否小于high,如果为false,直接返回
    if start < end:
        i,j = start,end
        # 设置基准数
        base = arr[i]

        while i < j:
            # 如果列表后边的数,比基准数大或相等,前移一位直到有比基准数小的数出现
            while (i < j) and (arr[j] >= base):
                j = j - 1

            # 如找到,则把第j个元素赋值给第个元素i,此时表中i,j个元素相等
            arr[i] = arr[j]

            #同样的方式比较前半区
            while (i < j) and (arr[i] <= base):
                i = i + 1
            arr[j] = arr[i]
        # 做完第一轮比较之后,列表被分成了两个半区,
        # 并且i=j,需要将这个数设置回base
        arr[i] = base

        #递归前后半区
        QuickSort(arr, start, i - 1)
        QuickSort(arr, j + 1, end)
    return arr

def hash_sort(arr):
    if not arr :
        return -1
    data_count=dict()
    for i in range(len(arr)):
        if arr[i] not in data_count:
            data_count[arr[i]]=1
        else:
            data_count[arr[i]]+=1
    index=0
    for key,value in data_count.items():
        i=value
        while i>0:
            arr[index]=key
            index+=1
            i-=1
    return QuickSort(arr,0,len(arr)-1)
        

if __name__=='__main__':
    arr=[15,12,15,2,2,12,2,3,12,100,3,3]
    hash_sort(arr)
    for i in range(len(arr)):
        print(arr[i],end=' ')