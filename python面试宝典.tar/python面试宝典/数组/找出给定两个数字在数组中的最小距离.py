#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Jan 27 21:52:26 2019

@author: me
"""

# 求数组中两个元素的最小距离
# 暴力方法-> 时间复杂度O(N²)，太慢了
def mindistance(arr,num1,num2):
    if not arr:
        return -1
    mindist=2**32 # 两个数之间最小距离
    dist=0
    i=0
    while i<len(arr):
        if arr[i]==num1:
            j=0
            while j<len(arr):
                if arr[j]==num2:
                    dist=abs(i-j) # 当前遍历的两书之间距离
                    if dist<mindist:
                        mindist=dist
                j+=1
        i+=1
    return mindist


# 动态规划方法
def dynamic_min_distance(arr,num1,num2):
    if not arr:
        return -1
    lastnum1=-1
    lastnum2=-1
    min_dis=2**32
    i=0
    while i<len(arr):
        if arr[i]==num1:
            lastnum1=i
            if lastnum2>=0:
                min_dis=min(min_dis,abs(lastnum1-lastnum2))
        if arr[i]==num2:
            lastnum2=i
            if lastnum1>=0:
                min_dis=min(min_dis,abs(lastnum2-lastnum1))
        i+=1
    return min_dis

                

if __name__=="__main__":
    arr=[4,5,6,4,7,4,6,4,7,8,5,6,4,3,10,8]
    num1=4
    num2=8
    print('暴力方法结果是: ',mindistance(arr,num1,num2))
    print('动态规划的结果是: ',dynamic_min_distance(arr,num1,num2))