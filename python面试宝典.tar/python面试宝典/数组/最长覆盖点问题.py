#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jan 29 18:04:37 2019

@author: me
"""

# 求解坐标轴的多点覆盖最长长度问题
def maxCover(arr,L):
    if not arr or not L:
        return -1
    count=2
    maxCount=1 # 最大覆盖的点数
    start=0
    n=len(arr)
    i=0
    j=1
    while i<n and j<n:
        while (j<n) and (arr[j]-arr[i]<=L):
            j+=1
            count+=1
        j-=1
        count-=1
        if count>maxCount:
            start=i
            maxCount=count
        i+=1
        j+=1
    print("覆盖点坐标:")
    i=start
    while i<start+maxCount:
        print(arr[i])
        i+=1
    print('\n')
    return maxCount

if __name__=='__main__':
    arr=[1,3,7,8,10,11,12,13,15,16,17,19,25]
    print('最长覆盖点:',maxCover(arr,8))