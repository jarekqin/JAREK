#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Jan 27 01:21:09 2019

@author: me
"""

# 如何旋转数组
# 时间复杂度->O(N)->遍历两次全数组 
# 空间复杂度O(1)->使用了一个辅助空间
def swap(arr,low,high):
    while low<high:
        tmp=arr[low]
        arr[low]=arr[high]
        arr[high]=tmp
        low+=1
        high-=1
        
def rotateArr(arr,div):
    if not arr or div<0 or div>=len(arr):
        return
    # 不需要旋转
    if div==0 or div==len(arr)-1:
        return
    # 交换第一个子数组的内容
    swap(arr,0,div)
    # 第二组
    swap(arr,div+1,len(arr)-1)
    # 整个数组
    swap(arr,0,len(arr)-1)
    
if __name__=="__main__":
    arr=[1,2,3,4,5]
    rotateArr(arr,(0+len(arr))//2)
    i=0
    while i<len(arr):
        print(arr[i],end=' ')
        i+=1
        