#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jan 29 18:17:21 2019

@author: me
"""

# 按照要求构造新数组
def calculate(a,b):
    if not a or not b:
        return -1
    n=len(a)
    i=1
    while i<n:
        b[i]=b[i-1]*a[i-1] # 正向计算乘积
        i+=1
    b[0]=a[n-1]
    i=n-2
    while i>=1:
        b[i]*=b[0]
        b[0]*=a[i] # 逆向计算乘机
        i-=1
        
if __name__=='__main__':
    a=[1,2,3,4,5,6,7,8,9,10]
    b=[1]*len(a)
    calculate(a,b)
    i=0
    while i<len(b):
        print(b[i])
        i+=1
        