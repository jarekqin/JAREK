#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Jan 28 20:18:23 2019

@author: me
"""

# 求解最小三元组距离
# 思想：
#从三个数组的第一个元素开始，首先求出起始最小距离并且记录；
#接着找出三个数字中最小的数字所在的数组，向后移一个元素，
#在重新计算当前最小距离并记录，知道全部遍历结束求出最小距离
# 时间复杂度:O(i+j+k):i,j,k分别是数组a,b,c的元素个数
def mins(a,b,c):
    mins=a if a<b else b
    mins=mins if mins<c else c
    return mins

def maxs(a,b,c):
    maxs=b if a<b else a
    maxs=c if maxs<c else maxs
    return maxs

def mindis(a,b,c):
    alen=len(a)
    blen=len(b)
    clen=len(c)
    curdist=0# 记录每次循环的两点之间当前实际最小距离
    minsd=0 # 每轮计算距离过后，找出a,b,c中最小数值进行后移
    mindist=2**32 # 记录最终最小距离
    # 分别是a,b,c的下标
    i=0
    j=0
    k=0
    while 1:
        curdist=maxs(abs(a[i]-b[i]),abs(a[i]-c[k]),abs(b[j]-c[k]))
        if curdist<mindist:
            mindist=curdist
            # 找出当前遍历到三个数组的最小值
        minsd=mins(a[i],b[j],c[k])
        if minsd==a[i]:
            i+=1
            if i>=alen:
                break
        elif minsd==b[j]:
            j+=1
            if j>=blen:
                break
        else:
            k+=1
            if k>=clen:
                break
    return mindist

if __name__=='__main__':
    a=[3,4,5,7,15]
    b=[10,12,14,16,17]
    c=[20,21,23,24,37,30]
    print('最小距离是: ',mindis(a,b,c))