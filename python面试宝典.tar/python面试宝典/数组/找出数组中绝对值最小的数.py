#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Jan 28 21:14:53 2019

@author: me
"""

# 求数组中绝对值最小的数字
# 传统办法：顺序遍历->时间复杂度O(N),空间复杂度O(1)
def findmin(arr):
    if not arr or len(arr)<1:
        return -1
    mins=2**32
    for i in range(len(arr)):
        if abs(arr[i])<abs(mins):
            mins=arr[i]
    return mins

# 二分法->时间负责度O(long2N)
def findmin_bio(arr):
    if not arr or len(arr)<1:
        return -1
    lens=len(arr)
    if arr[0]>0:
        return arr[0]
    if arr[lens-1]<0:
        return arr[lens-1]
    mid=0
    begin=0
    end=lens-1
    absmin=0
    # 数组中正负数均存在
    while 1:
        mid=begin+(end-begin)//2
        if arr[mid]==0:
            return 0
        elif arr[mid]>0:
            if arr[mid-1]>0:
                end=mid-1
            elif arr[mid-1]==0:
                return 0
            # 找到了正负数的分界点
            else:
                break
        else:
            if arr[mid+1]<0:
                begin=mid+1
            elif arr[mid+1]==0:
                return 0
            else:
                break
    # 获取正负数分界点的最小绝对值数
    if (arr[mid]>0):
        if arr[mid]<abs(arr[mid-1]):
            absmin=arr[mid]
        else:
            absmin=arr[mid-1]
    else:
        if abs(arr[mid])<arr[mid+1]:
            absmin=arr[mid]
        else:
            absmin=arr[mid+1]
    return absmin

            

if __name__=='__main__':
    arr=[-10,-5,-2,7,15,50]
    print('绝对值最小值是: ',findmin(arr))
    print('绝对值最小值是: ',findmin_bio(arr))
  