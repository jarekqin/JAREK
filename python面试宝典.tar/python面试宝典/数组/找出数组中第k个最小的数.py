#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Jan 27 20:36:16 2019

@author: me
"""

# 找出数组中第K小的数字
# 方法1：快速排序->时间复杂度O(N*log2N)
def QuickSort(arr,start,end):
    # 判断low是否小于high,如果为false,直接返回
    if start < end:
        i,j = start,end
        # 设置基准数
        base = arr[i]

        while i < j:
            # 如果列表后边的数,比基准数大或相等,前移一位直到有比基准数小的数出现
            while (i < j) and (arr[j] >= base):
                j = j - 1

            # 如找到,则把第j个元素赋值给第个元素i,此时表中i,j个元素相等
            arr[i] = arr[j]

            #同样的方式比较前半区
            while (i < j) and (arr[i] <= base):
                i = i + 1
            arr[j] = arr[i]
        # 做完第一轮比较之后,列表被分成了两个半区,
        # 并且i=j,需要将这个数设置回base
        arr[i] = base

        #递归前后半区
        QuickSort(arr, start, i - 1)
        QuickSort(arr, j + 1, end)
    return arr

# 类快速排序方法->时间复杂度<O(Nlog2N),但空间复杂度O(1)
def findsmall_k(arr,low,high,k):
    i=low
    j=high
    splitelem=arr[i]
    # 把小鱼等于splitelem的数值放到其左边，大于的放到右边
    while i<j:
        while i<j and arr[j]>=splitelem:
            j-=1
        if i<j:
            arr[i]=arr[j]
            i+=1
        while i<j and arr[i]<=splitelem:
            i+=1
        if i<j:
            arr[j]=arr[i]
            j-=1
    arr[i]=splitelem
    # splitelem在子数组arr[low-high]中下标的偏移量
    subarrayindex=i-low
    # 如果splitelem在arr[low-high]所在的位置正好是k-1，那么就是答案
    if subarrayindex==k-1:
        return arr[i]
    # 如果splitelem在arr[low-high]所在的位置>是k-1
    # 需要在arr[low-i-1]中找答案
    elif subarrayindex>k-1:
        return findsmall_k(arr,low,i-1,k)
    else:
        return findsmall_k(arr,i+1,high,k-(i-low)-1)
    
    
# 延伸题目：搜寻数组中前三名
# 用求最大值的方法:当k很大时候，会很慢
def findTop3(arr):
    if not arr:
        return -1
    r1=r2=r3=-2**31
    i=0
    while i<len(arr):
        if arr[i]>r1:
            r3=r2
            r2=r1
            r1=arr[i]
        elif arr[i]>r2 and arr[i]!=r1:
            r3=r2
            r2=arr[i]
        elif arr[i]>r3 and arr[i]!=r2:
            r3=arr[i]
        i+=1
    print('前3最大的数字是: ',r1,r2,r3)
    
if __name__=="__main__":
    k=3
    arr=[4,0,1,0,2,3]
    print('第k最小数是:',findsmall_k(arr,0,len(arr)-1,k))
    # 快速排序演示
#    arr = [49,38,65,97,76,13,27,49]
#    QuickSort(arr,0,len(arr)-1)
#    print(arr)
    arr2=[4,7,1,2,3,5,3,6,3,2]
    findTop3(arr2)