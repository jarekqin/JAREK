#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Jan 28 23:20:10 2019

@author: me
"""

# 不通过排序找出中位数
#思路：通过快速排序左小右大的思路，首先进行类快速排序找出第
#i小元素，然后根据数组长度是技术还是偶数来确定分割元素下标
#根据下标大于，等于或者小于数组的中间数来计算中位数
# 时间复杂度O(n)
class FindMiddle:
    def __init__(self):
        self.pos=0
        
    # 以arr[low]为基准把数组分为两部分
    def partition(self,arr,low,high):
        key=arr[low]
        while low<high:
            while low<high and arr[high]>key:
                high-=1
            arr[low]=arr[high]
            while low<high and arr[low]<key:
                low+=1
            arr[high]=arr[low]
        arr[low]=key
        self.pos=low
        
    def getmid(self,arr):
        low=0
        n=len(arr)
        high=n-1
        mid=(low+high)//2
        while 1:
            # 再次分为两部分
            self.partition(arr,low,high)
            if self.pos==mid:
                break
            elif self.pos>mid:
                high=self.pos-1
            else:
                low=self.pos+1
        return arr[mid] if (n%2)!=0 else (arr[mid]+arr[mid+1])/2
    
if __name__=='__main__':
    arr=[7,5,3,1,11,9]
    print(FindMiddle().getmid(arr))