#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Jan 28 17:47:05 2019

@author: me
"""

# 求数组连续最大和
# 公式：all[i-1]=max(end[i-1],arr[i-1],all[i-1])
# 其中all[i-2]是第1到第n-2个最大子数列和
# end[i-1]是第1到第n-1个最大子数列和
# 时间复杂度O(N),空间复杂度O(1)
def maxsub(arr):
    if not arr:
        return -1
    nall=arr[0] # 最大子数组和
    nend=arr[0] # 包含最后一个元素的最大子数组和
    i=1
    while i<len(arr):
        nend=max(nend+arr[i],arr[i])
        nall=max(nend,nall)
        i+=1
    return nall

# 确认最大子数组的位置
#思路：当end[i-1]<0时候，end[i]=arr[i]
#其中end[i]包含arr[i]的子数组和，如果一个值迫使
#end[i-1]<0，那么就从arr[i]重新开始
class Test:
    def __init__(self):
        self.begin=0 # 最大子数组起始位置
        self.end=0   # 最大子数组结束位置
        
    def maxsub(self,arr):
        n=len(arr)
        maxsum=-2**31 # 子数组最大值
        nsum=0 # 包含子数组最后一位的最大值
        nstart=0
        i=0
        while i<n:
            if nsum<0:
                nsum=arr[i]
                nstart=i
            else:
                nsum+=arr[i]
            if nsum>maxsum:
                maxsum=nsum
                self.begin=nstart
                self.end=i
            i+=1
        return maxsum
    
    def getbegin(self):
        return self.begin
    
    def getend(self):
        return self.end
    
        
if __name__=="__main__":
    arr=[1,-2,4,8,-4,7,-1,-5]
    print('连续最大和: ',maxsub(arr))
    arr2=Test()
    print('连续最大和: ',arr2.maxsub(arr))
    print('最大和对应的数组其实和结束分别是: ',
          arr2.getbegin(),arr2.getend())