#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jan 30 16:54:09 2019

@author: me
"""

# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""


# 求解三个数组之间的公共数

# 时间复杂度=O(N+M+Z)
def findCommon(arr1,arr2,arr3):
    i=0
    j=0
    k=0
    n1=len(arr1)
    n2=len(arr2)
    n3=len(arr3)
    # 遍历三个数组
    while i<n1 and j<n2 and k<n3:
        # 找到了公共元素
        if arr1[i]==arr2[j]==arr3[k]:
            print(arr1[i])
            i+=1
            j+=1
            k+=1
        # arr1不是公共元素
        elif arr1[i]<arr2[j]:
            i+=1
        # arr2不是公共元素
        elif arr2[j]<arr3[k]:
            j+=1
        else:
            k+=1
            
if __name__=='__main__':
    arr1=[2,5,12,20,45,85]
    arr2=[16,19,20,85,200]
    arr3=[3,4,15,20,39,72,85,190]
    findCommon(arr1,arr2,arr3)
    
    