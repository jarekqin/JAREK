#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jan 30 19:17:03 2019

@author: me
"""

# 给磁盘分区->时间复杂度：O(M*N)
def is__allocable(d,p):
    index=0
    i=0
    while i<len(p):
        while index<len(d) and p[i]>d[index]:
            index+=1
        if index>=len(d):
            return False
        d[index]-=p[i]
        i+=1
    return True

if __name__=='__main__':
    d=[120,120,120]
    p=[60,60,80,20,80]
    if is__allocable(d,p):
        print('Done')
    else:
        print('Cant be done')