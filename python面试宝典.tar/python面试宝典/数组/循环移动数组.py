#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jan 29 00:23:07 2019

@author: me
"""

# 如何对数组进行循环移位
# 使用翻转法->时间复杂度：O(N)
def reverse(arr,start,end):
    if not arr:
        return -1
    while start<end:
        temp=arr[start]
        arr[start]=arr[end]
        arr[end]=temp
        start+=1
        end-=1
        
def rightShift(arr,k):
    if not arr:
        return -1
    lens=len(arr)
    k%=lens
    reverse(arr,0,lens-k-1)
    reverse(arr,lens-k,lens-1)
    reverse(arr,0,lens-1)
    
if __name__=='__main__':
    k=4
    arr=[1,2,3,4,5,6,7,8]
    rightShift(arr,k)
    i=0
    while i<len(arr):
        print(arr[i],end=' ')
        i+=1
