#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Jan 28 21:51:47 2019

@author: me
"""

# 求解数组中出现一次的数字
# 通过位的异或运算，分为两个子组
# 分别取每个子组中的某个bit进行抑或计算
# 如果最后结果不等于0，切元素位奇数就是答案
# 时间复杂度=O(N)
def isone(n,i):
    return (n&(1<<i))==1

def findsingle(arr):
    size=len(arr)
    i=0
    while i<32:
        result1=result0=count1=count0=0
        j=0
        while j<size:
            if isone(arr[j],i):
                result1^=arr[j] # i位为1的异或运算
                count1+=1
            else:
                result0^=arr[j]
                count0+=1
            j+=1
        i+=1
        '''
        bit=0|1的子数组元素个数位奇数，且出现一次的数字
        被分配到bit值位0的子数组，说明只有一个出现一次的
        数字被分到了bit是1的子数组中，异或记过就是这个出
        现一次的数字
        '''
        if count1 % 2==1 and result0!=0:
            return result1
        if count0 % 2==1 and result1!=0:
            return result0
    return -1

if __name__=='__main__':
    arr=[6,3,4,5,9,4,3]
    result=findsingle(arr)
    if result!=1:
        print(result)
    else:
        print('没找到')