#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jan 30 19:25:04 2019

@author: me
"""

# 服务器分配任务
# 使用贪心算法：时间复杂度O(MN)
def calculate_process_time(t,n):
    if not t or not n:
        return -1
    m=len(t)
    protime=[0]*m
    i=0
    while i<n:
        mintime=protime[0]+t[0]
        minindex=0
        j=1
        while j<m:
            # 分配到第j台机器上的执行时间更短
            if mintime>protime[j]+t[j]:
                mintime=protime[j]+t[j]
                minindex=j
            j+=1
        protime[minindex]+=t[minindex]
        i+=1
    return protime

if __name__=='__main__':
    t=[7,10]
    n=6
    protime=calculate_process_time(t,n)
    if not protime:
        print('分配失败')
    else:
        totaltime=protime[0]
        i=0
        while i<len(protime):
            print('NO.%d台服务器有 %d 个任务，执行时间总共是 %d'\
                  % ((i+1),protime[i]/t[i],protime[i]))
            if protime[i]>totaltime:
                totaltime=protime[i]
            i+=1
        print('所有任务执行完毕，时间是:',totaltime)