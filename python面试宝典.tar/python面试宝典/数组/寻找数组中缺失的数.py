#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Jan 27 19:53:54 2019

@author: me
"""

# 找出数组中缺失的数字
# 位异或运算->时间复杂度=O(N)
# 算法思路：设置两个异或位运算结果a,b
# a=1^...^n,b=1^...^(n-1)
def getnum(arr):
    if not arr or len(arr)<=0:
        return -1
    a=arr[0]
    b=1
    lens=len(arr)
    i=1
    while i<lens:
        a=a^arr[i]
        i+=1
    i=2
    while i<=lens+1:
        b=b^i
        i+=1
    return a^b

if __name__=="__main__":
    arr=[1,4,3,2,7,5]
    print(getnum(arr))