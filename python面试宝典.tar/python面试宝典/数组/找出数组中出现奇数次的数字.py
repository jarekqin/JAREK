#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Jan 27 20:10:58 2019

@author: me
"""

# 找出数组中出现奇数次数的数字
# 第一种字典法->时间复杂度=空间复杂度=O(N)
def getnum_dict(arr):
    if not arr or len(arr)<1:
        return -1
    dic=dict()
    i=0
    lens=len(arr)
    while i<lens:
        # 如果字典中没有此数字，对应的值是1,代表第一次出现
        if arr[i] not in dic:
            dic[arr[i]]=1
        else:
            dic[arr[i]]=0
        i+=1
    for k,v in dic.items():
        if v==1:
            print(int(k))

# 第二种是位异或运算->时间复杂度=O(1)+O(N)=O(N)
# 算法思路：任何数和其自身做异或运算均为0
# 异或运算非零结果必定是奇数次数，出现偶次数的数字会被
# 消除。但不能直接输出a^b，因为得不到十进制后的数字
# 此时，用第三个变量记住奇数次数次异或运算结果
# 只要知道C二进制8位数字中某一位数=1的位数N即可
def getnum_xor(arr):
    if not arr or len(arr)<1:
        return -1
    result=0
    position=0
    # 计算数组中所有数字的异或运算结果
    i=0
    while i<len(arr):
        result=result^arr[i]
        i+=1
    tmpresult=result
    # 找出异或运算结果中其中一个位置为1的位数
    # 例如1100，位值为1位数为2和3
    i=result
    while i & 1==0:
        position+=1
        i=i>>1
    i=1
    while i<len(arr):
        # 异或运算结果与所有第position位为1的数异或运算
        # 结果一定是出现一次的两个数中的一个
        if((arr[i]>>position)&1)==1:
            result=result^arr[i]
        i+=1
    print(result)
    
    # 得到另一个出现一次的值
    print(result^tmpresult)
    



if __name__=="__main__":
    arr=[3,5,6,6,5,7,2,2]
    getnum_dict(arr)
    getnum_xor(arr)