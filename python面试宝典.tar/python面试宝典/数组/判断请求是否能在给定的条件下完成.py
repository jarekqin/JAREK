#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jan 29 21:41:08 2019

@author: me
"""

# 判断请求是否能在给定的储存条件下完成
# 用归纳法：
#思路：首先处理i之前的要求，那么剩余的空间
#是：sum(O(0)+...+O(i-1))必须>R(i)才能处理第i个要求
#又由于O(i)<R(i),所以必定又空间处理R(i)
#另外：假设n=k时候会处理完毕，则k+1的请求必须是剩余空间
#为A=sum(O(1)+...+O(k+1))<m(是总空间)。此时将i和k+1
#位置互换。也即是第K+1请求处理完毕，接下去处理第i个时候，
#必须要又空间B=sums(O(0)+...+O(k+1)+O(i+1)...+R(i)).如果，
#B>A,按顺序处理最好；如果B<A则是乱序处理。根据：R(i)-O(i)>=
#R(k+1)-O(k+1)-->B>A。按照顺序处理最优
# O(i)是结果存储所需空间，R(i)是计算中需要的内存空间
# 时间复杂度O(N^2)
def swap(arr,i,j):
    tmp=arr[i]
    arr[i]=arr[j]
    arr[j]=tmp
    
# 按照R(i)-O(i)从大到小排列
def bubblesort(R,Q):
    lens=len(R)
    i=0
    while i<lens-1:
        j=lens-1
        while j>i:
            if R[j]-O[j]>R[j-1]-O[j-1]:
                swap(R,j,j-1)
                swap(O,j,j-1)
            j-=1
        i+=1

def schedule(R,O,M):
    bubblesort(R,O)
    lens=len(R)
    left=M
    i=0
    while i<lens:
        if left<R[i]:# 剩余空间无法处理第i任务
            return False
        else:
            left-=O[i]
        i+=1
    return True

if __name__=='__main__':
    R=[10,15,23,20,6,9,7,16]
    O=[2,7,8,4,5,8,6,8]
    N=8
    M=50
    result=schedule(R,O,M)
    if result:
        print('按照如下请求序列可完成: ')
        i=0
        while i<N:
            print(str(R[i])+':'+str(O[i]),end=' ')
            i+=1
    else:
        print('无法完成')
        