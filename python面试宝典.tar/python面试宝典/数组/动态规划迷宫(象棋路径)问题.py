#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jan 29 22:44:36 2019

@author: me
"""

# 走迷宫经典题
# n*n矩阵从左上角走到右下角
class Maze:
    def __init__(self):
        self.N=4
        
    # 打印起终点
    def printSolution(self,sol):
        i=0
        while i<self.N:
            j=0
            while j<self.N:
                print(sol[i][j],end=' ')
                j+=1
            print('\n')
            i+=1
    # 判断x,y是否一个合理的单元格
    def isSafe(self,maze,x,y):
        return x>=0 and x<self.N and y>=0 and \
            y<self.N and maze[x][y]==1
            
    # 使用回溯的方法找到一条从左上角走到右下角的路
    def getpath(self,maze,x,y,sol):
        # 到达目的地
        if x==self.N-1 and y==self.N-1:
            sol[x][y]=1
            return True
        # 判断maze[x][y]是否一个可走的单元格
        if self.isSafe(maze,x,y):
            # 标记位1]
            sol[x][y]=1
            # 向右走一步
            if self.getpath(maze,x+1,y,sol):
                return True
            # 下走一步
            if self.getpath(maze,x,y+1,sol):
                return True
            # 行不通标记0
            sol[x][y]=0
            return False
        return False

if __name__=='__main__':
    rat=Maze()
    maze=[[1,0,0,0],
          [1,1,0,1],
          [0,1,0,0],
          [1,1,1,1]]
    sol=[([0]*4) for i in range(4)]
    if not rat.getpath(maze,0,0,sol):
        print('不能达到')
    else:
        rat.printSolution(sol)