#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Jan 28 22:18:39 2019

@author: me
"""

# 将n*n数组旋转45度以后输出
# 思路：从右上角数字开始输出
def rotatearr(arr):
    if not arr:
        return -1
    lens=len(arr)
    # 打印右上角
    i=lens-1
    while i>0:
        row=0
        col=i
        while col<lens:
            print(arr[row][col],end=' ')
            row+=1
            col+=1
        print('\n')
        i-=1
        
    i=0
    while i<lens:
        row=i
        col=0
        while row<lens:
            print(arr[row][col],end=' ')
            row+=1
            col+=1
        print('\n')
        i+=1

        
        
        

if __name__=='__main__':
    arr=[[1,2,3],[4,5,6],[7,8,9]]
    rotatearr(arr)