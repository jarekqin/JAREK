#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jan 29 22:20:12 2019

@author: me
"""

# 如何获得最好的矩阵链相乘方法
# 用最少的计算次数获得N个矩阵的连乘结果
# 具体思路查看P162
# 用动态规划取代纯粹的递归方法->时间复杂度=空间复杂度：O(N^3)
def Matrix(p,n):
    cost=[([1]*n) for i in range(n)]
    i=1
    while i<n:
        cost[i][i]=0
        i+=1
    clen=2
    while clen<n:
        i=1
        while i<n-clen+1:
            j=i+clen-1
            cost[i][j]=2**31
            k=i
            while k<=j-1:
                q=cost[i][k]+cost[k+1][j]+p[i-1]*p[k]*p[j]
                if (q<cost[i][j]):
                    cost[i][j]=q
                k+=1
            i+=1
        clen+=1
    return cost[1][n-1]

if __name__=='__main__':
    arr=[1,5,2,4,6]
    n=len(arr)
    print('最少乘法次数: ',Matrix(arr,n))