#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Jan 26 21:50:29 2019

@author: me
"""

# 在数组中找出那一个唯一重复的元素
# 空间换时间方法->时间复杂和空间复杂均为O(N)
def finddup(arr):
    if not arr:
        return -1
    lens=len(arr)
    hashtable=dict()
    i=0
    while i<lens-1:
        hashtable[i]=0
        i+=1
    j=0
    while j<lens:
        if hashtable[arr[j]-1]==0:
            hashtable[arr[j]-1]=arr[j]-1
        else:
            return arr[i]
        j+=1
    return -1
# 但如果规定了不能使用额外的空间
# 可以使用累加求和法-->时间复杂O(n),空间O(1)
def finddup2(arr):
    if not arr:
        return -1
    sums=((arr[0]+arr[-1])*len(arr))//2
    sub_sums=sums-arr[-1]
    return sums-sub_sums

# 异或运算求解->时间复杂度O(N)
def finddup3(arr):
    if not arr:
        return -1
    lens=len(arr)
    result=0
    i=0
    while i<lens:
        result^=arr[i]
        i+=1
    j=1
    while j<lens:
        result^=j
        j+=1
    return result

# 数据映射法。算法查看书本P115->时间复杂度O(N)
def finddup4(arr):
    if not arr:
        return -1
    lens=len(arr)
    index=0
    i=0
    while 1:
        # 数组中的元素只能< lens
        if arr[i]>=lens:
            return -1
        if arr[index]<0:
            break
        # 访问过，通过变相反数来标记
        arr[index]*=-1
        # index后继者为arr[index]
        index=-1*arr[index]
        if index>=lens:
            print('有非法数字')
    return index

# 环形相遇->时间复杂度O(N)
# 此方法可能会越界，所以要在指针处进行分别判断
# 它们是否跨界
def finddup5(arr):
    if not arr:
        return -1
    slow=0
    fast=0
    while 1:
        fast=arr[arr[fast]] # 一次走两步
        slow=arr[slow] # 一次走一步
        if slow==fast: # 找到相遇点
            break
    fast=0
    while 1:
        fast=arr[fast]
        slow=arr[slow]
        if slow==fast: # 找到入口
            return slow
        
# 拓展问题：
# 给定一个自然数N，有一个N+M个元素的数组，其中存放了
# 小于等于N的所有自然数，求重复出现的自然数序列
# 时间复杂度->O(n)
def findNormalArr(arr,num):
    s=set()
    if not arr:
        return s
    lens=len(arr)
    index=arr[0]
    num=num-1
    while 1:
        if arr[index]<0:
            num-=1
            arr[index]=lens-num
            s.add(index)
        if num==0:
            return s
        arr[index]*=-1
        index=arr[index]*-1

if __name__=="__main__":
    arr=[1,3,4,2,5,3]
    print('方法2：',finddup2(arr))
    print('方法3：',finddup3(arr))
    print('方法4：',finddup4(arr))
    print('方法5：',finddup5(arr))
    arr2=[1,2,3,3,3,3,4,5,5,5,5,6]
    print('重复自安然数序列是：',findNormalArr(arr2,6))


        