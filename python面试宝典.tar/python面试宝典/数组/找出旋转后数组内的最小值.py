#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Jan 26 23:57:44 2019

@author: me
"""

# 找出旋转数组的最小元素
# 使用二分法->时间复杂度(O(log2N)-O(N))
def get_min(arr,low,high):
    # 如果一个都没旋转，单独处理
    if high<low:
        return arr[0]
    # 只剩下一个元素一定是最小值
    if high==low:
        return arr[low]
    mid=low+((high+low)>>1) # 防止溢出
    # 判断arr[mid]是否为最小值
    if arr[mid]<arr[mid-1]:
        return arr[mid]
    elif arr[mid+1]<arr[mid]:
        return arr[mid+1]
    # 最小值在数组左半部分
    elif arr[high]>arr[mid]:
        return get_min(arr,low,mid-1)
    # 最小值在右半部分
    elif arr[mid]>arr[low]:
        return get_min(arr,mid+1,high)
    # 在左右两边部分分别查找
    else:
        return min(get_min(arr,low,mid-1),
                   get_min(arr,mid+1,high))
        
def result(arr):
    if not arr:
        return
    else:
        return get_min(arr,0,len(arr)-1)
        
if __name__=='__main__':
    arr=[5,6,1,2,3,4]
    mins=result(arr)
    print(mins)
    arr2=[1,1,0,1]
    mins2=result(arr2)
    print(mins2)
    
    
