#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jan 29 17:56:51 2019

@author: me
"""

# 如何有规律的在二维数组中进行高效查找
# 使用二分查找：首先遍历右上角元素，如果arr[i][j]==data
# 直接返回；如果arr[i][j]>data就说明这一列的值必定大于data
# 通过j-=1排除。同理，arr[i][j]<data这一行的数值也比data小
# 通过i+=1排除此行。一次类推
# 时间复杂度=O(M+N)
def findWithBinary(arr,data):
    if not arr or not data:
        return False
    # 从右上角开始遍历
    i=0
    rows=len(arr)
    col=len(arr[1])
    j=col-1
    while i<rows and j>=0:
        if arr[i][j]==data:
            return True
        elif arr[i][j]>data:
            j-=1
        else:
            i+=1
    return False

if __name__=='__main__':
    arr=[[0,1,2,3,4],
         [10,11,12,13,14],
         [20,21,22,23,24],
         [30,31,32,33,34],
         [40,41,42,43,44]]
    print(findWithBinary(arr,17))
    print(findWithBinary(arr,14))