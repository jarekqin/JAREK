#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Jan 28 23:40:10 2019

@author: me
"""

# 求出集合的所有子集
# 方法1：使用二进制标记法，标记0不输出，1为输出
# 时间复杂度O(N*2^N),因为用了相同的辅助空间，空间复杂度位O(N)

def getAllSubArr(arr,mask,c):
    if not arr:
        return -1
    length=len(arr)
    if length==c:
        print("{",end=' ')
        i=0
        while i<length:
            if mask[i]==1:
                print(arr[i],end=' ')
            i+=1
        print('}')
    else:
        mask[c]=1
        getAllSubArr(arr,mask,c+1)
        mask[c]=0
        getAllSubArr(arr,mask,c+1)

# 迭代法->时间复杂度O(2^N)
def getAllSubSet(string):
    if not string:
        return -1
    arr=[]
    arr.append(string[0:1])
    i=1
    while i<len(string):
        lens=len(arr)
        j=0
        while j<lens:
            arr.append(arr[j]+string[i])
            j+=1
        arr.append(string[i:i+1])
        i+=1
    return arr

if __name__=='__main__':
    arr=['a','b','c']
    mask=[0,0,0]
    getAllSubArr(arr,mask,0)
    result=getAllSubSet('abc')
    i=0
    while i<len(result):
        print(result[i])
        i+=1
