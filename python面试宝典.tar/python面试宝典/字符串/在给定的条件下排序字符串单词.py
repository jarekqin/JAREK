#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Feb  1 19:19:23 2019

@author: me
"""

# 如何按照给定的字母序列对字符数组排列
# 时间复杂度:O(N³)
# 题目具体查看P209
# 思路：给数组每个字母进行下标顺序标记，组合成单词的时候
# 根据首字母大小/整个单词相加数字大小来比较
def coding(char_to_int,seq,strs):
    for i in range(len(seq)):
        char_to_int[seq[i]]=i
    for i in range(1,len(strs)+1):
        for j in range(len(strs[i-1])):
            if strs[i-1][j] not in char_to_int.keys():
                char_to_int[strs[i-1][j]]=-1
            else:
                continue

def verify(strs,char_to_int):
    if not strs:
        return -1
    for i in range(len(strs)):
        for j in range(len(strs)-1-i):
            
            
                
                   
                    
                        
        


if __name__=='__main__':
    s=['bed','dog','dear','eye']
    sequence='degcfboa'
    char_to_int={}
    coding(char_to_int,sequence,s)
    verify(s,char_to_int)
    
    