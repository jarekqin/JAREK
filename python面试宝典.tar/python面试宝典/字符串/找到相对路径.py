#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Feb  2 21:07:31 2019

@author: me
"""

# 求相对路径
# 时间复杂度=空间复杂度：O(MAX(M,N))
def getRelativePath(p1,p2):
    if not p1 or not p2:
        return
    relativepath=''
    # 用来只想两个路径不同的目录的起始路径
    diff1=0
    diff2=0
    i=0
    j=0
    len1=len(p1)
    len2=len(p2)
    while i<len1 and j<len2:
        # 如果目录相同，就往后遍历
        if p1[i]==p2[j]:
            if path1[i]=='/':
                diff1=i
                diff2=j
            i+=1
            j+=1
        else:
            # 不同目录
            # b吧p1非公共部分的目录转换为../
            diff1+=1 # 跳过目录分隔符
            while diff1<len1:
                # 碰到下一级目录
                if path1[diff1]=='/':
                    relativepath+='../'
                diff1+=1
            # 同样，处理p2的非公共路径，加入到p1后面
            diff2+=1
            relativepath+=path2[diff2]
            break
    return relativepath

if __name__=='__main__':
    path1='/qihoo/app/a/b/c/d/new.c'
    path2='/qihoo/app/1/2/test.c'
    print(getRelativePath(path1,path2))