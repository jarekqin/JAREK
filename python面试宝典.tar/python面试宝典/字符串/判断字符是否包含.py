#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jan 31 17:48:31 2019

@author: me
"""

# 检查两个字符串的包含关系
# 空间换时间法：时间复杂度=O(M+N)
# 假设长度是：s2>s1
def Modifystring(s1,s2):
    if not s1 or not s2 or len(s1)>len(s2):
        print('输入有误')
    count=0 # 用于记录较短字符总字母个数
    flags=dict()
    for i in range(len(s1)):
        if s1[i] not in flags:
            flags[s1[i]]=1
            count+=1
        else:
            flags[s1[i]]+=1
    for j in range(len(s2)):
        if s2[j] in flags:
            flags[s2[j]]-=1
            count-=1
        else:
            flags[s2[j]]=1
        
    # 判断
    if count==0:
        return True
    else:
        return False
    
if __name__=='__main__':
    s1='b'
    s2='abcdef'
    
    if Modifystring(s1,s2):
        print('长字符包含短字符组')
    else:
        print('长字符不包含短字符组')