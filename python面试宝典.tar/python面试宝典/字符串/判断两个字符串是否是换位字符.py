#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jan 31 17:35:32 2019

@author: me
"""

# 判断是否位换位字符
# 思路：采取ascii字符序列记录当前字符串字母的出现次数
# 时间复杂度=O(N)
def compare(s1,s2):
    if not s1 or not s2:
        return -1
    result=True
    bcount=[0]*256
    i=0
    while i<len(s1):
        bcount[ord(list(s1)[i])]+=1
        i+=1
    i=0
    while i<len(s2):
        bcount[ord(list(s2)[i])]-=1
        i+=1
        
    i=0
    while i<256:
        if bcount[i]!=0:
            result=False
            break
        i+=1
    return result

if __name__=='__main__':
    s1='aaaabbc'
    s2='abcbaaa'
    print(s1,'and',s2)
    if compare(s1,s2):
        print('same')
    else:
        print('not same')

        