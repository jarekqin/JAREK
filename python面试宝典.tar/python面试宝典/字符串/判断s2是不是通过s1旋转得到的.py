#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Feb  2 20:04:02 2019

@author: me
"""

# 判断s2是否是由s1旋转而得
# 通过分析可知，s2如果可以由s1旋转得到，则s2
# 必定是s1s1的子串之一。通过比价，s2和s1s1即可
# 直到答案
# 时间复杂度=空间复杂度=O(N)
def isSubstring(s1,s2):
    return s1.find(s2)!=-1
# 此函数如果是KMP算法，则时间复杂度=O(2N+N)=O(N)
# 以上函数只能调用一次
def rotateSame(s1,s2):
    if not s1 or not s2:
        return False
    len1=len(s1)
    len2=len(s2)
    # 判断两个字符串长度是否相等，如果不相等，不能通过旋转得到
    if len1!=len2:
        return False
    # 申请临时空间储存s1s1，多一个空间储存'\0'
    tmp=[0]*(2*len1+1)
    # 是tmp位s1s1
    # 以下等价于tmp=s1*2
    i=0
    while i<len1:
        tmp[i]=s1[i]
        tmp[i+len1]=s1[i]
        i+=1
    tmp[2*len1]='\0'
    # 判断s2是否位s1s1子串
    result=isSubstring(''.join(tmp),s2)
    return result

if __name__=='__main__':
    s1='waterbottle'
    s2='erbottlewat'
    result=rotateSame(s1,s2)
    if result:
        print('s2是s1通过旋转得到的')
    else:
        print('s2没办法从s1通过旋转得到')