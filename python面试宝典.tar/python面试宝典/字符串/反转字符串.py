#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jan 31 17:14:27 2019

@author: me
"""

# 对字符串进行反转
# 直接交换法->时间复杂度=O(N)
def reverseStr(string):
    if not string:
        return -1
    ch=list(string)
    i=0
    j=len(string)-1
    while i<j:
        tmp=ch[i]
        ch[i]=string[j]
        ch[j]=tmp
        j-=1
        i+=1
    return ''.join(ch)


# 引申题目：翻转单词
# 先将每一个单词的字母进行翻转
def reverseWord(ch,front,end):
    while front<end:
        ch[front]=chr(ord(ch[front])^ord(ch[end]))
        ch[end]=chr(ord(ch[front])^ord(ch[end]))
        ch[front]=chr(ord(ch[front])^ord(ch[end]))
        front+=1
        end-=1
        
# 对翻转好的字符串针对每一个单词再翻转
def swap(string):
    lens=len(string)
    ch=list(string)
    reverseWord(ch,0,lens-1)
    begin=0
    i=1
    while i<lens:
        if ch[i]=='':
            reverseWord(ch,begin,i-1)
            begin+=1
        i+=1
    reverseWord(ch,begin,lens-1)
    return ''.join(ch)
    

if __name__=='__main__':
    string='abcdefg'
    print('翻转后:')
    print(reverseStr(string))
    string2='how are you'
    print(swap(string2))
        