#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Feb  1 21:43:36 2019

@author: me
"""

# 计算重复字符长度
# 递归方法
# 时间复杂度:O(N)
def getMaxDup(s,start,curmaxlen,maxlen):
    if start==len(s)-1:
        return max(curmaxlen,maxlen)
    # 如果两个连续的字符相等，那么在递归的时候把当前最长
    # 字符串长度+1
    if s[start]==s[start+1]:
        return getMaxDup(s,start+1,curmaxlen+1,maxlen)
    # 两个连续的子串不相等，求出最长穿
    # 当前连续重复字符串长度=1
    else:
        return getMaxDup(s,start+1,1,max(curmaxlen,maxlen))
    
if __name__=='__main__':
    print('abbc最长连续重复子串长度是：',getMaxDup('abbc',0,1,1))
    print('aaabbbc最长连续重复子串长度是：',getMaxDup('aaabbbc',0,1,1))
