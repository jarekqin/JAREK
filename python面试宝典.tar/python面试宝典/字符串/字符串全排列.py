#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jan 30 20:01:10 2019

@author: me
"""

# 求一个字符串的所有排列
# 递归法->时间复杂度：O(n!×n^2)
def swap(string,a,b):
    tmp=string[a]
    string[a]=string[b]
    string[b]=tmp
    
# 对字母进行全排列
def Permutation(string,start):
    if not string:
        return -1
    # 完成全排列后输出当前排列字符串结果
    if start==len(string)-1:
        print(''.join(string))
    else:
        i=start
        while i<len(string):
            # 交换未固定的字符串
            swap(string,start,i)
            # 固定第一个字母，对剩余的全排列
            Permutation(string,start+1)
            # 还原start与i所在的字符
            swap(string,start,i)
            i+=1
            
def Permutation_transe(s):
    string=list(s)
    Permutation(string,0)
    
# 删除重复的字符串
def isdup(string,begin,end):
    i=begin
    while i<end:
        if string[i]==string[end]:
            return False
        i+=1
    return True

def Permutation_dup(string,start):
    if not string:
        return -1
    # 完成全排列后输出当前排列字符串结果
    if start==len(string)-1:
        print(''.join(string))
    else:
        i=start
        while i<len(string):
            if not isdup(string,start,i):
                continue
            # 交换未固定的字符串
            swap(string,start,i)
            # 固定第一个字母，对剩余的全排列
            Permutation_dup(string,start+1)
            # 还原start与i所在的字符
            swap(string,start,i)
            i+=1

def Permutation_transe_dup(s):
    string=list(s)
    Permutation_dup(string,0)
    
if __name__=='__main__':
    s='abc'
    Permutation_transe(s)
    print('\n')
    s2='aba'
    Permutation_transe_dup(s2)