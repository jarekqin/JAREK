#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Feb  1 21:02:02 2019

@author: me
"""

# 判断字符串是否有重复字符串
# 空间换时间:用ascii累计值表示
# 时间复杂度:O(N),空间复杂度:O(256)
def isDup(string,record_table):
    if not string:
        return -1
    count=0
    for i in string:
        if record_table[i]==0:
            record_table[i]+=1
        elif record_table[i]>=1:
            record_table[i]+=1
            count+=1
    if count>=1:
        return True
    return False
       
        
        

if __name__=='__main__':
    string='good'
    record_table={}
    for i in range(256):
        record_table[chr(i)]=0
    if isDup(string,record_table):
        print('字符串中有重复元素')
    else:
        print('字符串没有重复元素')
    
        
        