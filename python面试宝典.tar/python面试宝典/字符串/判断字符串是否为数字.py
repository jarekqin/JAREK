# -*- coding: utf-8 -*-
"""
Created on Thu Jan 31 23:37:06 2019

@author: loveb
"""

# 判断字符串是否是数字
# 要把正负数都考虑进去
# 非递归法：首先判断第一个字符值确定数字的正负性
# 然后去掉符号位，把后面的字符串当做正数来处理，
# 处理完成后根据正负性返回结果
class Number:
    def __init__(self):
        self.flag=None
    
    def getflag(self):
        return self.flag
    
    # 判断正负数
    def _isnumber(self,c):
        return c>='0' and c<='9'
    
    def atoi(self,string):
        if not string:
            self.flag=False
            print('不是数字')
        self.flag=True
        res=0
        i=0
        minus=False # 是否是负数
        if string[i]=='-':
            minus=True
            i+=1
        if string[i]=='+':
            i+=1
        while i<len(string):
            if self._isnumber(string[i]):
                res=res*10+ord(string[i])-ord('0')
            else:
                self.flag=False
                print('不是数字')
            i+=1
        return -res if minus else res
    
if __name__=='__main__':
    t=Number()
    s='-543'
    print(t.atoi(s))
    s='543'
    print(t.atoi(s))
    s='+543'
    print(t.atoi(s))
    s='++43'
    result=t.atoi(s)
    if t.getflag():
        print(result)