#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Feb  1 21:55:24 2019

@author: me
"""

# 求一个字符串中出现的第一个最长重复子串
# 后缀排序法:时间复杂度：O(N*LOG(N)*N)
# 空间复杂度：O(N)
class CommonSubString:
    # 找出最长的公共子串的长度
    def maxPrefix(self,s1,s2):
        i=0
        while i<len(s1) and i<len(s2):
            if s1[i]==s2[i]:
                i+=1
            else:
                break
            i+=1
        return i
    
    # 获取最长的公共子串
    def getMaxCommonstr(self,txt):
        n=len(txt)
        suffixes=[0]*n
        longsub=0
        longstr=None
        # 获取后缀数组
        i=0
        while i<n:
            suffixes[i]=txt[i:]
            i+=1
        # 对后缀数组排序
        suffixes.sort()
        i=1
        while i<n:
            tmp=self.maxPrefix(suffixes[i],suffixes[i-1])
            if tmp>longsub:
                longsub=tmp
                longstr=suffixes[i][0:i+1]
            i+=1
        return longstr
    
if __name__=='__main__':
    txt='banana'
    c=CommonSubString()
    print('最长的公共子串是: ',c.getMaxCommonstr(txt))