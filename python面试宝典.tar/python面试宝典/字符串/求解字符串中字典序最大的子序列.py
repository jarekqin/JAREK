#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Feb  2 19:32:34 2019

@author: me
"""

# 求解字符串中字典序最大的子序列
# 逆序求解，由题目可知，逆向遍历每一次的an-1必定在子串中
# 则从后往前遍历，如果碰到字符大于等于子串首字符，就加入子串中
# 直到找不到更大的首字符；然后将额外空间的字符转换顺序
# 时间复杂度=空间复杂度:O(N)
def getLargestStr(arr):
    if not arr:
        return None
    lens=len(arr)
    largestsub=[0]*(lens+1)
    # 最后一个字符一定在子串中
    largestsub[0]=arr[-1]
    i=lens-2
    j=0
    # 逆向遍历
    while i>0:
        if ord(arr[i])>ord(largestsub[j]):
            j+=1
            largestsub[j]=arr[i]
        i-=1
        
    largestsub=largestsub[0:j+1]
    # 对子串位置互换
    i=0
    while i<j:
        tmp=largestsub[i]
        largestsub[i]=largestsub[j]
        largestsub[j]=tmp
        i+=1
        j-=1
    return ''.join(largestsub)

if __name__=='__main__':
    s='acbdxmng'
    result=getLargestStr(s)
    if result:
        print('最大子串是: ',result)
    else:
        print('没有找到')