#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jan 31 18:18:52 2019

@author: me
"""

# 去掉字符串内的内嵌括号
# 思路：如果字符串内出现除了数字，括号和字母之外额字符，报错
# 使用额外的计数器变量记录()如果碰到(就加1，碰到)减1，如果最后
# 计数器=0，说明括号是成对出现；否则报错
# 另外要使用额外存储区把除了括号意外的字符保存到此处，还要保存
# 最外面的括号
# 时间复杂度=空间复杂度=O(N)
def removeNestedPare(string):
    if not string:
        return string
    count=0 # 记录括号出现次数
    if list(string)[0]!='(' or list(string)[-1]!=')':
        print('字符串首位非正常括号')
        return None
    sb='('
    # 字符串的收尾括号单独处理
    i=1
    while i<len(string)-1:
        ch=string[i]
        if ch=='(':
            count+=1
        elif ch==')':
            count-=1
        else:
            sb=sb+string[i]
        i+=1
    if count!=0:
        print('括号不匹配，不能继续操作')
        return None
    sb=sb+')'
    return sb

if __name__=='__main__':
    string='(1,(2,3),(4,5,6),7)'
    print(removeNestedPare(string))
        