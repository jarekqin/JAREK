#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Feb  2 01:01:44 2019

@author: me
"""

# 找到由其它单词组成的最长单词
# 贪心算法，思路具体看书p213
class LongestWord:
    def find(self,arr,strs):
        # 判断字符strs是否在arr中
        i=0
        while i<len(arr):
            if strs==arr[i]:
                return True
            i+=1
        return False
    
    # 判断字符串word是否能有数组ar中的其它单词组合
    def isContain(self,arr,word,length):
        lens=len(word)
        # 递归结束条件，当字符串长度是0
        if lens==0:
            return True
        # 循环取单词所有前缀
        i=1
        while i<=lens:
            if i==length:
                return False
            strs=word[0:i]
            if self.find(arr,strs):
                # 查找完字符串的前缀后，递归判断后面的子串是否能由其它单词组成
                if self.isContain(arr,word[i:],length):
                    return True
            i+=1
        return False
    
    # 找出能由数组中其它字符串组成额最长字符串
    def getlongest(self,arr):
        arr=sorted(arr,key=len,reverse=True)
        print(arr)
        # 贪心从最长字符串开始判断
        i=0
        while i<len(arr):
            if self.isContain(arr,arr[i],len(arr[i])):
                return arr[i]
            i+=1
        return None
    
if __name__=='__main__':
    arr=['test','tester','testertest','testing',
         'apple','seattle','banana','batting',
         'ngcat','batti','bat','testingtester','testbattingcat']
    lw=LongestWord()
    longest=lw.getlongest(arr)
    if longest!=None:
        print('最长字符串是: ',longest)
    else:
        print('没有')