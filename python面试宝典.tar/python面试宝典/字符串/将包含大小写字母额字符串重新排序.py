#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jan 31 18:08:25 2019

@author: me
"""

# 对由大小写字母的序列进行排序
# 根据ascii码排序，A-Z<a-z

def ReverseArray(ch):
    if not ch:
        return -1
    lens=len(ch)
    begin=0
    end=lens-1
    while begin<end:
        # 正向遍历搜索下一个大写字母
        while ch[begin]>='a' and ch[end]<='z' and end>begin:
            begin+=1
        while ch[end]>='A' and ch[end]<='Z' and end>begin:
            end-=1
        temp=ch[begin]
        ch[begin]=ch[end]
        ch[end]=temp
        
if __name__=='__main__':
    ch=list('AbcDef')
    ReverseArray(ch)
    for i in ch:
        print(i)