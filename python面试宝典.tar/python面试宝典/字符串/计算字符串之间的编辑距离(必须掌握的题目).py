#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Feb  2 20:16:26 2019

@author: me
"""

# 超重点：如何求解字符串的编辑距离
# 使用动态规划来解决
class EditDIstance:
    def mins(self,a,b,c):
        tmp=a if a<b else b
        return tmp if tmp<c else c
    
    def edit(self,s1,s2,replace):
        if not s1 or not s2:
            return False
        # 如果s1是空串,那么编辑距离是s2
        if not s1:
            return len(s2)
        if not s2:
            return len(s1)
        
        len1=len(s1)
        len2=len(s2)
        # 申请二维数组来储存中间的计算结果
        D=[([0]*(len2+1)) for i in range(len1+1)]
        i=0
        while i<len1+1:
            D[i][0]=i
            i+=1
            
        i=0
        while i<len2+1:
            D[0][i]=i
            i+=1
            
        i=1
        while i<len1+1:
            j=1
            while j<len2+1:
                if s1[i-1]==s2[j-1]:
                    D[i][j]=self.mins(D[i-1][j]+1,D[i][j-1]+1,
                                 D[i-1][j-1])
                else:
                    D[i][j]=min(D[i-1][j]+1,D[i][j-1]+1,
                             D[i-1][j-1]+replace)
                j+=1
            i+=1
        print('-'*30)
        i=0
        while i<len1+1:
            j=0
            while j<len2+1:
                print(D[i][j],end=' ')
                j+=1
            print('\n')
            i+=1
        print('-'*30)
        dis=D[len1][len2]
        return dis
    
if __name__=="__main__":
    s1='bciln'
    s2='fciling'
    ed=EditDIstance()
    print('第一题:')
    print('编辑距离: ',ed.edit(s1,s2,1))
    print('第二问')
    print('编辑距离: ',ed.edit(s1,s2,2))