#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Feb  2 22:11:48 2019

@author: me
"""

# 根据链式法则搜寻达到目标单词的最短距离
# 使用BFS方式从给定的字符串开始遍历所有相邻的单词
# 直到找到目标单词
# 时间复杂度:O(n²*m)，n是单词个数，m是字符串长度
from collections import deque
class QItem:
    def __init__(self,word,lens):
        self.word=word
        self.lens=lens
        
# 判断两个字符串是否只有一个字符不同
def isAdjacent(a,b):
    diff=0
    lens=len(a)
    i=0
    while i<lens:
        if a[i]!=b[i]:
            diff+=1
        if diff>1:
            return False
        i+=1
    return diff==1

# 返回从start->target的最小长度
def shortlen(start,target,D):
    Q=deque()
    item=QItem(start,1)
    Q.append(item) # 把第一个字符串添加进来
    while len(Q)>0:
        curr=Q[0]
        Q.pop()
        for it in D:
            temp=it
            # 如果这两个字符串只有一个字符不同
            if isAdjacent(curr.word,temp):
                item.word=temp
                item.lens=curr.lens+1
                Q.append(item)
                # 把这个字符从队列删除避免重复遍历
                D.remove(temp)
                # 通过转变后得到目标字符
                if temp==target:
                    return item.lens
    return 0

if __name__=='__main__':
    D=[]
    D.append('pooN')
    D.append('pbcc')
    D.append('zamc')
    D.append('poIc')
    D.append('pbca')
    D.append('pbIc')
    D.append('poIN')
    start='TooN'
    target='pbca'
    print('最短路径长度:',shortlen(start,target,D))