#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Feb  3 16:56:32 2019

@author: me
"""

# 把10进制分别让2进制和16进制形式输出
import numpy as np
def intToBin(n):
    hex_num=8*8
    bit=[]
    for i in range(hex_num):
        b=n>>i
        c,d=divmod(b,2)
        bit.append(str(d))
    return ''.join(bit[::-1])

def intToHex(s):
    hexs=''
    remainder=0
    while s!=0:
        remainder=s%16
        if remainder<10:
            hexs=str(remainder+int(0))+hexs
        else:
            hexs=str(remainder-10+ord('A'))+hexs
        s=s>>4
    return chr(int(hexs))

if __name__=='__main__':
    print('数字的二进制:',intToBin(np.long(10)))
    print('数字的16进制是:',intToHex(np.long(10)))