#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Feb  1 15:58:28 2019

@author: me
"""

# 求出字符串中最长子回文字符串
# MANACHER算法
# 时间复杂度=空间复杂度：O(N)
class String:
    def __init__(self):
        self.center=None
        self.palen=None
        
    def getcenter(self):
        return self.center
    def getlen(self):
        return self.palen
    def mins(self,a,b):
        return b if a>b else a
    
    def manacher(self,strs):
        lens=len(strs)
        newlen=2*lens+1
        s=[0]*newlen # 插入分隔符后的字符串
        p=[0]*newlen
        ids=0
        i=0
        while i<newlen:
            # 构造填充分隔符的字符串
            s[i]='*'
            i+=1
        i=0
        while i<lens:
            s[(i+1)*2]=strs
            i+=1
        self.center=-1
        self.palen=-1
        # 求解p值
        i=1
        while i<newlen:
            if ids+p[ids]>i:
                p[i]=self.mins(ids+p[ids]-i,p[2*ids-i])
            else:
                p[i]=1
        # 然后接着向左右两边扩展求最长的回文子串
            while i+p[i]<newlen and i-p[i]>0 and s[i-p[i]]==s[i+p[i]]:
                p[i]+=1
            # 当前求出的回文字符串最右端的下标更大
            if i+p[i]>ids+p[ids]:
                ids=i
            # 当求出的回文字符串更长
            if p[i]-1>self.palen:
                self.center=(i+1)/2-1
                self.palen=p[i]-1
            i+=1
            
if __name__=='__main__':
    strs='abcbax'
    t=String()
    t.manacher(strs)
    center=t.getcenter()
    palen=t.getlen()
    if center!=-1 and palen!=-1:
        print('最长回文子串是:')
        if palen % 2==1:
            i=center-palen/2
            while i<=center+palen/2:
                print(strs[int(i)])
                i+=1
        else:
            i=center-palen/2
            while i<center+palen/2:
                print(strs[int(i)])
                i+=1
    else:
        print('查找失败')