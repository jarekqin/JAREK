#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Feb  1 15:31:10 2019

@author: me
"""

# 字符串的匹配
# KMP算法：思路自己查询
# 时间复杂度:O(m+n),空间复杂度:O(n)
def getnext(p,nexts):
    i=0
    j=-1
    nexts[0]=-1
    while i<len(p):
        if j==-1 or p[i]==p[j]:
            i+=1
            j+=1
            nexts[i]=j
        else:
            j=nexts[j]
            
def match(s,p,nexts):
    if not s or not p:
        return -1
    slen=len(s)
    plen=len(p)
    # p肯定不是s的子串
    if slen<plen:
        return -1
    i=0
    j=0
    while i<slen and j<plen:
        print('i=',i,'j=',j)
        if j==-1 or s[i]==p[j]:
            # 如果相同比较后面的
            i+=1
            j+=1
        else:
            # 主串i不需要回测，从nexts数组中找出需要比较
            # 的模式串的位置j
            j=nexts[j]
    if j>=plen:
        return i-plen
    return -1

if __name__=='__main__':
    s='abababaabcbab'
    p='abaabc'
    lens=len(p)
    nexts=[0]*(lens+1)
    getnext(p,nexts)
    print('nexts数组是:',nexts[0],end=' ')
    i=1
    while i<lens-1:
        print(',',nexts[i],end=' ')
        i+=1
    print('\n')
    print('匹配结果是',match(s,p,nexts))