#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Feb  1 21:48:43 2019

@author: me
"""

# 求最长递增子序列的长度
# 动态规划：时间复杂度：O(N²),空间负责度O(N)
def getmaxlen(strs):
    lens=len(strs)
    maxlen=[0]*lens
    maxaslen=1
    i=1
    while i<lens:
        maxlen[i]=1
        j=0
        while j<i:
            if strs[j]<strs[i] and maxlen[j]>maxlen[i]-1:
                maxlen[i]=maxlen[j]+1
                maxaslen=maxlen[i]
            j+=1
        i+=1
    return maxaslen

if __name__=='__main__':
    s='xbcdza'
    print('最长递增子序列的长度是:',getmaxlen(s))