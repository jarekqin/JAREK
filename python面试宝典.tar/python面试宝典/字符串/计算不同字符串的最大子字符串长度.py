#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jan 30 20:50:43 2019

@author: me
"""

# 找出两个不同长度字符串的最大子字符串
# 采用s1不动，s2移动比较的方法
# 时间复杂度O((M+N)*N),空间复杂度O(1)
def getMaxSubStr(s1,s2):
    len1=len(s1)
    len2=len(s2)
    maxlen=0
    tmpmaxlen=0
    maxlenend1=0
    sb=''
    i=0
    while i<len1+len2:
        s1begin=s2begin=0
        tmpmaxlen=0
        if i<len1:
            s1begin=len1-i
        else:
            s2begin=i-len1
        j=0
        while(s1begin+j<len1) and (s2begin+j<len2):
            if list(s1)[s1begin+j]==list(s2)[s2begin+j]:
                tmpmaxlen+=1
            else:
                if(tmpmaxlen>maxlen):
                    maxlen=tmpmaxlen
                    maxlenend1=s1begin+j
                else:
                    tmpmaxlen=0
            j+=1
        if tmpmaxlen>maxlen:
            maxlen=tmpmaxlen
            maxlenend1=s1begin+j
        i+=1
    i=maxlenend1-maxlen
    while i<maxlenend1:
        sb=sb+list(s1)[i]
        i+=1
    return sb
    
if __name__=='__main__':
    str1='abccade'
    str2='dgcadde'
    print(getMaxSubStr(str1,str2))