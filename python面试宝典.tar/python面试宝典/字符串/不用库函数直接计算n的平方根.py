#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Feb  3 18:28:24 2019

@author: me
"""

# 不用库函数，直接计算n的平方根
# a[i+1]=(a[i]+n/a[i])/2

def squareroot(n,e):
    new_one=n
    last_one=1.0 # 第一个近似值是1
    while new_one-last_one>e:
        new_one=(new_one+last_one)/2
        last_one=n/new_one
    return new_one

if __name__=='__main__':
    n=50
    e=0.000001
    print('%d的平方根是:%0.6f'%(n,squareroot(n,e)))
    n=4
    print('%d的平方根是:%0.6f'%(n,squareroot(n,e)))