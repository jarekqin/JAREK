#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Feb  2 20:57:14 2019

@author: me
"""

# 截取字符串中的中文
# 转换成utf-8来判断
def isChinese(c):
    return True if c>=u'\u4e00'and c<=u'\u9fa5' else False

def truncateStr(strs,lens):
    if not strs or not lens:
        return ''
    chrarr=strs
    sb=''
    count=0
    for cc in chrarr:
        if (count<lens):
            if(isChinese(cc)):
            # 如果要求截取子串的长度只差1-2个字符，但是接下来的是中文
            # 那么截取结果子串中不保存这个中文字符
                if count+1<=lens and count+3>lens:
                    return sb
                count+=3
                sb+=cc
            else:
                count+=1
                sb+=cc
        else:
            break
    return sb

if __name__=='__main__':
    sb='人abc们DEF'
    print(truncateStr(sb,6))
        