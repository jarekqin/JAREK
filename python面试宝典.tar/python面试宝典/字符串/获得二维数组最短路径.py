#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Feb  2 20:45:12 2019

@author: me
"""

# 求组二维数组，从左上角到右下角的最短距离
# 每次走到arr[i][j]的最短距离公式：
# f(i,j)=min(f(i-1,j),f(i,j-1))+ar[i][j]
# 时间复杂度=空间复杂度：O(N*M)
def getPath(arr):
    if not arr:
        return 0
    row=len(arr)
    col=len(arr[1])
    # 动态规划空间
    cache=[([0]*col) for i in range(row)]
    cache[0][0]=arr[0][0]
    i=1
    while i<col:
        cache[0][i]=cache[0][i-1]+arr[0][i]
        i+=1
    j=1
    while j<row:
        cache[j][0]=cache[j-1][0]+arr[j][0]
        j+=1
    # 在遍历二维数组过程中不断的把计算结果放入辅助空间中
    print('路径')
    i=1
    while i<row:
        j=1
        while j<col:
            if cache[i-1][j]>cache[i][j-1]:
                cache[i][j]=cache[i][j-1]+arr[i][j]
                print('[',i,j-1,']',end=' ')
            # 可以确定选择的路线位arr[i-1][j]
            else:
                cache[i][j]=cache[i-1][j]+arr[i][j]
                print('[',i-1,j,']',end=' ')
            j+=1
        i+=1
        
    print('[',row-1,col-1,']')
    return '最小值是: '+str(cache[row-1][col-1])

if __name__=='__main__':
    arr=[[1,4,3],[8,7,5],[2,1,5]]        
    print(getPath(arr))