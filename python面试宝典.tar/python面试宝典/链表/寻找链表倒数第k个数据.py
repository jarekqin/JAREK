# -*- coding: utf-8 -*-
"""
Created on Mon Jan 21 18:33:21 2019

@author: loveb
"""

from LNode import LNode
# 如何确定链表的倒数第K个数字
def constructList(k):
    i=1
    head=LNode(0)
    head.next_p=None
    tmp=None
    cur=head
    while i<k:
        tmp=LNode(0)
        tmp.data=i
        tmp.next_p=None
        cur.next_p=tmp
        cur=tmp
        i+=1
    return head

# 打印原链表
def printlist(head):
    cur=head.next_p
    while cur:
        print(cur.data,end=' ')
        cur=cur.next_p
        
# 找出倒数第K个节点数据
def findlastk(head,k):
    if not head or not head.next_p:
        return head

    slow=head.next_p
    fast=head.next_p
    i=0
    # 让快指着先走k步
    while i<k and fast:
        fast=fast.next_p
        i+=1
    if i<k:
        return None
    # 快慢指针一起走7
    while fast:
        slow=slow.next_p
        fast=fast.next_p
    return slow

if __name__=='__main__':
    head=constructList(8)
    result=None
    print('原链表')
    printlist(head)
    result=findlastk(head,3)
    if result:
        print('倒数第3个节点数据是:'+str(result.data))