# -*- coding: utf-8 -*-
"""
Created on Tue Jan 22 18:24:16 2019

@author: loveb
"""

# 在只给定单链表中某个节点的指针的情况下删除该节点的值
from LNode import LNode
def PrintList(head):
    cur=head.next_p
    while cur:
        print(cur.data,end=' ')
        cur=cur.next_p

def RemoveNode(p):
    if not p or not p.next_p:
        return False
    p.data=p.next_p.data
    p.next_p=p.next_p.next_p
    return True

if __name__=='__main__':
    i=1
    head=LNode(0)
    head.next_p=None
    tmp=None
    cur=head
    p=None
    while i<8:
        tmp=LNode(0)
        tmp.data=i
        tmp.next_p=None
        cur.next_p=tmp
        cur=tmp
        if i==5:
            p=tmp
        i+=1
    print('原链表')
    PrintList(head)
    result=RemoveNode(p)
    if result:
        print('\n在删除第k个节点后的链表：')
        PrintList(head)