# -*- coding: utf-8 -*-
"""
Created on Tue Jan 22 18:06:21 2019

@author: loveb
"""

from LNode import LNode
# 合并两个链表
def constructList(start):
    i=start
    head=LNode(0)
    head.next_p=None
    tmp=None
    cur=head
    while i<7:
        tmp=LNode(0)
        tmp.data=i
        tmp.next_p=None
        cur.next_p=tmp
        cur=tmp
        i+=2
    return head

def PrintList(head):
    cur=head.next_p
    while cur:
        print(cur.data,end=' ')
        cur=cur.next_p
        
# 合并两个链表
def Merge(head1,head2):
    if not head1 or not head1.next_p:
        return head2
    if not head2 or not head2.next_p:
        return head1
    
    cur1=head1.next_p
    cur2=head2.next_p
    head=None # 合并后新链表表头
    cur=None # 合并后的链表表尾
    # 合并后的链表头结点为第一个节点元素最小值
    if cur1.data>cur2.data:
        head=head2
        cur=cur2
        cur2=cur2.next_p
        
    else:
        head=head1
        cur=cur1
        cur1=cur1.next_p
        
    # 每次找链表剩余节点的最小值对应的节点
    # 链接到合并后链表的尾部
    while cur1 and cur2:
        if cur1.data<cur2.data:
            cur.next_p=cur1
            cur=cur1
            cur1=cur1.next_p
        else:
            cur.next_p=cur2
            cur=cur2
            cur2=cur2.next_p
    # 遍历完一个链表以后，把另一个链表的剩余节点链接到
    # 合并后新链表的后面
    if cur1:
        cur.next_p=cur1
    if cur2:
        cur.next_p=cur2
    return head

if __name__=='__main__':
    head1=constructList(1)
    head2=constructList(2)
    print('head1')
    PrintList(head1)
    print('\nhead2')
    PrintList(head2)
    print('\n合并后链表')
    head=Merge(head1,head2)
    PrintList(head)