# -*- coding: utf-8 -*-
"""
Created on Tue Jan 22 22:30:22 2019

@author: loveb
"""

# 展开链接列表
# 每个节点也是一个有序列表
# 展开所有节点的数据后重新排成一个水平的列表
# 思想：使用递归+归并排序来合并操作和排序
class Node:
    def __init__(self,data):
        self.data=data
        self.right=None
        self.down=None
        
class Mergelist:
    def __init__(self):
        self.head=None
        
    # 合并两个有序列表
    def my_merge(self,a,b):
        # 如果有空链表 直接返回另一个
        if not a:
            return b
        if not b:
            return a
        
        # 把两个链表头中较小的赋值给result
        if a.data<b.data:
            result=a
            result.down=self.my_merge(a.down,b)
        else:
            result=b
            result.down=self.my_merge(a,b.down)
        return result
    
    # 把新链表扁平化
    def flattern(self,root):
        if not root or not root.right:
            return root
        # 地柜处理root.right链表
        root.right=self.flattern(root.right)
        # 把root节点对应的链表与右边的链表合并
        root=self.my_merge(root,root.right)
        return root
    
    # 把data插入链表头
    def my_insert(self,head_ref,data):
        new_node=Node(data)
        new_node.down=head_ref
        head_ref=new_node
        # 返回新链表的头结点
        return head_ref
    
    def printList(self):
        temp=self.head
        while temp:
            print(temp.data,end=' ')
            temp=temp.down
            print('\n')
            
if __name__=='__main__':
    L=Mergelist()
    L.head=L.my_insert(L.head,31)
    L.head=L.my_insert(L.head,8)
    L.head=L.my_insert(L.head,6)
    L.head=L.my_insert(L.head,3)
    L.head.right=L.my_insert(L.head.right,21)
    L.head.right=L.my_insert(L.head.right,11)
    L.head.right.righ=L.my_insert(L.head.right.right,50)
    L.head.right.righ=L.my_insert(L.head.right.right,22)
    L.head.right.righ=L.my_insert(L.head.right.right,15)
    L.head.right.righ.right=L.my_insert(L.head.right.right.right,55)
    L.head.right.righ.right=L.my_insert(L.head.right.right.right,40)
    L.head.right.righ.right=L.my_insert(L.head.right.right.right,39)
    L.head.right.righ.right=L.my_insert(L.head.right.right.right,30)
    L.head=L.flattern(L.head)
    L.printList()