# -*- coding: utf-8 -*-
"""
Created on Tue Jan 22 17:48:46 2019

@author: loveb
"""

# 链表以K个节点为一组进行反转
from LNode import LNode
# 对不带头结点的单链表反转
def Reverse(head):
    if head==None or head.next_p==None:
        return head
    pre=head
    cur=head.next_p
    next1=cur.next_p
    pre.next_p=None
    # 使当前遍历到的节点cur指向其前驱节点
    while cur!=None:
        next1=cur.next_p
        cur.next_p=pre
        pre=cur
        cur=next1
    return pre

# 对链表K反转
def ReverseK(head,k):
    if not head or not head.next_p or k<2:
        return
    i=1
    pre=head
    begin=head.next_p
    end=None
    pNext=None
    while begin!=None:
        end=begin
        # 找到begin之后k位置的节点
        while i<k:
            if end.next_p:
                end=end.next_p
            else:# 剩余节点小于k
                return
            i+=1
        pNext=end.next_p
        end.next_p=None
        pre.next_p=Reverse(begin)
        begin.next_p=pNext
        pre=begin
        begin=pNext
        i=1

if __name__=='__main__':
    i=1
    head=LNode(0)
    head.next_p=None
    tmp=None
    cur=head
    while i<8:
        tmp=LNode(0)
        tmp.data=i
        tmp.next=None
        cur.next_p=tmp
        cur=tmp
        i+=1
    print('原链表')
    cur=head.next_p
    while cur:
        print(cur.data,end=' ')
        cur=cur.next_p
    ReverseK(head,3)
    print('\n交换后')
    cur=head.next_p
    while cur:
        print(cur.data,end=' ')
        cur=cur.next_p