# -*- coding: utf-8 -*-
"""
Created on Mon Jan 21 18:20:50 2019

@author: loveb
"""

from LNode import LNode
# 如何确定链表是否有环和如何确定入口
def constructList(k):
    i=1
    head=LNode(0)
    head.next_p=None
    tmp=None
    cur=head
    while i<k:
        tmp=LNode(0)
        tmp.data=i
        tmp.next_p=None
        cur.next_p=tmp
        cur=tmp
        i+=1
    cur.next_p=head.next_p.next_p.next_p
    return head

# 判断链表是否有环
def isLoop(head):
    if not head or not head.next_p:
        return head
    
    slow=head.next_p
    fast=head.next_p
    while fast and fast.next_p:
        slow=slow.next_p
        fast=fast.next_p.next_p
        if slow==fast:
            return slow
    return None

# 找出环入口
def findloopnode(head,meetnode):
    first=head.next_p
    second=meetnode
    while first!=second:
        first=first.next_p
        second=second.next_p
    return first

if __name__=='__main__':
    head=constructList(8)
    meetnode=isLoop(head)
    loopnode=None
    if meetnode:
        print('有环')
        loopnode=findloopnode(head,meetnode)
        print('环入口是:'+str(loopnode.data))
    else:
        print('无环')
