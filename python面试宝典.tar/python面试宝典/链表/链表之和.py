# -*- coding: utf-8 -*-
"""
Created on Mon Jan 21 16:49:37 2019

@author: loveb
"""

from LNode import LNode
# 计算两个单链表所代表的数之和
# 对两个带头结点的单链表所代表的数相加
# 返回值是相加后链表的头结点

def add_chain(h1,h2):
    if not h1 or not h1.next_p:
        return h2
    if not h2 or not h2.next_p:
        return h1
    
    c=0 # 记录进位
    sums=0
    p1=h1.next_p
    p2=h2.next_p
    tmp=None # 用来指向新创建的存储相加的节点
    resultHead=LNode(0) # 相加后链表的表头
    resultHead.next_p=None
    p=resultHead # 用来指向新链表的最后一个节点
    while p1 is not None and p2 is not None:
        tmp=LNode(0)
        tmp.next_p=None
        sums=p1.data+p2.data+c
        tmp.data=sums % 10
        c=sums/10 # 进位
        p.next_p=tmp
        p=tmp
        p1=p1.next_p
        p2=p2.next_p
    if p1 is None:
        while p2 is not None:
            tmp=LNode(0)
            tmp.next_p=None
            sums=p2.data+c
            tmp.data=sums % 10
            c=sums/10
            p.next=tmp
            p=tmp
            p2=p2.next_p
    # 乳沟h1比h2长，则就考虑h1剩余节点的值
    if p2 is None:
        while p1 is not None:
            tmp=LNode(0)
            tmp.next_p=None
            sums=p1.data+c
            tmp.data=sums % 10
            c=sums/10
            p.next=tmp
            p=tmp
            p1=p1.next_p    
    # 如果计算完成还有进位，就增加新节点
    if c==1:
        tmp=LNode(0)
        tmp.next_p=None
        tmp.data=1
        p.next_p=tmp
    return resultHead

if __name__=='__main__':
    i=1
    head1=LNode(0)
    head2=LNode(0)
    head1.next_p=None
    head2.next_p=None
    tmp=None
    cur=head1
    addResult=None
    while i<7:
        tmp=LNode(0)
        tmp.data=i+2
        tmp.next_p=None
        cur.next_p=tmp
        cur=tmp
        i+=1
    cur=head2
    i=9
    while i>4:
        tmp=LNode(0)
        tmp.data=i
        tmp.next_p=None
        cur.next_p=tmp
        cur=tmp
        i-=1
    print('\nHead1:')
    cur=head1.next_p
    while cur:
        print(cur.data,end=' ')
        cur=cur.next_p
    print('\nHead2')
    cur=head2.next_p
    while cur:
        print(cur.data,end=' ')
        cur=cur.next_p
    print('\n相加以后:')
    addResult=add_chain(head1,head2)
    cur=addResult.next_p
    while cur is not None:
        print(int(cur.data),end=' ')
        cur=cur.next_p