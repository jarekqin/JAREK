# -*- coding: utf-8 -*-
"""
Created on Tue Jan 22 19:10:49 2019

@author: loveb
"""
# 判断两个链表是否有焦点
from LNode import LNode

def IsIntersect(head1,head2):
    if not head1 or not head1.next_p or \
            not head2 or not head2.next_p:
        return None
    
    temp1=head1.next_p
    temp2=head2.next_p
    n1,n2=0,0
    # 遍历Head1找到尾节点，同时记录head1长度
    while temp1.next_p:
        temp1=temp1.next_p
        n1+=1
    # 遍历head2找到尾节点，记录其长度
    while temp2.next_p:
        temp2=temp2.next_p
        n2+=1
        
    if n1>n2:
        while n1-n2>0:
            head1=head1.next_p
            n1-=1
    elif n2>n1:
        while n2-n1>0:
            head2=head2.next_p
            n2-=1
        # 连个链表同时前进
    head2=head2.next_p
    while n2!=1 or n1!=1:
        head1=head1.next_p
        head2=head2.next_p
        n2-=1
        n1-=1
    return head1

    
if __name__=='__main__':
    i=1
    head1=LNode(0)
    head1.next_p=None
    head2=LNode(0)
    head2.next_p=None
    cur=head1
    tmp=None
    p=None
    while i<8:
        tmp=LNode(0)
        tmp.data=i
        tmp.next_p=None
        cur.next_p=tmp
        cur=tmp
        if i==5:
            p=tmp
        i+=1

    cur=head2
    # 构造第二个链表
    i=1
    while i<5:
        tmp=LNode(0)
        tmp.data=i
        tmp.next_p=None
        cur.next_p=tmp
        cur=tmp
        i+=1
    cur.next=p
    interNode=IsIntersect(head1,head2)
    if not interNode:
        print('不相交')
    else:
        print('交点为:'+str(interNode.data))