# -*- coding: utf-8 -*-
"""
Created on Mon Jan 21 16:33:05 2019

@author: loveb
"""

# 从无序链表中删除重复项
# 思路：双遍历循环，外指针用于记录当前值
# 内指针循环剩余接待，如果inner.data=outter.data
# 删除，然后内指针变为inner.next_p
class LNode:
    def __init__(self,x):
        self.data=x
        self.next_p=None
        
def dup_chain(head):
    if head is None or head.next_p==None:
        return
    outter=head.next_p
    inner=None
    inner_pre=None
    while outter!=None:
        inner=outter.next_p
        inner_pre=outter
        while inner!=None:
            if outter.data==inner.data:
                inner_pre.next_p=inner.next_p
                inner=inner.next_p
            else:
                inner_pre=inner
                inner=inner.next_p
        outter=outter.next_p
        
if __name__=='__main__':
    i=1
    head=LNode(1)
    head.next_p=None
    tmp=None
    cur=head
    while i<7:
        tmp=LNode(0)
        if i % 2==0:
            tmp.data=i+1
        elif i % 3==0:
            tmp.data=i-2
        else:
            tmp.data=i
        tmp.next=None
        cur.next_p=tmp
        cur=tmp
        i+=1
    print('删除重复值之前')
    cur=head.next_p
    while cur:
        print(cur.data)
        cur=cur.next_p
    dup_chain(head)
    print('删除后')
    cur=head.next_p
    while cur:
        print(cur.data)
        cur=cur.next_p