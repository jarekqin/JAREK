# -*- coding: utf-8 -*-
"""
Created on Mon Jan 21 17:19:22 2019

@author: loveb
"""

# 对链表进行重新排序
# 思路：对链表进行折半，后半部分进行逆序，然后合并
from LNode import *
# 用双指针寻找链表的中点
def findmiddle(head):
    if not head or not head.next_p:
        return head
    fast=head # 遍历链表时候每次走两步
    slow=head # 遍历链表事后每次走一步
    slowpre=head
    while fast is not None and fast.next_p is not None:
        slowpre=slow
        slow=slow.next_p
        fast=fast.next_p.next_p
    # 吧链子形成两段
    slowpre.next_p=None
    return slow

# 对不带头结点的链表翻转
def Reverse(head):
    if not head or not head.next_p:
        return head
    pre=head
    cur=head.next_p
    pre.next_p=None
    next1=None
    while cur:
        next1=cur.next_p
        cur.next_p=pre
        pre=cur
        cur=next1
    return pre
    
        

# 对链表进行排序
def order_chain(head):
    if head ==None or head.next_p==None:
        return
    # 前半部分第一个节点
    cur1=head.next_p
    mid=findmiddle(head.next_p)
    # 后半部分第一个节点
    cur2=Reverse(mid)
#    while cur2:
#        print(cur2.data,end=' ')
#        cur2=cur2.next_p
    tmp=None
    # 合并
    while cur1.next_p:
        tmp=cur1.next_p
        cur1.net_p=cur2
        cur1=tmp
        tmp=cur2.next_p
        cur2.next_p=cur1
        cur2=tmp
    cur1.next_p=cur2

    while cur1:
        print(cur1.data,end=' ')
        cur1=cur1.next_p
    
    
if __name__=='__main__':
    i=1
    head=LNode(0)
    head.next_p=None
    tmp=None
    cur=head
    while i<8:
        tmp=LNode(0)
        tmp.data=i
        tmp.next_p=None
        cur.next_p=tmp
        cur=tmp
        i+=1
        
    print('排序前')
    cur=head.next_p
    while cur:
        print(cur.data,end=' ')
        cur=cur.next_p
    order_chain(head)
    print('\n排序后')
    cur=head.next_p
    while cur:
        print(cur.data,end=' ')
        cur=cur.next_p
