# -*- coding: utf-8 -*-
"""
Created on Tue Jan 22 17:29:43 2019

@author: loveb
"""
# 链表相邻数据对换位置
from LNode import LNode
def neighbour_reverse(head):
    if not head or not head.next_p:
        return head
    cur=head.next_p
    pre=head
    next1=None
    while cur and cur.next_p:
        next1=cur.next_p.next_p
        pre.next_p=cur.next_p
        cur.next_p.next_p=cur
        cur.next_p=next1
        pre=cur
        cur=next1
        
if __name__=='__main__':
    i=1
    head=LNode(0)
    head.next_p=None
    tmp=None
    cur=head
    while i<8:
        tmp=LNode(0)
        tmp.data=i
        tmp.next=None
        cur.next_p=tmp
        cur=tmp
        i+=1
    print('原链表')
    cur=head.next_p
    while cur:
        print(cur.data,end=' ')
        cur=cur.next_p
    neighbour_reverse(head)
    print('\n交换后')
    cur=head.next_p
    while cur:
        print(cur.data,end=' ')
        cur=cur.next_p

        
