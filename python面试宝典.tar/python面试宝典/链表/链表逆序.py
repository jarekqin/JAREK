# -*- coding: utf-8 -*-
"""
Created on Mon Jan 21 15:40:51 2019

@author: loveb
"""

# python面试宝典-链表题
# 链表的逆序
class LNode:
    def __init__(self,x=None):
        self.data=x
        self.next_p=None

# 插入法：每次把便利到的节点插入到头结点之后        
def Reverse(head):
    if head is None or head.next_p is None:
        return
    cur=None
    next1=None
    cur=head.next_p.next_p
    head.next_p.next_p=None
    while cur is not None:
        next1=cur.next_p
        cur.next_p=head.next_p
        head.next_p=cur
        cur=next1

def ReversePrint(firstNode):
    if firstNode is None:
        return
    ReversePrint(firstNode.next_p)
    print(firstNode.data)
    

if __name__=='__main__':
    i=1
    # 链表头结点
    head=LNode()
    head.next_p=None
    tmp=None
    cur=head
    # 构造单链表
    while i<8:
        tmp=LNode(i)
        tmp.next_p=None
        cur.next_p=tmp
        cur=tmp
        i+=1
        
    print('逆序前:')
    cur=head.next_p
    while cur!=None:
        print(cur.data)
        cur=cur.next_p
        
    print('\n逆序后')
    Reverse(head)
    cur=head.next_p
    while cur!=None:
        print(cur.data)
        cur=cur.next_p