# -*- coding: utf-8 -*-
"""
Created on Wed Jan 23 22:44:02 2019

@author: loveb
"""

# 设计一个排序系统
from collections import deque
class User:
    def __init__(self,ids,name):
        self.ids=ids
        self.name=name
        self.seq=0
        
    def getName(self):
        return self.name
    
    def setName(self,name):
        self.name=name
    
    def setSeq(self,seq):
        self.seq=seq
        
    def getID(self,ID):
       return self.ids
        
    def equals(self,arg0):
        o=arg0
        return self.ids==o.getID()
    
    def toString(self):
        return 'id:'+str(self.ids)+'  name:'+ \
                self.name+'  seq:'+str(self.seq)
class MyQueue:
    def __init__(self):
        self.q=deque()
        
    def add_end(self,u):
        u.setSeq(len(self.q)+1)
        self.q.append(u)
        
    # 对头出列
    def del_head(self):
        self.q.popleft()
        self.updateSeq()
        
    # 队列中随机有人离开
    def del_random(self,u):
        self.q.remove(u)
        self.updateSeq()
        
    # 有人出列后更新现在的队列
    def updateSeq(self):
        i=1
        for u in self.q:
            u.setSeq(i)
            i+=1
    
    def printlist(self):
        for u in self.q:
            print(u.toString())
            
if __name__=='__main__':
    u1=User(1,'user1')
    u2=User(2,'user2')
    u3=User(3,'user3')
    u4=User(4,'user4')
    queue=MyQueue()
    queue.add_end(u1)
    queue.add_end(u2)
    queue.add_end(u3)
    queue.add_end(u4)
    queue.del_head()
    queue.del_random(u3)
    queue.printlist()