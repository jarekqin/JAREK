# -*- coding: utf-8 -*-
"""
Created on Wed Jan 23 20:49:45 2019

@author: loveb
"""

# 用哈希算法求出某个车票的起点和中点
# 构建一个字典，然后从整个旅程中找到下一站
def printresult(inputs):
    # 用来存储input的键和值调换后的信息
    reverseinput=dict()
    for k,v in inputs.items():
        reverseinput[v]=k
    start=None
    # 找到起点
    for k,v in inputs.items():
        if k not in reverseinput:
            start=k
            break
    if not start:
        print('输入不合理')
        return
    # 从起点遍历
    to=inputs[start]
    print(start+'->'+to)
    start=to
    to=inputs[to]
    try:
        while to:
            print(start+'->'+to)
            start=to
            to=inputs[to]
    except KeyError:
        return
    
if __name__=='__main__':
    inputs=dict()
    inputs['西安']='成都'
    inputs['北京']='上海'
    inputs['大连']='西安'
    inputs['上海']='大连'
    printresult(inputs)