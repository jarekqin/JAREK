# -*- coding: utf-8 -*-
"""
Created on Wed Jan 23 19:12:54 2019

@author: loveb
"""

# 链表形式生成队列
from LNode import *
class MyQueue:
    def __init__(self):
        self.phead=None
        self.pend=None
        
    def empty1(self):
        if self.phead==self.pend:
            return 1
        else:
            return 0
        
    def size1(self):
        size=0
        p=self.phead
        while p:
            p=p.next_p
            size+=1
        return size

    def add1(self,e):
        p=LNode(0)
        p.data=e
        p.next_p=None
        if not self.phead:
            self.phead=self.pend=p
        else:
            self.pend.next_p=p
            self.pend=p
     
    # 出队列，删除队列头元素
    def delete1(self):
        if not self.phead:
            print('空列表,删除失败')
        self.phead=self.phead.next_p
        if not self.phead:
            self.pend=None
            
    # 取得队列首元素
    def getFront(self):
        if not self.phead:
            return None
        return self.phead.data
    
    # 取得队列尾元素
    def getBack(self):
        if not self.pend:
            return None
        return self.pend.data    
    
if __name__=='__main__':
        queue=MyQueue()
        queue.add1(1)
        queue.add1(2)
        print('队列头数据是: ',queue.getFront())
        print('队列尾数据是: ',queue.getBack())
        print('队列大小是:',queue.size1())