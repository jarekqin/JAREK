# -*- coding: utf-8 -*-
"""
Created on Wed Jan 23 19:02:07 2019

@author: loveb
"""

# 列表实现（数组方式）
class MyQueue:
    def __init__(self):
        self.arr=[]
        self.front=0
        self.rear=0
        
    def isEmpty(self):
        return self.front==self.rear
    
    def isSize(self):
        return self.rear-self.front
    
    def getFront(self):
        if self.isEmpty():
            return None
        return self.arr[self.front]
    
    def getBack(self):
        if self.isEmpty():
            return None
        return self.arr[self.rear-1]
    
    def deQueue(self):
        if self.read>self.front:
            self.front+=1
        else:
            print('队列已空')
            
    def addQueue(self,item):
        self.arr.append(item)
        self.rear+=1
        
if __name__=='__main__':
    queue=MyQueue()
    queue.addQueue(1)
    queue.addQueue(2)
    print('队列头数据是: ',queue.getFront())
    print('队列尾数据是: ',queue.getBack())
    print('队列大小是:',queue.isSize())