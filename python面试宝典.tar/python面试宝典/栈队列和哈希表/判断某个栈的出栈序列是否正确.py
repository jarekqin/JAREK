# -*- coding: utf-8 -*-
"""
Created on Wed Jan 23 19:57:59 2019

@author: loveb
"""

# 判断可能的出栈序列
from 数组实现栈 import *
def isPopSerial(push,pop):
    if not pop or not push:
        return False
    pushLen=len(push)
    popLen=len(pop)
    if pushLen!=popLen:
        return False
    pushindex=0
    popindex=0
    stack=MyStack()
    while pushindex<pushLen:
        # 把push的序列依次入栈，知道栈顶元素等于pop序列第一个元素
        stack.push(push[pushindex])
        pushindex+=1
        # 栈顶元素出栈，pop序列移动到下一个元素
        while (not stack.isEmpty()) and stack.top_1()==pop[popindex]:
            stack.pop_1()
            popindex+=1
    # 栈为空，且pop序列中的元素都被遍历
    return stack.isEmpty() and popindex==popLen

if __name__=='__main__':
    push='12345'
    pop='32541'
    if isPopSerial(push,pop):
        print(pop+'是'+push+'的一个pop序列')
    else:
        print(pop+'不是'+push+'的一个pop序列')
        