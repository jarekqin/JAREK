# -*- coding: utf-8 -*-
"""
Created on Tue Jan 22 20:24:43 2019

@author: loveb
"""

# 如何实现栈
# 用数组实现
class MyStack:
    def __init__(self):
        self.items=[]
        
    def isEmpty(self):
        return len(self.items)==0
    
    def size_1(self):
        return len(self.items)
    
    def top_1(self):
        if not self.isEmpty():
            return self.items[len(self.items)-1]
        else:
            return None
    
    def pop_1(self):
        if len(self.items)>0:
            return self.items.pop()
        else:
            print('栈已空')
            return None
        
    def push(self,item):
        self.items.append(item)
        
if __name__=='__main__':
    s=MyStack()
    s.push(4)
    print('栈顶元素是:',s.top_1())
    print('栈有:',s.size_1(),'个元素')
    s.pop_1()
    print('栈为空:%s' % s.isEmpty())
    