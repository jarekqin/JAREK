# -*- coding: utf-8 -*-
"""
Created on Tue Jan 22 20:31:42 2019

@author: loveb
"""
# 链表实现栈
from LNode import LNode
class Stack_2:
    def __init__(self):
        self.data=None
        self.next_p=None
        
    def is_empty(self):
        return self.next_p==None
    
    def is_size(self):
        size=0
        p=self.next_p
        while p:
            p=p.next_p
            size+=1
        return size
    
    def is_push(self,e):
        p=LNode(e)
        p.next_p=self.next_p
        self.next_p=p
        
    def is_pop(self):
        tmp=self.next_p
        if tmp:
            self.next_p=tmp.next_p
            return tmp.data
        print('栈已空')
        return None
    
    def is_top(self):
        if self.next_p:
            return self.next_p.data
        print('栈已空')
        return None
    
if __name__=='__main__':
    stack=Stack_2()
    stack.is_push(1)
    print('栈顶元素是:',stack.is_top())
    print('栈大小为: ',stack.is_size())
    stack.is_pop()
    print('弹出成功')
    