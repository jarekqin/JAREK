# -*- coding: utf-8 -*-
"""
Created on Wed Jan 23 20:29:17 2019

@author: loveb
"""

# 两个栈模拟队列操作
from 数组实现栈 import *
class Stack_list:
    def __init__(self):
        self.A=MyStack()
        self.B=MyStack()
        
    def push_list(self,data):
        self.A.push(data)
        
    def pop_list(self):
        if self.B.isEmpty():
            while not self.A.isEmpty():
                self.B.push(self.A.top_1())
                self.A.pop_1()
        first=self.B.top_1()
        self.B.pop_1()
        return first
    
if __name__=='__main__':
    stack=Stack_list()
    stack.push_list(1)
    stack.push_list(2)
    print('队列首元素是: ',stack.pop_list())
    print('队列首元素是: ',stack.pop_list())
