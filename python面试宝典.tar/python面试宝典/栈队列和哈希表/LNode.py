# -*- coding: utf-8 -*-
"""
Created on Mon Jan 21 16:49:16 2019

@author: loveb
"""

class LNode:
    def __init__(self,x):
        self.data=x
        self.next_p=None