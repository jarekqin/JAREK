# -*- coding: utf-8 -*-
"""
Created on Wed Jan 23 21:01:30 2019

@author: loveb
"""

# 如何从数组中找出a+b=d+c的数对
class pair:
    def __init__(self,f,s):
        self.f=f
        self.s=s
        
def findpair(arr):
    # key为数对的和，值为数对数组
    sumpair=dict()
    n=len(arr)
    # 遍历所有可能数对
    i=0
    while i<n:
        j=i+1 # 内循环是把每个当前值和后面的值逐个相加
        while j<n:
            # 如果这个数对的和在map中没有，则放入map
            sums=arr[i]+arr[j]
            if sums not in sumpair:
                sumpair[sums]=pair(i,j)
            # 存在则找出和打印结果
            else:
                p=sumpair[sums]
                print(str(arr[p.f]),'+',str(arr[p.s]),'=',
                      str(arr[i]),'+',str(arr[j]))
            j+=1
        i+=1
    return False

if __name__=='__main__':
    arr=[3,4,7,10,20,9,8]
    findpair(arr)