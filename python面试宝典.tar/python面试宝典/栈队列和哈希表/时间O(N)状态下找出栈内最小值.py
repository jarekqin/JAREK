# -*- coding: utf-8 -*-
"""
Created on Wed Jan 23 20:12:06 2019

@author: loveb
"""
# 使用o(n)的时间复杂度来找出栈中最小元素
# 使用额外的辅助空间来换取时间复杂度提升
from 数组实现栈 import *
class Stack:
    def __init__(self):
        self.elementStack=MyStack()
        self.minStack=MyStack()
    
    def push(self,data):
        self.elementStack.push(data)
        # 更新保存最小值
        if self.minStack.isEmpty():
            self.minStack.push(data)
        else:
            if data<self.minStack.top_1():
                self.minStack.push(data)
    def pop(self):
        topdata=self.elementStack.top_1()
        self.elementStack.pop_1()
        if topdata==self.mins():
            self.minStack.pop_1()
        return topdata
    
    def mins(self):
        if self.minStack.isEmpty():
            return 2**32
        else:
            return self.minStack.top_1()
        
if __name__=='__main__':
    stack=Stack()
    stack.push(5)
    print('栈中最小值为: '+str(stack.mins()))
    stack.push(6)
    print('栈中最小值为: '+str(stack.mins()))
    stack.push(2)
    print('栈中最小值为: '+str(stack.mins()))
    stack.pop()
    print('栈中最小值为: '+str(stack.mins()))
    