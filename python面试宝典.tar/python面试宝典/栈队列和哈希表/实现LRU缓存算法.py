# -*- coding: utf-8 -*-
"""
Created on Wed Jan 23 20:44:19 2019

@author: loveb
"""

# 实现LRU缓存方案
from collections import deque
class LRU:
    def __init__(self,cachesize):
        self.cachesize=cachesize
        self.queue=deque()
        self.hashSet=set()
        
    def isfull(self):
        return len(self.queue)==self.cachesize
    
    # 把页号为page的页面缓存到队列中，同时也添加到hash表
    def addqueue(self,page):
        if self.isfull():
            self.hashSet.remove(self.queue[-1])
            self.queue.pop()
        self.queue.appendleft(page)
        self.hashSet.add(page)
        
    # 访问某个page的时候会调用一下函数，有两种情况
    # 在缓存队伍中，直接把这个节点移动到队首
    # 不在缓存中，把这个Page缓存到队首
    def accesspage(self,page):
        if page not in self.hashSet:
            self.addqueue(page)
        elif page!=self.queue[0]:
            self.queue.remove(page)
            self.queue.appendleft(page)
    
    def printqueue(self):
        while len(self.queue)>0:
            print(self.queue.popleft())
            
if __name__=='__main__':
    lru=LRU(3)
    lru.accesspage(1)
    lru.accesspage(2)
    lru.accesspage(5)
    lru.accesspage(1)
    lru.accesspage(6)
    lru.accesspage(7)
    lru.printqueue()