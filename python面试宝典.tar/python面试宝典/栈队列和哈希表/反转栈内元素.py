# -*- coding: utf-8 -*-
"""
Created on Wed Jan 23 19:28:10 2019

@author: loveb
"""

# 将栈元素反转
from 数组实现栈 import *
def moveBottomToTop(s):
    if s.isEmpty(): 
        return
    top1=s.top_1()
    s.pop_1()
    if not s.isEmpty():
        # 递归处理不包含栈顶元素的子栈
        moveBottomToTop(s)
        top2=s.top_1()
        s.pop_1()
        # 交换栈顶和栈底元素
        s.push(top1)
        s.push(top2)
    else:
        s.push(top1)
# 反转栈
def reverse_stack(s):
    if s.isEmpty():
        return
    # 把栈底元素移动到栈顶
    moveBottomToTop(s)
    top=s.top_1()
    s.pop_1()
    # 递归处理子栈
    reverse_stack(s)
    s.push(top)

# 引申出来的栈排序算法
def movebuttomtotop(s):
    if s.isEmpty(): 
        return
    top1=s.top_1()
    s.pop_1()
    if not s.isEmpty():
        # 递归处理不包含栈顶元素的子栈
        movebuttomtotop(s)
        top2=s.top_1()
        if top1>top2:
            s.pop_1()
            # 交换栈顶和栈底元素
            s.push(top1)
            s.push(top2)
            return
    s.push(top1)    

def sortStack(s):
    if s.isEmpty():
        return
    # 把栈底元素移动到栈顶
    movebuttomtotop(s)
    top=s.top_1()
    s.pop_1()
    # 递归处理子栈
    sortStack(s)
    s.push(top)    
  
if __name__=='__main__':
    s=MyStack()
    s.push(5)
    s.push(4)
    s.push(3)
    s.push(2)
    s.push(1)
    reverse_stack(s)
    print('反转后的栈为:')
    while not s.isEmpty():
        print(s.top_1())
        s.pop_1()
    # 栈排序案例
    print('分割线'+'-'*15)
    s2=MyStack()
    s2.push(5)
    s2.push(3)
    s2.push(1)
    s2.push(2)
    s2.push(4)
    sortStack(s2)
    print('排序后的栈')
    while not s2.isEmpty():
        print(s2.top_1())
        s2.pop_1()
    