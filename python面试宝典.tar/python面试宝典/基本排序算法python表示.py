#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Jan 27 21:25:15 2019

@author: me
"""

# 各类python排序算法，从左往右比较，内圈从左往右递增
# 选择排序是从未排序的序列中选取最大或者最小值放在起始位置
# 再从未排序的数字中逐个对比相邻之间的数据大小进行排序
# 选择排序是一个不稳定的排序算法
# 虽然选择排序和冒泡排序的时间复杂度一样，但实际上，
# 选择排序进行的交换操作很少，最多会发生 N - 1次交换。
# 而冒泡排序最坏的情况下要发生N^2 /2交换操作。
# 从这个意义上讲，交换排序的性能略优于冒泡排序
# 时间复杂度:O(N²)
def choice_order(arr):
    if not arr:
        return -1
    for i in range(len(arr)):
        for j in range(i+1,len(arr)):
            if arr[i]>arr[j]:
                tmp=arr[j]
                arr[j]=arr[i]
                arr[i]=tmp
    return arr

# 时间复杂度=O(NLOG2N),最差情况下O(N²)
def QuickSort(arr,start,end):
    if not arr:
        return -1
    # 判断low是否小于high,如果为false,直接返回
    if start < end:
        i,j = start,end
        # 设置基准数
        base = arr[i]

        while i < j:
            # 如果列表后边的数,比基准数大或相等,前移一位直到有比基准数小的数出现
            while (i < j) and (arr[j] >= base):
                j = j - 1

            # 如找到,则把第j个元素赋值给第个元素i,此时表中i,j个元素相等
            arr[i] = arr[j]

            #同样的方式比较前半区
            while (i < j) and (arr[i] <= base):
                i = i + 1
            arr[j] = arr[i]
        # 做完第一轮比较之后,列表被分成了两个半区,
        # 并且i=j,需要将这个数设置回base
        arr[i] = base

        #递归前后半区
        QuickSort(arr, start, i - 1)
        QuickSort(arr, j + 1, end)
    return arr

# 根据c语言改编
def quick_sort_c_version(arr,left,right):
    if not arr:
        return -1
    ltemp=left
    rtemp=right
    f=arr[(left+right)//2]
    while(ltemp<rtemp):
        while(arr[ltemp]<f):
            ltemp+=1
        while(arr[rtemp]>f):
            rtemp-=1
        if(ltemp<=rtemp):
            t=arr[ltemp]
            arr[ltemp]=arr[rtemp]
            arr[rtemp]=t;
            rtemp-=1
            ltemp+=1
    if(ltemp==rtemp):
        ltemp+=1
    if(left<rtemp):
        quick_sort_c_version(arr,left,ltemp-1)
    if(ltemp<right):
        quick_sort_c_version(arr,rtemp+1,right)
    return arr

# 从右往左依次比较相邻两个元素，内圈从右往左递减
# 时间复杂度=O(N²)最差，最好O(N)
def bubble_order(arr):
    if not arr:
        return -1
    for i in range(len(arr)):
        for j in range(len(arr)-i-1):
            if arr[j]>arr[j+1]:
                tmp=arr[j]
                arr[j]=arr[j+1]
                arr[j+1]=tmp
    return arr

# 插入排序，首先从左往右对未排序的数据和已排序序列进行对比
# 找到未排序数字在已排序序列中的正确位置后，插入已排序序列中
# 直道全部排序结束
#1 时间复杂度：
#（1）顺序排列时，只需比较(n-1)次，插入排序时间复杂度为O(n)；
#（2）逆序排序时，需比较n(n-1)/2次，插入排序时间复杂度为O(n^2)；
#（3）当原始序列杂乱无序时，平均时间复杂度为O(n^2)
#2 空间复杂度：
#插入排序过程中，需要一个临时变量temp存储待排序元素，因此空间复杂度为O(1)。
#3 算法稳定性：
#插入排序是一种稳定的排序算法。
def insert_order(arr):
    if not arr:
        return -1
    for i in range(1,len(arr)):
        for j in range(i-1,-1,-1):
            if arr[j]>arr[j+1]:
                tmp=arr[j]
                arr[j]=arr[j+1]
                arr[j+1]=tmp
    return arr
    

# 希尔排序
# 不稳定排序，时间复杂度平均:O(nLOGn)
# 最差:O(N^S)(1<S<2),空间复杂度O(1)
def shell_sort(arr):
    count=len(arr)
    step=2
    group=count//step
    while group>0:
        for i in range(int(group)):
            j=i+group
            while j<count:
                k=j-group
                key=arr[int(j)]
                while k>=0:
                    if arr[int(k)]>key:
                        arr[int(k+group)]=arr[int(k)]
                        arr[int(k)]=key
                    k-=group
                j+=group
        group/=step
    return arr
    
# 堆排序（极其重要）
# 根据一颗完整二叉树来排序
# 不稳定排序，时间复杂度平均:O(NLOGN)
def adjust_heap(arr,i,size):
    left=2*i+1
    right=2*i+2
    maxs=i
    if i<size//2:
        if left<size and arr[left]>arr[maxs]:
            maxs=left
        if right<size and arr[right]>arr[maxs]:
            maxs=right
        if maxs!=i:
            arr[maxs],arr[i]=arr[i],arr[maxs]
            adjust_heap(arr,maxs,size)
            
def build_heap(arr,size):
    for i in range(0,(size//2))[::-1]:
        adjust_heap(arr,i,size)

def heap_sort(arr):
    size=len(arr)
    build_heap(arr,size)
    for i in range(size)[::-1]:
        arr[0],arr[i]=arr[i],arr[0]
        adjust_heap(arr,0,i)
    return arr


# 基数排序
import math
def radix_sort(arr,radix=10):
    k=int(math.ceil(math.log(max(arr),radix)))
    bucket=[[] for i in range(radix)]
    for i in range(1,k+1):
        for j in arr:
            bucket[j/(radix**int(i-1))%(radix**i)].append(j)
        del arr[:]
        for z in bucket:
            arr+=z
            del z[:]
    return arr

if __name__=="__main__":
    arr1=[50,20,70,10,30,110,80,60]
    print('选择排序:',choice_order(arr1))
    arr2=[50,20,70,10,30,110,80,60]
    print('快速排序python版本:',
          QuickSort(arr2,0,len(arr2)-1))
    arr3=[50,20,70,10,30,110,80,60]
    print('冒泡排序:',bubble_order(arr3))
    arr4=[50,20,70,10,30,110,80,60]
    print('插入排序:',insert_order(arr4))
    arr5=[50,20,70,10,30,110,80,60]
    print('快速排序(C语言改造版本):',
          quick_sort_c_version(arr5,0,len(arr5)-1))
    arr6=[50,20,70,10,30,110,80,60]    
    print('希尔排序:',shell_sort(arr6))
    arr7=[50,20,70,10,30,110,80,60]
    print('堆排序:',heap_sort(arr7))
    arr8=[3,4,2,8,9,5,1]
    print('基数排序:',radix_sort(arr8))