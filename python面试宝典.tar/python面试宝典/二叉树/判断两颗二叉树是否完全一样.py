# -*- coding: utf-8 -*-
"""
Created on Thu Jan 24 18:10:37 2019

@author: loveb
"""

# 判断两颗二叉树是否相等
from NODE import *
# 重构二叉树
def constructtree():
    root=BioNode()
    node1=BioNode()
    node2=BioNode()
    node3=BioNode()
    node4=BioNode()    
    root.data=6
    node1.data=3
    node2.data=-7
    node3.data=-1
    node4.data=9
    root.left=node1
    root.right=node2
    node1.left=node3
    node1.right=node4
    node2.left=node2.right=node3.left=node3.right=\
    node4.left=node4.right=None
    return root

def isequal(root1,root2):
    if not root1 and root2:
        return True
    if not root1 and root2:
        return False
    if root1 and not root2:
        return False
    try:
        if root1.data==root2.data:
            return isequal(root1.left,root2.left) and \
                    isequal(root1.right,root2.right)
        else:
            return False
    except AttributeError:
        return True

if __name__=='__main__':
    root1=constructtree()
    root2=constructtree()
    if isequal(root1,root2):
        print('两棵树一致')
    else:
        print('两棵树不一致')