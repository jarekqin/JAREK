# -*- coding: utf-8 -*-
"""
Created on Thu Jan 24 19:24:10 2019

@author: loveb
"""

# 把二叉树变为双向链表
# 中序遍历算法改变
from NODE import *

class Test:
    def __init__(self):
        self.phead=None
        self.pend=None
        
    # 把有序数组转换为二叉树
    def arraytolist(self,arr,start,end):
        root=None
        if end>=start:
            root=BioNode()
            mid=(start+end+1)//2
            root.data=arr[mid]
            root.left=self.arraytolist(arr,start,mid-1)
            root.right=self.arraytolist(arr,mid+1,end)
        else:
            root=None
        return root
    # 把二叉树变为双向链表
    def inorderbstree(self,root):
        if not root:
            return
        # 转换左子树
        self.inorderbstree(root.left)
        root.left=self.pend # 是当前节点的左子树指向双向链表最后一个节点
        if not self.pend: # 双向链表为空，当前遍历的节点为链表表头
            self.phead=root
        else:   # 让链表中最后你一个节点的右子树指向当前节点
            self.pend.right=root
        self.pend=root # 将当前节点设置链表的最后一个节点
        # 转换右子树
        self.inorderbstree(root.right)
        
if __name__=='__main__':
    arr=[1,2,3,4,5,6,7]
    test=Test()
    root=test.arraytolist(arr,0,len(arr)-1)
    test.inorderbstree(root)
    print('转换后正向遍历')
    cur=test.phead
    while cur:
        print(cur.data,end=' ')
        cur=cur.right
    print('-'*50)
    print('转换后反向遍历')
    cur=test.pend
    while cur:
        print(cur.data,end=' ')
        cur=cur.left
    