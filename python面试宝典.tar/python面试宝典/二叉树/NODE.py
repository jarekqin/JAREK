# -*- coding: utf-8 -*-
"""
Created on Thu Jan 24 16:40:46 2019

@author: loveb
"""

# 二叉树基本定义类
class BioNode:
    def __init__(self):
        self.data=None
        self.right=None
        self.left=None
        
def arraytolist(arr,start,end):
        root=None
        if end>=start:
            root=BioNode()
            mid=(start+end+1)//2
            root.data=arr[mid]
            root.left=arraytolist(arr,start,mid-1)
            root.right=arraytolist(arr,mid+1,end)
        else:
            root=None
        return root
    
def constructtree():
    root=BioNode()
    node1=BioNode()
    node2=BioNode()
    node3=BioNode()
    node4=BioNode()    
    root.data=6
    node1.data=3
    node2.data=-7
    node3.data=-1
    node4.data=9
    root.left=node1
    root.right=node2
    node1.left=node3
    node1.right=node4
    node2.left=node2.right=node3.left=node3.right=\
    node4.left=node4.right=None
    return root