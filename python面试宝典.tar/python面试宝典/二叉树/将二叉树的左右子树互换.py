#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jan 25 23:28:11 2019

@author: me
"""

# 将二叉树的左右子树互换
from NODE import *
from 逐层打印二叉树 import *
# 镜像翻转
def reverseTree(root):
    if not root:
        return
    reverseTree(root.left)
    reverseTree(root.right)
    tmp=root.left
    root.left=root.right
    root.right=tmp

if __name__=='__main__':
    arr=[1,2,3,4,5,6,7]
    root=arraytotree(arr,0,len(arr)-1)
    print('二叉树分层遍历结果: ')
    printtreelayer(root)
    print('\n')
    reverseTree(root)
    print('反转后结果是: ')
    printtreelayer(root)
 