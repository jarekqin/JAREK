# -*- coding: utf-8 -*-
"""
Created on Thu Jan 24 19:49:14 2019

@author: loveb
"""

# 判断一个数组是否是某个正态二叉树的后序遍历结果
def isafterorder(arr,start,end):
    if not arr:
        return False
    # 数组的最后一个节点必须是根节点
    root=arr[end]
    # 找到数组中大于root的最小数
    i=start
    # 此数值之前的数值必定在左子树，而后面的数值必定在右子树
    while i<end:
        if(arr[i]>root):
            break
        i+=1
    j=i
    # 如果是后续遍历的序列，则从i开始所有的值大于根节点的值
    while j<end:
        if arr[j]<root:
            return False
        j+=1
    left_isaferorder=True
    right_isafterorder=True
    # 判断小于root的值是否是二元查找树的后续遍历
    if i>start:
        left_isaferorder=isafterorder(arr,start,i-1)
    # 同样判断大于root的值
    if j<end:
        right_isafterorder=isafterorder(arr,i,end)
    return left_isaferorder and right_isafterorder


if __name__=='__main__':
    arr=[1,3,2,5,7,6,4]
    result=isafterorder(arr,0,len(arr)-1)
    i=0
    while i<len(arr):
        print(arr[i],end=' ')
        i+=1
    if result:
        print('是二叉树的后序遍历序列')
    else:
        print('不是二叉树的后序遍历序列')