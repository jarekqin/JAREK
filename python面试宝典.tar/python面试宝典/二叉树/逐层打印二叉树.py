# -*- coding: utf-8 -*-
"""
Created on Thu Jan 24 17:40:30 2019

@author: loveb
"""
# 按层打印二叉树
from NODE import *
import numpy as np
from collections import deque
# 将有序数组转换成二叉树
def arraytotree(arr,start,end):
    root=None
    if end>=start:
        root=BioNode()
        mid=(start+end+1)//2
        # 数的根节点为数组的中间元素
        root.data=arr[mid]
        # 递归左右子树
        root.left=arraytotree(arr,start,mid-1)
        root.right=arraytotree(arr,mid+1,end)
    else:
        root=None
    return root

# 按层次打印二叉树
def printtreelayer(root):
    if not root:
        return
    queue=deque()
    # 根节点进入队列
    queue.append(root)
    while len(queue)>0:
        p=queue.popleft()
        # 访问当前节点
        print(p.data,end=' ')
        # 如果这个节点的做孩子不为空就入列
        if p.left:
            queue.append(p.left)
        if p.right:
            queue.append(p.right)

def printatlevel(root,level):
    if not root or not level:
        return 0
    elif level==0:
        print(root.data,end=' ')
        return 1
    else:
        # 把打印根节点的level层的节点转换为求解根节点的孩子节点
        # 的level-1层的节点
        return printatlevel(root.left,
        level-1)+printatlevel(root.right+1)
    
            
if __name__=='__main__':
    arr=[1,2,3,4,5,6,7,8,9,10]
    root=arraytotree(arr,0,len(arr)-1)
    print('结果是:')
    printtreelayer(root)
