# -*- coding: utf-8 -*-
"""
Created on Thu Jan 24 17:55:51 2019

@author: loveb
"""

# 求一棵二叉树的最大子树和
from NODE import *
class Test:
    def __init__(self):
        self.maxsum=-2**31
        
    def findmaxsubtree(self,root,maxroot):
        if not root:
            return 0
        # 求root左子树所有节点的和
        leftmax=self.findmaxsubtree(root.left,maxroot)
        rightmax=self.findmaxsubtree(root.right,maxroot)
        sums=leftmax+rightmax+root.data
        # 以root为跟的子树的和大于子树的所有节点的和
        if sums>self.maxsum:
            self.maxsum=sums
            maxroot.data=root.data
        return sums
    # 重构二叉树
    def constructtree(self):
        root=BioNode()
        node1=BioNode()
        node2=BioNode()
        node3=BioNode()
        node4=BioNode()
        root.data=6
        node1.data=3
        node2.data=-7
        node3.data=-1
        node4.data=9
        root.left=node1
        root.right=node2
        node1.left=node3
        node1.right=node4
        node2.left=node2.right=node3.left=node3.right=\
        node4.left=node4.right=None
        return root
    
if __name__=='__main__':
    test=Test()
    root=test.constructtree()
    maxroot=BioNode() # 最大子树的根节点
    test.findmaxsubtree(root,maxroot)
    print('最大子树和为: ',test.maxsum)
    print('最大子树根节点是: ',maxroot.data)