#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Jan 26 00:32:44 2019

@author: me
"""

# 找出二叉树中路径最大的值
class BioNode:
    def __init__(self,data):
        self.data=data
        self.right=None
        self.left=None

class IntRef:
    def __int__(self):
        self.data=None

def Max(a,b,c):
    maxs=a if a>b else b
    maxs=maxs if maxs>c else c
    return maxs

# 寻找最长路径
def FindMaxPath(root,maxs):
    if not root:
        return 0
    else:
        # 求左子树最大值路径
        sumleft=FindMaxPath(root.left,maxs)
        # 右子树
        sumright=FindMaxPath(root.right,maxs)
        # 求叶子节点为结束节点的最大路径和
        allmax=root.data+sumleft+sumright
        leftmax=root.data+sumleft
        rightmax=root.data+sumright
        tmpmax=Max(allmax,leftmax,rightmax)
        if tmpmax>maxs.data:
            maxs.data=tmpmax
        submax=sumleft if sumleft>sumright else sumright
        return root.data+submax
    
def finMax(root):
    maxs=IntRef()
    maxs.data=-2**31
    FindMaxPath(root,maxs)
    return maxs.data

if __name__=='__main__':
    root=BioNode(2)
    left=BioNode(3)
    right=BioNode(5)
    root.left=left
    root.right=right
    print(finMax(root))
        