# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

# 复制二叉树
from NODE import *
def createDupTRee(root):
    if not root:
        return NOne
    # root of bio tree
    dupTree=BioNode()
    dupTree.data=root.data
    # copy left
    dupTree.left=createDupTRee(root.left)
    # copy right
    dupTree.right=createDupTRee(root.right)
    return dupTree

def printTreeMideOrder(root):
    # print bio tree with middle circle
    if not root:
        return
    # for left
    if root.left:
        printTreeMideOrder(root.left)
    # for root
    print(root.data,end=' ')
    # for right
    if root.right:
        printTreeMideOrder(root.right)
        
if __name__=='__main__':
    root1=constructtree()
    root2=constructtree()
    print('original bio tree: ')
    printTreeMideOrder(root1)
    print('\n')
    print('new bio tree: ')
    printTreeMideOrder(root2)