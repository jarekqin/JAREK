# -*- coding: utf-8 -*-
"""
Created on Thu Jan 24 20:09:11 2019

@author: loveb
"""
# 求两颗排序二叉树共同的父节点
import math
from NODE import *
class IntRef:
    def __init__(self):
        self.num=None
        
# 找出节点在二叉树中的编号
def getNo(root,node,number):
    if not root:
        return False
    if root==node:
        return True
    tmp=number.num
    number.num=2*tmp
    # node 节点在root的左子树中，左子树编号为当前节点编号的2倍
    if getNo(root.left,node,number):
        return True
    # node 节点在root的左子树中，左子树编号为当前节点编号的2倍+1
    else:
        number.num=2*tmp+1
        return getNo(root.right,node,number)
        
        
def getNodeFromNum(root,number):
    if not root or number<0:
        return None
    if number==1:
        return root
    # 节点编号对应二进制的位数(最高位一定为1)
    lens=int((math.log(number)/math.log(2)))
    # 去掉根节点表示的1
    number-=1<<lens # 位移有问题
    while lens>0:
        # 如果这一位二进制的值=1
        # 那么编号为number的节点必定在当前节点右子树上
        if(1<<(lens-1)) & number==1:
            root=root.right
        else:
            root=root.left
        lens-=1
    return root

# 找两棵树的共同父节点
def findparent(root,node1,node2):
    ref1=IntRef()
    ref1.num=1
    ref2=IntRef()
    ref2.num=1
    getNo(root,node1,ref1)
    getNo(root,node2,ref2)
    num1=ref1.num
    num2=ref2.num
    # 找出编号为Num1 num2共同的父节点
    while num1!=num2:
        if num1>num2:
            num1/=2
        else:
            num2/=2
    # Num就是他们最近的公共父节点编号
    return getNodeFromNum(root,num1)

if __name__=='__main__':
    arr=[1,2,3,4,5,6,7,8,9,10]
    root=arraytolist(arr,0,len(arr)-1)
    node1=root.left.left.left
    node2=root.left.right
    res=None
    res=findparent(root,node1,node2)
    if res:
        print(node1.data,'和',node2.data,'的共同父节点为: ',res.data)
    else:
        print('没有公共父节点')