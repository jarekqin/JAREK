#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jan 25 22:40:45 2019

@author: me
"""

# 在二叉树中找出一个条路径，
# 使得路径上的所有节点和等于给某个定整形数
from NODE import *
def FindRoad(root,num,sums,v):
    # recording present root node
    sums+=root.data
    v.append(root.data)
    # 当前节点是叶子节点，且遍历的路径上所有
    # 节点的和等于num
    if not root.left and not root.right and sums==num:
        i=0
        while i<len(v):
            print(v[i],end='->')
            i+=1
        print('\n')
    # for left
    if root.left:
        FindRoad(root.left,num,sums,v)
    # for right
    if root.right:
        FindRoad(root.right,num,sums,v)
    # clear circled paths
    sums-=v[-1]
    v.remove(v[-1])
        
if __name__=='__main__':
    root=constructtree()
    v=[]
    print('path that all nodes sum=8 as below:')
    FindRoad(root,8,0,v)