# -*- coding: utf-8 -*-
"""
Created on Thu Jan 24 17:25:33 2019

@author: loveb
"""

from NODE import *
# 将一个有序序列整数数组放入二叉树

# 将有序数组转换成二叉树
def arraytotree(arr,start,end):
    root=None
    if end>=start:
        root=BioNode()
        mid=(start+end)//2
        # 数的根节点为数组的中间元素
        root.data=arr[mid]
        # 递归左右子树
        root.left=arraytotree(arr,start,mid-1)
        root.right=arraytotree(arr,mid+1,end)
    else:
        root=None
    return root

# 中序遍历打印二叉树
def printTreeMid(root):
    if not root:
        return
    # 遍历节点
    if root.left:
        printTreeMid(root.left)
    print(root.data,end=' ')
    if root.right:
        printTreeMid(root.right)
        
if __name__=='__main__':
    arr=[1,2,3,4,5,6,7,8,9,10]
    print('数组: ')
    i=0
    while i<len(arr):
        print(arr[i],end=' ')
        i+=1
    print('\n')
    root=arraytotree(arr,0,len(arr)-1)
    print('转换后的中旬遍历: ')
    printTreeMid(root)
    print('\n')