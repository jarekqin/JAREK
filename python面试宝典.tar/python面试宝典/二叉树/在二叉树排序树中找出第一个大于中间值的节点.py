#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jan 25 23:54:13 2019

@author: me
"""

# 在二叉树中找出第一个大于中间值的节点
from NODE import *
# 二叉树最小值必定在最左下角
def getMinNode(root):
    if not root:
        return root
    while root.left:
        root=root.left
    return root

def getMaxNode(root):
    if not root:
        return root
    while root.right:
        root=root.right
    return root

def getNode(root):
    maxnode=getMaxNode(root)
    minnode=getMinNode(root)
    mid=(maxnode.data+minnode.data)/2
    result=None
    # 如果当前节点的值不大于f,则在右子树找
    while root:
        if root.data<=mid:
            root=root.right
        else:
            result=root
            root=root.left
    return result

if __name__=='__main__':
    arr=[1,2,3,4,5,6,7]
    root=arraytotree(arr,0,len(arr)-1)
    print(getNode(root).data)
