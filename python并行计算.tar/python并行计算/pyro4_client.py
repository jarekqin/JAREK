#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Feb 20 19:23:42 2019

@author: me
"""

# pyro4 client

import Pyro4

uri=input('What is the pyro uri of the greeting object?').strip()
name=input('what is your name').strip()
server=Pyro4.Proxy('PYRONAME:server')
print(server.welcomeMessage(name))

