#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Feb 12 14:40:28 2019

@author: me
"""

# python线程编程
# 基本框架
from threading import Thread,Condition
from time import sleep
import time
import threading
import random
from multiprocessing import Value

class CookBook(Thread):
    def __init__(self):
        Thread.__init__(self)
        self.message='Hello parallel python\n'
        
    def print_message(self):
        print(self.message)
        
    def run(self):
        print('Thread Start')
        x=0
        while x<10:
            self.print_message()
            sleep(1)
            x+=1
        print('Thread ending')
        
#if __name__=='__main__':
#    hello_python=CookBook()
#    hello_python.start()
#    
    
    
# 最简单的线程案例
def function(i):
    print('function called by thread %d' % i)
    return

threads=[] # 手动生成线程池，可以增速且分割大型数据执行一样的函数
for i in range(5):
    t=Thread(target=function,args=(i,))
    threads.append(t)
    t.start()
    t.join()

# 如何确定当前线程
def func1():
    print(threading.currentThread().getName()+str('is starting'))
    sleep(2)
    print(threading.currentThread().getName()+str('is ending'))
    return

def func2():
    print(threading.currentThread().getName()+str('is starting'))
    sleep(2)
    print(threading.currentThread().getName()+str('is ending'))
    return

def func3():
    print(threading.currentThread().getName()+str('is starting'))
    sleep(2)
    print(threading.currentThread().getName()+str('is ending'))
    return

t1=Thread(name='first thread',target=func1)
t2=Thread(name='second thread',target=func2)
t3=Thread(name='third thread',target=func3)
t1.start()
t2.start()
t3.start()
t1.join()
t2.join()
t3.join()


# 子类中使用线程
exitflag=0
class MyThread(Thread):
    def __init__(self,threadID,name,counter):
        Thread.__init__(self)
        self.threadID=threadID
        self.name=name
        self.counter=counter
        
    def run(self):
        print('Starting '+self.name)
        self.print_time(self.name,self.counter,5)
        print('Exiting '+self.name)
    
    def print_time(self,threadName,delay,c):
        while c:
            if exitflag:
                threading.exit()
            time.sleep(delay)
            print('%s:%s'% \
                  (threadName,time.ctime(time.time())))
            c-=1

t1=MyThread(1,'Thread-1',1)
t2=MyThread(2,'Thread-2',2)
t1.start()
t2.start()

# 线程的锁同步
shared_resource_with_lock=0
COUNT=100000
lock=threading.Lock()
def increase():
    global shared_resource_with_lock
    for i in range(COUNT):
        lock.acquire()
        shared_resource_with_lock+=1
        lock.release()
        
def decrease():
    global shared_resource_with_lock
    for i in range(COUNT):
        lock.acquire()
        shared_resource_with_lock-=1
        lock.release()

t1=Thread(target=increase)
t2=Thread(target=decrease)
t1.start()
t2.start()
t1.join()
t2.join()
print('the value of shared variable with lock management is %s'\
      % shared_resource_with_lock)

# 信号量实现线程同步
from multiprocessing import Value
sem=threading.Semaphore()
item=Value('i',0)
def consumer():
    print('consumer is waiting')
    sem.acquire()
    item.value-=1
    print('Consumer notify: consumed item number %s' % item.value)
    sem.release()
    
def producer():
    print('producer is working')
    sem.acquire()
    item.value+=1
    sem.release() # sem不为0之后才释放信号告诉另一个线程
    print('Producer notify: producing item number %s' % item.value)
    sleep(2)

for i in range(5):
    t1=Thread(target=producer)
    t2=Thread(target=consumer)
    t1.start()
    t2.start()
    t1.join()
    t2.join()

# 使用条件变量进行线程同步
item=Value('i',0) # VALUE主要初始化一个值的共享内存
# 进程间尽量少用共享内存，线程因为共享进程资源，所以推荐共享内存
condition=Condition()

class consumer(Thread):
    def __init__(self):
        super().__init__()
        
    def consume(self):
        condition.acquire()
        if item.value==0:
            condition.wait()
            print('no source now')
        item.value-=1
        print('consumer used 1 item')
        print('item has',item.value)
        condition.notify()
        condition.release()
    
    def run(self):
        for i in range(20):
            time.sleep(2)
            self.consume()
            
class producer(Thread):
    def __init__(self):
        super().__init__()
        
    def produce(self):
        condition.acquire()
        if item.value==10:
            condition.wait()
            print('source is full now')
        item.value+=1
        print('producer put 1 item')
        print('item has',item.value)
        condition.notify()
        condition.release()
    
    def run(self):
        for i in range(20):
            time.sleep(2)
            self.produce()
            
producer=producer()
consumer=consumer()
producer.start()
consumer.start()
producer.join()
consumer.join()

# 使用事件实现线程同步
# 可以用set()设为true,clear()设为false,wait()会一直阻塞
items=[]
from threading import Event
event=Event()

class consumer(Thread):
    def __init__(self,items,event):
        super().__init__()
        self.items=items
        self.event=event
        
    def run(self):
        while self.items:
            time.sleep(2)
            self.event.wait()
            item=self.items.pop()
            print('Consumer notify: %d popped from list by %s' % \
                  (item,self.name))
            
class producer(Thread):
    def __init__(self,items,event):
        super().__init__()
        self.items=items
        self.event=event
        
    def run(self):
        global items
        for i in range(10):
            time.sleep(2)
            item=random.randint(0,256)
            self.items.append(item)
            print('Producer notify: item No %d appended by %s'% \
                  (item,self.name))
            print('Event set by %s' % self.name)
            self.event.set()
            print('event cleared by %s \n' % self.name)
            self.event.clear()
            
t1=producer(items,event)
t2=consumer(items,event)
t1.start()
t2.start()
t1.join()
t2.join()


# 队列实现线程通信，适用于多数据源内存
from threading import Thread,Event
from queue import Queue
import time
import random

class producer(Thread):
    def __init__(self,queue):
        super().__init__()
        self.queue=queue
        
    def run(self):
        for i in range(10):
            item=random.randint(0,256)
            self.queue.put(item)
            print('Producting %d putting into queue by %s \n' % \
                  (item,self.name))
            time.sleep(1)
            
class consumer(Thread):
    def __init__(self,queue):
        super().__init__()
        self.queue=queue
        
    def run(self):
        while 1:
            item=self.queue.get()# 得到队列表头元素并弹出
            print('Consuming %d by %s' % (item,self.name))
            self.queue.task_done()

            
queue=Queue()
t1=producer(queue)
t2=consumer(queue)
t3=consumer(queue)
t4=consumer(queue)
t1.start()
t2.start()
t3.start()
t4.start()
t1.join()
t2.join()
t3.join()
t4.join()


# python多线程可以用于I/O和爬虫（仅局限于urllib模块））
def function_to_run():
    import urllib.request
    for i in range(10):
        with urllib.request.urlopen('http://www.packtpub.com') as f:
            f.read(1024)
    