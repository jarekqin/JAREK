#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Feb 16 19:45:55 2019

@author: me
"""

# python多进程（python中推荐用多进程解决并发运行）
# 最简单的进程程序和手动生成进程池
from multiprocessing import Process
import time
import multiprocessing
def foo(i):
    print('called function with process %d'% i)
    return

Process_pool=[]
for i in range(10):
    p=Process(target=foo,args=(i,))
    Process_pool.append(p)
    p.start()
for p in Process_pool:
    p.join()
    
    
# 对进程命名
def foo():
    name=multiprocessing.current_process().name
    print('Starting %s \n' % name)
    time.sleep(1)
    print('Exiting %s \n' % name)
    
process_with_name=Process(name='foo_process',target=foo)
process_with_name.daemon=True # 守护进程
process_with_default_name=Process(target=foo)
process_with_name.start()
process_with_default_name.start()


# 杀死进程
def foo():
    print('starting')
    time.sleep(1)
    print('ending')
    
p=Process(target=foo)
print('Process before execution:',p,p.is_alive())
p.start()
print('process running:',p,p.is_alive())
p.terminate()
print('process terminated:',p,p.is_alive())
p.join()
print('process joined:',p,p.is_alive())
print('process exit code:',p.exitcode)

# 子类中使用进程
class Myprocess(Process):
    def __init__(self):
        super().__init__()
        
    def run(self):
        print('called run method in process %s' % self.name)
        return
    
jobs=[]
for i in range(5):
    p=Myprocess()
    jobs.append(p)
    p.start()
    p.join()
    
    
# 集中点：进程间通信
# 队列通信
import random
class producer(Process):
    def __init__(self,queue):
        super().__init__()
        self.queue=queue
        
    def run(self):
        for i in range(10):
            item=random.randint(0,100)
            self.queue.put(item)
            print('Process producer putting %d into queue by %s' %\
                  (item,self.name))
            time.sleep(1)
            print('queue has %s numbers' % self.queue.qsize())

class consumer(Process):
    def __init__(self,queue):
        super().__init__()
        self.queue=queue
        
    def run(self):
        while 1:
            if (self.queue.empty()):
                print('queue is empty')
                break
            time.sleep(2)
            item=self.queue.get()
            print('Process consumer get %d poped from by %s' % \
                  (item,self.name))
            time.sleep(1)
            
queue=multiprocessing.Queue()
process_producer=producer(queue)
process_consumer=consumer(queue)
process_producer.start()
process_consumer.start()
process_producer.join()
process_consumer.join()


# 管道进程通信
from multiprocessing import Pipe
def create_item(pipe):
    write_pipe,read_pipe=pipe
    read_pipe.close()
    for item in range(10):
        write_pipe.send(item)
    write_pipe.close()
    
def read_item(pipe):
    write_pipe,read_pipe=pipe
    write_pipe.close()
    try:
        while 1:
            item=read_pipe.recv()
            print('Received %d' % item)
    except EOFError:
        read_pipe.close()
        
pipe=Pipe()
write=Process(target=create_item,args=(pipe,))
write.start()
read=Process(target=read_item,args=(pipe,))
read.start()
# 强行杀死进程
write.join()
read.join()

# 进程池+消息队列综合案例
# Manger的消息队列,以这个为主
from multiprocessing import Manager,Pool
def write():
    while 1:
        data=int(input('Type integer number: '))
        if data==0:
            print('Exit writing process')
            break
        q.put(data)

def read():
    while 1:
        try:
            print('We get %d:' % \
            q.get(block=True,timeout=1.5))
            # print(q.get(block=False))
        except:
            break

q=Manager().Queue()
pool=Pool()
for func in [write(),read()]:
    pool.apply_async(func)
pool.close()
pool.join()

# 进程池另一个案例
def func(data):
    result=data**2
    return result

inputs=list(range(100))
pool=Pool(processes=4)
# 等同于内置的map函数，不过此处是并行版本，会阻塞
# map_async()是异步版本
pool_outputs=pool.map(func,inputs)
pool.close()
pool.join()
print('Pool: ',pool_outputs)