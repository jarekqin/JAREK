#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Feb 20 17:13:14 2019

@author: me
"""

# 使用rpyc
import rpyc
import sys
c=rpyc.classic.connect('0.0.0.0')
c.execute('print ("hi python cookbook")')
c.modules.sys.stdout=sys.stdout
c.execute('print("hi here")')