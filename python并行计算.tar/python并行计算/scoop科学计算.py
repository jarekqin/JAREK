#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Feb 20 15:38:53 2019

@author: me
"""

# scoop的映射函数串行实现
import operator
import time
from scoop import futures

def simulateWorkload(inputdata):
    time.sleep(0.01)
    return sum(inputdata)


def CompareMapReduce():
    mapScoopTime=time.time()
    res=futures.mapReduce(
            simulateWorkload,
            operator.add,
            list([a] *a for a in range(1000)),
            )
    mapScooptime=time.time()-mapScoopTime
    print('futures.map in Scoop executed in %0.3f with \
          result %0.3f' % (mapScooptime,res))
    
    mapPythonTime=time.time()
    res1=sum(
            map(
                simulateWorkload,
                list([a] * a for a in range(1000))
                )
            )
    mapPythonTime=time.time()-mapPythonTime
    print('futures.map in Scoop executed in %0.3f with \
          result %0.3f' % (mapPythonTime,res1))
    
if __name__=='__main__':
    CompareMapReduce()