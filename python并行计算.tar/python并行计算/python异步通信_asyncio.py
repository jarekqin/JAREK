#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Feb 17 16:55:43 2019

@author: me
"""

# Asyncio模块的异步处理
# 最简单的asyncio异步案例
import asyncio
import datetime
import time

#def func1(end_time,loop):
#    print('func1 called')
#    if (loop.time()+1.0)<end_time:
#        loop.call_later(1,func2,end_time,loop)
#    else:
#        loop.stop()
#        
#def func2(end_time,loop):
#    print('func2 called')
#    if (loop.time()+1.0)<end_time:
#        loop.call_later(1,func3,end_time,loop)
#    else:
#        loop.stop()    
#        
#def func3(end_time,loop):
#    print('func3 called')
#    if (loop.time()+1.0)<end_time:
#        loop.call_later(1,func1,end_time,loop)
#    else:
#        loop.stop()    
#        
#def func4(end_time,loop):
#    print('func4 called')
#    if (loop.time()+1.0)<end_time:
#        loop.call_later(1,func4,end_time,loop)
#    else:
#        loop.stop()
#        
#loop=asyncio.get_event_loop()
#end_loop=loop.time()+9.0
#loop.call_soon(func1,end_loop,loop)
#loop.run_forever()
#loop.close()


# asyncio处理协程
# 有限自动机案例
from random import randint

@asyncio.coroutine
def startstate():
    print('Start state called\n')
    input_value=randint(0,5)
    time.sleep(1)
    if input_value==0:
        result=yield from state2(input_value)
    else:
        result=yield from state1(input_value)
    print('resume of the transition: \nstart state calling',result)
    
@asyncio.coroutine
def state1(transition):
    outputvalue=str(('State 1 with transition value=%s\n' % transition))
    input_value=randint(0,5)
    time.sleep(1)
    print('...Evaluating...')
    if(input_value==0):
        result=yield from state3(input_value)
    else:
        result=yield from state2(input_value)
    result='State 1 calling'+result
    return outputvalue+str(result)

@asyncio.coroutine
def state2(transition):
    outputvalue=str(('State 2 with transition value=%s\n' % transition))
    input_value=randint(0,5)
    time.sleep(1)
    print('...Evaluating...')
    if(input_value==0):
        result=yield from state1(input_value)
    else:
        result=yield from state3(input_value)
    result='State 2 calling'+result
    return outputvalue+str(result)

@asyncio.coroutine
def state3(transition):
    outputvalue=str(('State 3 with transition value=%s\n' % transition))
    input_value=randint(0,5)
    time.sleep(1)
    print('...Evaluating...')
    if(input_value==0):
        result=yield from state1(input_value)
    else:
        result=yield from endstate(input_value)
    result='State 3 calling'+result
    return outputvalue+str(result)

@asyncio.coroutine
def endstate(transition):
    outputvalue=str(('end state with transition value=%s\n' % transition))
    print('...Stop Computation...')
    return outputvalue

print('Finite state machine simulation with asyncio coroutine')
loop=asyncio.get_event_loop()
loop.run_until_complete(startstate())


# 管理任务案例
# 一个时间循环一次只执行一个任务，如果其他时间循环通过不同线程
# 则可以并行执行。

@asyncio.coroutine
def factorial(number):
    f=1
    for i in range(2,number+1):
        print('Asyncio.Task: computer factorial(%d)' % i)
        yield from asyncio.sleep(1)
        f*=i
    print('Asyncio.Task-factorial(%d)=%d' % (number,f))
    
@asyncio.coroutine
def fibonacci(number):
    a,b=0,1
    for i in range(number):
        print('Asyncio.Task: computer fibonacci(%d)' % i)
        yield from asyncio.sleep(1)
        a,b=b,a+b
    print('Asyncio.Task-fibonacci(%d)=%d' % (number,a))

@asyncio.coroutine
def binomialCoeff(n,k):
    result=1
    for i in range(1,k+1):
        result=result*(n-i+1)/i
        print('Asyncio.Task: computer binomialCoeff(%d)' % i)
        yield from asyncio.sleep(1)
    print('Asyncio.Task-binomialCoeff(%d,%d)=%d' % (n,k,result))
# 将所有任务放入一个任务表  
tasks=[asyncio.Task(factorial(10)),
       asyncio.Task(fibonacci(10)),
       asyncio.Task(binomialCoeff(20,10))]
# 取得待解决时间列表
loop=asyncio.get_event_loop()
# 直到全部完成
loop.run_until_complete(asyncio.wait(tasks))
loop.close()

