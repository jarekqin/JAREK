#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Feb 17 14:53:02 2019

@author: me
"""

# 异步通信
# 简单的异步concurrent.future案例
import concurrent.futures as cf
import time
arr=[i for i in range(1,11)]
def evaluate(x):
    result=count(x)
    print('item: ',x,'result=',result)
    
def count(number):
    for i in range(1000000):
        i+=1
    return i*number

# 线性执行
start=time.clock()
for item in arr:
    evaluate(item)
print('Sequential execution in',time.clock()-start,'seconds\n')

# 线程执行
start1=time.clock()
with cf.ThreadPoolExecutor(max_workers=5) as exe:
    for item in arr:
        exe.submit(evaluate,item)
print('Thread_pool exe in',time.clock()-start1,'seconds\n')


# 进程执行
start1=time.clock()
with cf.ProcessPoolExecutor(max_workers=5) as exe:
    for item in arr:
        exe.submit(evaluate,item)
print('Process_pool exe in',time.clock()-start1,'seconds')
# 线程池最慢，进程池最快，是线程池和线性执行的11倍左右速度


