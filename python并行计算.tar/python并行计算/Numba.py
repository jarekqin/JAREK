#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Mar 14 22:05:35 2019

@author: abc
"""

import numba as nb
@nb.jit
def sum_sq(a):
    result=0
    N=len(a)
    for i in range(N):
        result+=a[i]
    return result

import numpy as np
x=np.random.rand(10000)

print(sum_sq.py_func(x))

print(sum_sq(x))
# 一次只能使用一次显性签名声明
x=np.random.rand(10000).astype('float64')
print(sum_sq(x))
print(sum_sq.signatures)

# 案例2
@nb.jit #(nopython=True) # 强制原生模式会报错
def concatenate(strings):
    result=''
    for s in strings:
        result+=s
    return result
concatenate(['hello','world'])
concatenate.signatures
concatenate.inspect_types()

# numba通用函数
@np.vectorize
def cantor(a,b):
    return int(0.5*(a+b)*(a+1+b)+b)

@nb.vectorize
def cantor_nb(a,b):
    return int(0.5*(a+b)*(a+1+b)+b)

%timeit cantor(5,6)
%timeit cantor_nb(5,6)


# 矩阵的广播计算
@nb.guvectorize(['float64[:],float64[:],float64[:]'],'(n), (n)->()')
def euclidean(a,b,out):
    n=a.shape[0]
    out[0]=0.0
    for i in range(n):
        out[0]+=(a[i]-b[i])**2
        
a=np.random.rand(2)
b=np.random.rand(2)
c=euclidean(a,b)


a=np.random.rand(10,2)
b=np.random.rand(10,2)
c=euclidean(a,b)


# jit类支持定会类
class Node:
    def __init__(self,value):
        self.value=value
        self.next=None

class LinkedList:
    def __init__(self):
        self.head=None
        
    def push_front(self,value):
        if self.head==None:
            self.head=Node(value)
        else:
            new_head=Node(value)
            new_head.next=self.head
            self.head=new_head
            
    def show(self):
        node=self.head
        while node:
            print(node.value)
            node=node.next
list1=LinkedList()
list1.push_front(1)
list1.push_front(2)
list1.push_front(3)
list1.show()

# 继承+多态改变子类函数为父类
class A(object):
    def show(self):
        print('this is class A')
class B(A):
    def show(self):
        print('this is class B')
b=B()
b.__class__=A
b.show()


@nb.jit
def sum_list(l):
    result=0
    node=l.head
    while node:
        result+=node.value
        node=node.next
    return result
l=LinkedList()
for i in range(10000):
    l.push_front(i)

%timeit sum_list.py_func(l)

%timeit sum_list(l)

# 用于类的装饰器
node_type=nb.deferred_type()
node_spec=[
        ('next',nb.optional(node_type)),
        ('value',nb.int64)
        ]

@nb.jitclass(node_spec)
class Node2:
    def __init__(self,value):
        self.value=value
        self.next=None
node_type.define(Node2.class_type.instance_type)


ll_spec=[
        ('head',nb.optional(Node2.class_type.instance_type))
        ]
@nb.jitclass(ll_spec)
class LinkedList2:
    def __init__(self):
        self.head=None
        
    def push_front(self,value):
        if self.head==None:
            self.head=Node(value)
        else:
            new_head=Node(value)
            new_head.next=self.head
            self.head=new_head
            
    def show(self):
        node=self.head
        while node:
            print(node.value)
            node=node.next

l=LinkedList2()
for i in range(10000):
    l.push_front(i)
    