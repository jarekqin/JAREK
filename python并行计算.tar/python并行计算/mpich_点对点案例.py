#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Feb 17 13:24:05 2019

@author: me
"""

# mpich的点对点通信
from mpi4py import MPI
comm=MPI.COMM_WORLD
rank=comm.rank
print('my rank is: ',rank)

#if rank==0:
#    data=10000
#    destination_process=4
#    comm.send(data,dest=destination_process)
#    print('sending data %s ' % data+\
#          'to process %d' % destination_process)
#    
#if rank==1:
#    data='hello'
#    destination_process=8
#    comm.send(data,dest=destination_process)
#    print('sending data %s' % data+\
#          'to process %d' % destination_process)       
#
#if rank==4:
#    data=comm.recv(source=0)
#    print('data received is %s' % data)
#    
#if rank==8:
#    data1=comm.recv(source=1)
#    print('data received is %s' % data1)
#    
    
# 避免死锁方案
# sendrecv结合了send和recv两个函数的参数，但有负责自动检查的功能
# 避免死锁
if rank==1:
    data='a'
    destination=5
    source=5
    # comm.send(data,dest=destination)
    data_recv=comm.sendrecv(data,dest=destination,
                            source=source)
    
# 发送和接受顺序应该等同于rank=1
if rank==5:
    data='b'
    destination=1
    source=1
    # comm.send(data,dest=destination)
    data_recv=comm.sendrecv(data,dest=destination,
                            source=source)
