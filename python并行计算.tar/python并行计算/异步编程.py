#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Mar 14 23:41:19 2019

@author: abc
"""

# 回调函数
import threading
import time
def wait_and_print(msg):
    time.sleep(1.0)
    print(msg)
    
    
def wait_and_print_async(msg):
    def callback():
        print(msg)
        
    timer=threading.Timer(1.0,callback)
    timer.start()

wait_and_print('first call')
wait_and_print('second call')
print('after all')

wait_and_print_async('1st call')
wait_and_print_async('2nd call')
print('after submission')