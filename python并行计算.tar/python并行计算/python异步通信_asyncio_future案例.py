#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Feb 17 19:40:07 2019

@author: me
"""

# asyncio.future
import asyncio
import sys
@asyncio.coroutine
def first_corroutine(future,n):
    count=0
    for i in range(1,n+1):
        count+=i
    yield from asyncio.sleep(4)
    future.set_result('first coroutine (sum of N integers) result='+
                      str(count))

@asyncio.coroutine
def second_coroutine(future,n):
    count=1
    for i in range(2,n+1):
        count*=i
    yield from asyncio.sleep(4)   
    future.set_result('first coroutine (factorial) result='+
                      str(count))
    
def get_result(future):
    print(future.result())
    
n1=int(input('please type into n1: '))
n2=int(input('please type into n2: '))
loop=asyncio.get_event_loop()
future1=asyncio.Future()
future2=asyncio.Future()

tasks=[first_corroutine(future1,n1),
       second_coroutine(future2,n2)]
future1.add_done_callback(get_result)
future2.add_done_callback(get_result)
loop.run_until_complete(asyncio.wait(tasks))
loop.close()