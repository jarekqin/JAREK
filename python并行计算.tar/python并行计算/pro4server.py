#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Feb 20 19:20:51 2019

@author: me
"""

# pyro4 测试文档服务器段
import Pyro4
@expose
class Server(object):
    def welcomeMessage(self,name):
        return ('Hi welcome'+str(name))
    
def startServer():
    server=Server()
    daemon=Pyro4.Daemon()
    ns=Pyro4.locateNS()
    uri=daemon.register(server)
    ns.register('server',uri)
    print('Ready. Object uri= ',uri)
    daemon.requestLoop()
        
if __name__=='__main__':
    startServer()