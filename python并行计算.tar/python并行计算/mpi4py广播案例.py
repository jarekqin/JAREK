#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Feb 17 13:47:56 2019

@author: me
"""
# 广播功能都是异步通信
# mpi4py的广播实现聚合通信案例，只能发送相同的信息
# 一个服务器发出多条信息到不同的客户端
from mpi4py import MPI
comm=MPI.COMM_WORLD
rank=comm.Get_rank()

#if rank==0:# 设置为服务器端根进程
#    variable=100
#else:
#    variable=None
#    
#variable=comm.bcast(variable,root=0)
#print('bcast starting')
#print('process=%d' % rank,'variable =%d' % variable)
#print('bcast ending')
#
## scatter广播可以发送不同的信息段
## 但在执行的时候，必须保证输入执行数=数组个数
#if rank==0:
#    arr=[i for i in range(1,11)]
#else:
#    arr=None
#print('scatter starting')
#recvbuf=comm.scatter(arr,root=0)
#print('process=%d' % rank,'received =%d' % recvbuf)
#print('scatter ending')
#
## gather反向聚合通信(此通信是同步通信)
## 多个客户端向一个服务器端发送消息
## comm.gather,comm.gatherv,comm.Gather用来收集一个任务
## comm.Allgather,comm.Allgatherv,comm.allgather收集所有任务
#size=comm.Get_size()
#data=(rank+1)**2
#rank=comm.Get_rank()
#data=comm.gather(data,root=0)
#if rank==0:
#    print('rank=%s ' %rank,
#          '...receiving data to other process')
#    for i in range(1,size):
#        data[i]=(i+1)**2
#        print('process %s receiving %s from process %s' % \
#              (rank,data[i],i))

# 全通信功能
# 结合了scatter和gather(随机同步或者异步通信机制)
import numpy as np
size=comm.Get_size()
rank=comm.Get_rank()

a_size=1
send_data=(rank+1)*np.arange(size,dtype=int)
recv_data=np.empty(size*a_size,dtype=int)
comm.Alltoall(send_data,recv_data)

print('process %s sending %s receving %s' % 
      (rank,send_data,recv_data))